#!/usr/bin/python
# -*- coding: utf-8 -*-

# Inicio Ronda Final - 2019
# La libreria Pygame debe estar instalada junto a Python 2.7.13
#  para que el codigo se ejecute.
# Si no lo esta, ir en Windows a la aplicacion Simbolo del Sistema y
#  con una conexion activa a Internet ejecutar el comando pip install pygame.

import pygame
import random
import pygooey
import csv
import os.path

# Se inicializa la libreria Pygame y demas variables.

pygame.init()
pygame.font.init()
pygame.mixer.music.load('musica.mid')  # Megalovania de Toby Fox
pygame.mixer.music.play(-1)
pygame.display.set_caption('Maraton 2019 - Ronda Final')
pantalla = pygame.display.set_mode((1152, 648))
tipografia = pygame.font.SysFont('Comic Sans MS', 18)
tipografiaGrande = pygame.font.SysFont('Comic Sans MS', 24)

global cantidadDeEnergia
global lstComandosRealizados
global cantidadDePasos
global zonaDeTransporte
global nivelCompletado
global color
global color_anterior

cantidadDePasos = 0
cantidadDeEnergia = 7000
(colorVerde, colorAzul, colorBlanco, colorNegro, colorNaranja) = ((11, 102, 35), (0, 0, 255), (255, 255, 255), (0, 0, 0), (239, 27, 126))
cantidadDeCasillasPorLado = 8  # Debe ser numero par ya que la zona es un cuadrado
cantPixelesPorLadoCasilla = 72
salirJuego = False
lstAreaProtegida = []
lstComandosRealizados = []
listaAmenazas = []
nivelCompletado = False
colores = (colorVerde, colorAzul, colorBlanco, colorNegro, colorNaranja)
color = colorAzul
color_anterior = colorAzul
# Se cargan las imagenes.

imgSuperTablet = pygame.image.load('supertablet.png')
imgPared = pygame.image.load('pared.png')
imgAreaProtegida = pygame.image.load('areaprotegida.png')

imgAmenaza = pygame.image.load('amenaza1.png')
imgAmenaza1 = pygame.transform.scale(imgAmenaza, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
listaAmenazas.append(imgAmenaza1)
imgAmenaza = pygame.image.load('amenaza2.png')
imgAmenaza2 = pygame.transform.scale(imgAmenaza, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
listaAmenazas.append(imgAmenaza2)
imgAmenaza = pygame.image.load('amenaza3.png')
imgAmenaza3 = pygame.transform.scale(imgAmenaza, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
listaAmenazas.append(imgAmenaza3)
imgAmenaza = pygame.image.load('amenaza4.png')
imgAmenaza4 = pygame.transform.scale(imgAmenaza, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
listaAmenazas.append(imgAmenaza4)

imgSuperTablet = pygame.transform.scale(imgSuperTablet,
                                        (cantPixelesPorLadoCasilla,
                                         cantPixelesPorLadoCasilla))
imgPared = pygame.transform.scale(imgPared, (cantPixelesPorLadoCasilla,
                                             cantPixelesPorLadoCasilla))
imgAreaProtegida = pygame.transform.scale(imgAreaProtegida,
                                          (cantPixelesPorLadoCasilla,
                                           cantPixelesPorLadoCasilla))


# ----------------------------------------------------------------------------
# comienzo de nuevas funciones
# ----------------------------------------------------------------------------
global sin_moverse

# Consigna 5 ... se incorporan mejoras.
# Selecciona un virus al azar para cada juego.


def actualizarAmenazas():
    global imgAmenaza

    virus = random.randint(0, 3)
    imgAmenaza = listaAmenazas[virus]


# maximos del juego
maximo_de_tiempo = 60
maximo_de_movimientos = 60

# Por default el modo de juego es por cantidad de movimientos.
modoDeJuego = "movimientos"

# Dibuja el modo de juego que esta seleccionado.


def dibujarModoDeJuego():

    if modoDeJuego == "movimientos":
        texto = tipografiaGrande.render('El Juego es por maximo ' +
                                        str(maximo_de_movimientos) +
                                        ' movimientos.', False, colorBlanco)
    else:
        texto = tipografiaGrande.render('El Juego es por maximo ' +
                                        str(maximo_de_tiempo) +
                                        ' segundos.', False, colorBlanco)

    ancho = 475
    alto = 40
    x = 75 + cantidadDeCasillasPorLado * cantPixelesPorLadoCasilla
    y = cantPixelesPorLadoCasilla * 4
    pygame.draw.rect(pantalla, colorAzul, (x, y, ancho, alto))
    pantalla.blit(texto, (x + 5, y, ancho, alto))
    pygame.display.update()


# Consigna 5
# Cualquier funcionalidad extra sumara puntos en la evaluacion del
#  jurado siempre y cuando esten cumplidas las consignas anteriores.
#  El jurado presta mucha atencion a la creatividad.
# Se definen limites al tiempo y movimientos del juego.

def siFinDelJuego():

    if modoDeJuego == "movimientos" and cantidadDePasos == maximo_de_movimientos:
        resetearJuego()
    elif modoDeJuego == "tiempo" and segundos == maximo_de_tiempo:
        resetearJuego()

# Consigna 5
# Cualquier funcionalidad extra sumara puntos en la evaluacion del
#  jurado siempre y cuando esten cumplidas las consignas anteriores.
#  El jurado presta mucha atencion a la creatividad.
# Se maneja el ingreso por teclado del nombre del jugador ganador.
nombreDelJugador = None


def asignar_con_enter(id, texto):
    global nombreDelJugador

    nombreDelJugador = texto


def ingresar_nombre_jugador():
    global nombreDelJugador

    nombreDelJugador = None
    done = False

    settings = {'command': asignar_con_enter,
                'inactive_on_enter': False,
                'clear_on_enter': True}
    entry = pygooey.TextBox(rect=(300, 80, 150, 30), **settings)

    textoPasos = tipografia.render('ingresar su Nombre:', False,
                                   colorBlanco)
    pantalla.blit(textoPasos, (100, 80, 20, 30))

    while not done:
        for event in pygame.event.get():
            entry.get_event(event)

            if nombreDelJugador:
                done = True

        entry.update()
        entry.draw(pantalla)
        pygame.display.update()

    return nombreDelJugador

# Consigna 5 ... se incorporan mejoras.
# Contador del tiempo de juego.

segundos = 0

# Seteo del timer cada segundo (1000ms).
pygame.time.set_timer(pygame.USEREVENT + 1, 1000)

# Se posicionan los objetos del mundo en forma aleatoria.


def mundoRandom(zonaDeTransporte):
    '''
    zonaDeTransporte[2][5] = 0

    zonaDeTransporte[3][5] = 0
    zonaDeTransporte[4][5] = 0
    zonaDeTransporte[5][5] = 0
    zonaDeTransporte[6][5] = 0
    zonaDeTransporte[5][6] = 0
    '''
    lstAreaProtegida[:] = []

    lista = []
    # genera ubicaciones en todo el mundo
    while len(lista) < 8:
        x = random.randint(2, 7)
        y = random.randint(3, 7)
        posicion = (x, y)
        if posicion not in lista:
            lista.append(posicion)

    # genera ubicaciones en la zona central
    while len(lista) < 13:
        x = random.randint(3, 6)
        y = random.randint(4, 6)
        posicion = (x, y)
        if posicion not in lista:
            lista.append(posicion)

    # agregando los virus
    x, y = lista.pop()
    zonaDeTransporte[x][y] = 'virus'
    x, y = lista.pop()
    zonaDeTransporte[x][y] = 'virus'
    x, y = lista.pop()
    zonaDeTransporte[x][y] = 'virus'
    x, y = lista.pop()
    zonaDeTransporte[x][y] = 'virus'
    x, y = lista.pop()
    zonaDeTransporte[x][y] = 'virus'

    # Consigna 5 ... se incorporan mejoras.
    # agregando un bloque de pared
    x, y = lista.pop()
    zonaDeTransporte[x][y] = 'pared'

    # agregando el jugador
    x, y = lista.pop()
    zonaDeTransporte[x][y] = 'jugador'

    # agregando las zonas protegidas
    x, y = lista.pop()
    lstAreaProtegida.append((x, y))
    x, y = lista.pop()
    lstAreaProtegida.append((x, y))
    x, y = lista.pop()
    lstAreaProtegida.append((x, y))
    x, y = lista.pop()
    lstAreaProtegida.append((x, y))
    x, y = lista.pop()
    lstAreaProtegida.append((x, y))

    return zonaDeTransporte

# Variable para contar el tiempo sin movimientos de Super Tablet.

sin_moverse = 0

# Inicializa el tiempo sin movimientos.


def resetearTiempoSinMovimientos():
    global sin_moverse

    sin_moverse = 0


# Se muestra el contador de segundos sin movimientos de Super Tablet

def dibujarTiempoSinMovimientos():
    global sin_moverse

    ancho = 350
    alto = 40
    x = 75 + cantidadDeCasillasPorLado * cantPixelesPorLadoCasilla
    y = cantPixelesPorLadoCasilla * 8
    pygame.draw.rect(pantalla, colorAzul, (x, y, ancho, alto))
    texto = tipografiaGrande.render('Segundos sin movimientos: ' + str(sin_moverse), False, colorBlanco)
    pantalla.blit(texto, (x + 5, y, ancho, alto))

    pygame.display.update()

# Se actualiza el tiempo transcurrido.


def actualizarTiempo():
    global segundos, sin_moverse

    segundos += 1
    sin_moverse += 1

    # Consigna 2
    # Programar que si Super Tablet pasa mas de 15 segundos sin moverse
    #  el nivel se reinicie.
    if sin_moverse > 15:
        resetearJuego()
    else:
        dibujarTiempoDeJuego()
        dibujarTiempoSinMovimientos()

# ----------------------------------------------------------------------------
# fin de nuevas funciones
# ----------------------------------------------------------------------------

# Se crea el mapa del nivel y algunas operaciones para los elementos que se
#  encuentran dentro de la zona de transporte.


def crearZonaDeTransporte():

    zonaDeTransporte = [[0 for x in range(cantidadDeCasillasPorLado + 1)]
                        for y in range(cantidadDeCasillasPorLado + 1)]

    zonaDeTransporte[1][2] = 'pared'
    zonaDeTransporte[2][2] = 'pared'
    zonaDeTransporte[3][2] = 'pared'
    zonaDeTransporte[4][2] = 'pared'
    zonaDeTransporte[5][2] = 'pared'
    zonaDeTransporte[6][2] = 'pared'
    zonaDeTransporte[7][2] = 'pared'
    zonaDeTransporte[8][2] = 'pared'

    zonaDeTransporte[1][8] = 'pared'
    zonaDeTransporte[2][8] = 'pared'
    zonaDeTransporte[3][8] = 'pared'
    zonaDeTransporte[4][8] = 'pared'
    zonaDeTransporte[5][8] = 'pared'
    zonaDeTransporte[6][8] = 'pared'
    zonaDeTransporte[7][8] = 'pared'
    zonaDeTransporte[8][8] = 'pared'

    zonaDeTransporte[1][3] = 'pared'
    zonaDeTransporte[1][4] = 'pared'
    zonaDeTransporte[1][5] = 'pared'
    zonaDeTransporte[1][6] = 'pared'
    zonaDeTransporte[1][7] = 'pared'

    zonaDeTransporte[8][3] = 'pared'
    zonaDeTransporte[8][4] = 'pared'
    zonaDeTransporte[8][5] = 'pared'
    zonaDeTransporte[8][6] = 'pared'
    zonaDeTransporte[8][7] = 'pared'
    '''
    zonaDeTransporte[2][5] = 'jugador'

    zonaDeTransporte[3][5] = 'virus'
    zonaDeTransporte[4][5] = 'virus'
    zonaDeTransporte[5][5] = 'virus'
    zonaDeTransporte[6][5] = 'virus'
    zonaDeTransporte[5][6] = 'virus'

    lstAreaProtegida.append((2, 4))
    lstAreaProtegida.append((2, 6))
    lstAreaProtegida.append((7, 4))
    lstAreaProtegida.append((7, 6))
    lstAreaProtegida.append((4, 6))
    '''
    # Consigna 3
    # Ajustar el disenio al nivel cambiando las posiciones de las paredes,
    #  virus y/o zonas protegidas, teniendo en cuenta, que los destinatarios
    #  del juego son estudiantes del segundo nivel de primaria.
    # Crear un mundo aleatorio.
    zonaDeTransporte = mundoRandom(zonaDeTransporte)

    return zonaDeTransporte


zonaDeTransporte = crearZonaDeTransporte()


def hayAreaProtegidaEn(x, y):
    punto = (x, y)
    return lstAreaProtegida.__contains__(punto)


def posicionarElemento(elemento, x, y):
    global zonaDeTransporte
    zonaDeTransporte[x][y] = elemento


def borrarElemento(x, y):
    global zonaDeTransporte
    zonaDeTransporte[x][y] = 0


# Se dibujan la zona de transporte, fondo y reglas.

def dibujarZonaDeTransporte():
    global zonaDeTransporte

    cnt = 0
    for i in range(1, cantidadDeCasillasPorLado + 1):
        for j in range(1, cantidadDeCasillasPorLado + 1):
            if cnt % 2 == 0:
                pygame.draw.rect(pantalla, colorVerde,
                                 [cantPixelesPorLadoCasilla * j,
                                  cantPixelesPorLadoCasilla * i,
                                  cantPixelesPorLadoCasilla,
                                  cantPixelesPorLadoCasilla])
            else:
                pygame.draw.rect(pantalla, colorVerde,
                                 [cantPixelesPorLadoCasilla * j,
                                  cantPixelesPorLadoCasilla * i,
                                  cantPixelesPorLadoCasilla,
                                  cantPixelesPorLadoCasilla])

            if hayAreaProtegidaEn(j, i) is True:
                pantalla.blit(imgAreaProtegida,
                              (cantPixelesPorLadoCasilla * j,
                               cantPixelesPorLadoCasilla * i))
            if zonaDeTransporte[j][i] == 'jugador':
                pantalla.blit(imgSuperTablet,
                              (cantPixelesPorLadoCasilla * j,
                               cantPixelesPorLadoCasilla * i))
            if zonaDeTransporte[j][i] == 'pared':
                pantalla.blit(imgPared, (cantPixelesPorLadoCasilla * j,
                                         cantPixelesPorLadoCasilla * i))
            if zonaDeTransporte[j][i] == 'virus':
                pantalla.blit(imgAmenaza, (cantPixelesPorLadoCasilla * j,
                                           cantPixelesPorLadoCasilla * i))
            cnt += 1
        cnt -= 1

    pygame.draw.rect(pantalla, colorBlanco, [cantPixelesPorLadoCasilla,
                     cantPixelesPorLadoCasilla,
                     cantidadDeCasillasPorLado * cantPixelesPorLadoCasilla,
                     cantidadDeCasillasPorLado * cantPixelesPorLadoCasilla], 1)
    pygame.display.update()


def dibujarFondo():
    fondo = pygame.image.load('fondo.png')
    pantalla.blit(fondo, (0, 0))

# Consigna 5 ... se incorporan mejoras.


def dibujarReglas():

    textoReglas = tipografia.render('Mover a Super Tablet con las flechas del teclado para que lleve los virus a las zonas protegidas.',
                                    False, colorBlanco)
    textoReglas2 = tipografia.render('M-jugar por Movimientos. T-jugar por Tiempo. X-Deshace la movida. R-Reinicia el nivel. Q-Quit.',
                                     False, colorBlanco)

    ancho = 810
    alto = 46
    x = 340
    y = 3
    pygame.draw.rect(pantalla, colorAzul, (x, y, ancho, alto))
    pantalla.blit(textoReglas, (x + 5, y, ancho, alto))

    y = 35
    alto = 35

    pygame.draw.rect(pantalla, colorAzul, (x, y, ancho, alto))
    pantalla.blit(textoReglas2, (x + 5, y, ancho, alto))

    pygame.display.update()


# Se dibuja el contador de segundos jugados, se actualizan los pasos de Super Tablet y el contador de energia.

def dibujarTiempoDeJuego():
    global segundos

    ancho = 350
    alto = 40
    x = 75 + cantidadDeCasillasPorLado * cantPixelesPorLadoCasilla
    y = cantPixelesPorLadoCasilla * 7
    pygame.draw.rect(pantalla, colorAzul, (x, y, ancho, alto))
    textoSegundos = tipografiaGrande.render('Segundos transcurridos: ' + str(segundos), False, colorBlanco)
    pantalla.blit(textoSegundos, (x + 5, y, ancho, alto))

    pygame.display.update()


def actualizarContadorDePasos(num):
    global cantidadDePasos

    cantidadDePasos = cantidadDePasos + num

    ancho = 350
    alto = 40
    x = 75 + cantidadDeCasillasPorLado * cantPixelesPorLadoCasilla
    y = cantPixelesPorLadoCasilla * 6
    pygame.draw.rect(pantalla, colorAzul, (x, y, ancho, alto))
    textoPasos = tipografiaGrande.render('Cantidad de movimientos: ' + str(cantidadDePasos), False, colorBlanco)
    pantalla.blit(textoPasos, (x + 5, y, ancho, alto))
    pygame.display.update()

    # se reinicia el contador de tiempo inactivo cada vez que el jugador se mueve.
    resetearTiempoSinMovimientos()
    dibujarTiempoSinMovimientos()
    


def actualizarContadorDeElectricidad(num):
    global cantidadDeEnergia

    cantidadDeEnergia = cantidadDeEnergia - num
    ancho = 550
    alto = 40
    x = 75 + cantidadDeCasillasPorLado * cantPixelesPorLadoCasilla
    y = cantPixelesPorLadoCasilla * 5
    pygame.draw.rect(pantalla, colorAzul, (x, y, ancho, alto))
    textoEnergia = tipografiaGrande.render('Bateria disponible de Super Tablet: ' +
                                           str(cantidadDeEnergia) + 'mA', False, colorBlanco)
    pantalla.blit(textoEnergia, (x + 5, y, ancho, alto))
    pygame.display.update()


# Se crean las funciones para dibujar la felicitacion y el cartel de ronda final.

def dibujarFelicitacion():
    global nivelCompletado

    x = 50
    y = 3
    ancho = 200
    alto = 46

    if nivelCompletado is True:
        textoFelicitacion = tipografiaGrande.render('GANASTE :)', False, colorBlanco)
    else:
        textoFelicitacion = tipografiaGrande.render('Juego en curso', False, colorBlanco)

    pygame.draw.rect(pantalla, colorAzul, (x, y, ancho, alto))
    pantalla.blit(textoFelicitacion, (x + 5, y, ancho, alto))
    pygame.display.update()


def dibujarCartelRondaFinal():
    global color, color_anterior
    textoFelicitacion = tipografiaGrande.render('  Ronda Final', False, colorNaranja)
    print("dibujarCarte")
    color_anterior = color
    
    color = random.choice(colores)
    ancho = 160
    alto = 45
    x = 75 + cantidadDeCasillasPorLado * cantPixelesPorLadoCasilla
    y = 106
    pygame.draw.rect(pantalla, color, (x, y, ancho, alto))
    pantalla.blit(textoFelicitacion, (x + 5, y, ancho, alto))

    pygame.display.update()


def VolverColor():
    global color, color_anterior
    textoFelicitacion = tipografiaGrande.render('  Ronda Final', False, colorNaranja)
    print(color, color_anterior)
    color = color_anterior
    
    ancho = 160
    alto = 45
    x = 75 + cantidadDeCasillasPorLado * cantPixelesPorLadoCasilla
    y = 106
    pygame.draw.rect(pantalla, color, (x, y, ancho, alto))
    pantalla.blit(textoFelicitacion, (x + 5, y, ancho, alto))

    pygame.display.update()

    
# Consigna 5 ... se incorporan mejoras.
# Se crean las funciones relacionadas con la tabla de marcadores.

def obtener5QueJugaronPrimero():
    lstPuntuaciones = []

    if os.path.isfile('puntuaciones.txt'):

        with open('puntuaciones.txt') as csvFile:
            reader = csv.reader(csvFile, delimiter=',')

            for jugador in reader:
                par = []
                par.append(jugador[0])
                par.append(int(jugador[1]))
                lstPuntuaciones.append(par)

        csvFile.close()

    # Consigna 1
    # Leer el archivo de texto que contiene a los nombres de los jugadores y
    #  puntuaciones y mostrar en forma actualizada a los cinco mejores de mayor
    #  a menor (por puntuacion) en todo momento del juego.
    # Codigo organizador del ranking de los 5 mejores.
    lstPuntuaciones.sort(key=lambda par: par[1], reverse=True)

    lstPuntuaciones = lstPuntuaciones[:5]

    return lstPuntuaciones


# Se crea una funcion que presenta a los cinco jugadores con mayor puntaje

def dibujar5QueJugaronPrimero():
    lst5Jugadores = obtener5QueJugaronPrimero()
    ancho = 220
    alto = 40
    x = 350 + cantidadDeCasillasPorLado * cantPixelesPorLadoCasilla
    i = 8

    for par in lst5Jugadores:
        y = 32 * i - 150
        textoRanking = tipografiaGrande.render(str(par[0]) + ': ' + str(par[1]), False, colorBlanco)
        pygame.draw.rect(pantalla, colorAzul, (x, y, ancho, alto))
        pantalla.blit(textoRanking, (x + 5, y, ancho, alto))
        i = i + 1

    pygame.display.update()


# Consigna 5 ... se incorporan mejoras.
# Se crea una funcion que dibuja el Fondo del juego.

def dibujarFondoDeljuego():
    dibujarFondo()
    dibujarZonaDeTransporte()
    dibujarCartelRondaFinal()
    dibujarReglas()
    dibujarFelicitacion()


# Consigna 5 ... se incorporan mejoras.
# Se crea una funcion que dibuja la presentacion del juego.

def dibujarDatosDelJuego():
    dibujarZonaDeTransporte()
    dibujar5QueJugaronPrimero()
    dibujarModoDeJuego()
    actualizarContadorDeElectricidad(0)
    actualizarContadorDePasos(0)
    dibujarTiempoDeJuego()
    dibujarTiempoSinMovimientos()

    pygame.display.update()


actualizarAmenazas()
dibujarFondoDeljuego()
dibujarDatosDelJuego()


# Se crea una funcion que indique si el nivel fue solucionado.

def estaSolucionado():
    global nivelCompletado
    global zonaDeTransporte

    cantVirusSobreAreasProtegidas = 0

    for punto in lstAreaProtegida:
        x = punto[0]
        y = punto[1]
        if zonaDeTransporte[x][y] == 'virus':
            cantVirusSobreAreasProtegidas = cantVirusSobreAreasProtegidas + 1

    if cantVirusSobreAreasProtegidas == len(lstAreaProtegida):
        nivelCompletado = True
    else:
        nivelCompletado = False

    dibujarFelicitacion()
    escribirPuntuacion()


# Creamos operaciones para mover a|| Super Tablet

def irALaDerecha():
    global zonaDeTransporte

    for i in range(1, cantidadDeCasillasPorLado):
        for j in range(1, cantidadDeCasillasPorLado):
            if zonaDeTransporte[j][i] == 'jugador':
                if zonaDeTransporte[j + 1][i] == 0:
                    posicionarElemento('jugador', j + 1, i)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(10)
                    borrarElemento(j, i)
                    comando = ('jugador', j, i)
                    lstComandosRealizados.append(comando)
                    comando = ('borrar', j + 1, i)
                    lstComandosRealizados.append(comando)
                    pygame.mixer.Channel(1).play(pygame.mixer.Sound('mover.wav'))
                    break
                if zonaDeTransporte[j + 1][i] == 'virus' and not (zonaDeTransporte[j + 2][i] == 'pared' or zonaDeTransporte[j + 2][i] == 'virus'):
                    posicionarElemento('virus', j + 2, i)
                    posicionarElemento('jugador', j + 1, i)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(15)
                    borrarElemento(j, i)
                    comando = ('jugador', j, i)
                    lstComandosRealizados.append(comando)
                    comando = ('virus', j + 1, i)
                    lstComandosRealizados.append(comando)
                    comando = ('borrar', j + 1, i)
                    lstComandosRealizados.append(comando)
                    comando = ('borrar', j + 2, i)
                    lstComandosRealizados.append(comando)
                    pygame.mixer.Channel(1).play(pygame.mixer.Sound('mover.wav'))
                    break
                if zonaDeTransporte[j + 1][i] == 'virus' and zonaDeTransporte[j + 2][i] == 'virus':
                    actualizarContadorDeElectricidad(200)
                    comando = ('hicemuchafuerza', 0, 0)
                    lstComandosRealizados.append(comando)
                    break


def irArriba():
    global zonaDeTransporte
    global lstComandosRealizados

    for i in range(1, cantidadDeCasillasPorLado):
        for j in range(1, cantidadDeCasillasPorLado):
            if zonaDeTransporte[j][i] == 'jugador':
                if zonaDeTransporte[j][i - 1] == 0:
                    posicionarElemento('jugador', j, i - 1)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(10)
                    borrarElemento(j, i)
                    comando = ('jugador', j, i)
                    lstComandosRealizados.append(comando)
                    comando = ('borrar', j, i - 1)
                    lstComandosRealizados.append(comando)
                    pygame.mixer.Channel(1).play(pygame.mixer.Sound('mover.wav'))
                    break
                if zonaDeTransporte[j][i - 1] == 'virus' and not (zonaDeTransporte[j][i - 2] == 'pared' or zonaDeTransporte[j][i - 2] == 'virus'):
                    posicionarElemento('virus', j, i - 2)
                    posicionarElemento('jugador', j, i - 1)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(15)
                    borrarElemento(j, i)
                    comando = ('jugador', j, i)
                    lstComandosRealizados.append(comando)
                    comando = ('virus', j, i - 1)
                    lstComandosRealizados.append(comando)
                    comando = ('borrar', j, i - 1)
                    lstComandosRealizados.append(comando)
                    comando = ('borrar', j, i - 2)
                    lstComandosRealizados.append(comando)
                    pygame.mixer.Channel(1).play(pygame.mixer.Sound('mover.wav'))
                    break
                if zonaDeTransporte[j][i - 1] == 'virus' and zonaDeTransporte[j][i - 2] == 'virus':
                    actualizarContadorDeElectricidad(200)
                    comando = ('hicemuchafuerza', 0, 0)
                    lstComandosRealizados.append(comando)
                    break


def irAbajo():
    global zonaDeTransporte

    for j in range(1, cantidadDeCasillasPorLado):
        for i in range(1, cantidadDeCasillasPorLado):
            if zonaDeTransporte[j][i] == 'jugador':
                if zonaDeTransporte[j][i + 1] == 0:
                    posicionarElemento('jugador', j, i + 1)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(10)
                    borrarElemento(j, i)
                    comando = ('jugador', j, i)
                    lstComandosRealizados.append(comando)
                    comando = ('borrar', j, i + 1)
                    lstComandosRealizados.append(comando)
                    pygame.mixer.Channel(1).play(pygame.mixer.Sound('mover.wav'))
                    break
                if zonaDeTransporte[j][i + 1] == 'virus' and not (zonaDeTransporte[j][i + 2] == 'pared' or zonaDeTransporte[j][i + 2] == 'virus'):
                    posicionarElemento('virus', j, i + 2)
                    posicionarElemento('jugador', j, i + 1)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(15)
                    borrarElemento(j, i)
                    comando = ('jugador', j, i)
                    lstComandosRealizados.append(comando)
                    comando = ('virus', j, i + 1)
                    lstComandosRealizados.append(comando)
                    comando = ('borrar', j, i + 1)
                    lstComandosRealizados.append(comando)
                    comando = ('borrar', j, i + 2)
                    lstComandosRealizados.append(comando)
                    pygame.mixer.Channel(1).play(pygame.mixer.Sound('mover.wav'))
                    break
                if zonaDeTransporte[j][i + 1] == 'virus' and zonaDeTransporte[j][i + 2] == 'virus':
                    actualizarContadorDeElectricidad(200)
                    comando = ('hicemuchafuerza', 0, 0)
                    lstComandosRealizados.append(comando)
                    break


def irALaIzquierda():
    global zonaDeTransporte

    for i in range(1, cantidadDeCasillasPorLado):
        for j in range(1, cantidadDeCasillasPorLado):
            if zonaDeTransporte[j][i] == 'jugador':
                if zonaDeTransporte[j - 1][i] == 0:
                    posicionarElemento('jugador', j - 1, i)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(10)
                    borrarElemento(j, i)
                    comando = ('jugador', j, i)
                    lstComandosRealizados.append(comando)
                    comando = ('borrar', j - 1, i)
                    lstComandosRealizados.append(comando)
                    pygame.mixer.Channel(1).play(pygame.mixer.Sound('mover.wav'))
                    break
                if zonaDeTransporte[j - 1][i] == 'virus' and not (zonaDeTransporte[j - 2][i] == 'pared' or zonaDeTransporte[j - 2][i] == 'virus'):
                    posicionarElemento('virus', j - 2, i)
                    posicionarElemento('jugador', j - 1, i)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(15)
                    comando = ('jugador', j, i)
                    lstComandosRealizados.append(comando)
                    comando = ('virus', j - 1, i)
                    lstComandosRealizados.append(comando)
                    comando = ('borrar', j - 1, i)
                    lstComandosRealizados.append(comando)
                    comando = ('borrar', j - 2, i)
                    lstComandosRealizados.append(comando)
                    borrarElemento(j, i)
                    pygame.mixer.Channel(1).play(pygame.mixer.Sound('mover.wav'))
                    break
                if zonaDeTransporte[j - 1][i] == 'virus' and zonaDeTransporte[j - 2][i] == 'virus':
                    actualizarContadorDeElectricidad(200)
                    comando = ('hicemuchafuerza', 0, 0)
                    lstComandosRealizados.append(comando)
                    break


# Se crea una funcion que regresa el juego al estado anterior.

def deshacerMovida():

    if len(lstComandosRealizados) > 0:
        comando = lstComandosRealizados.pop()
        if comando[0] == 'hicemuchafuerza':
            actualizarContadorDeElectricidad(-200)
            deshacerMovida()
        if comando[0] == 'borrar':
            borrarElemento(comando[1], comando[2])
            deshacerMovida()
        if comando[0] == 'virus':
            posicionarElemento(comando[0], comando[1], comando[2])
            actualizarContadorDeElectricidad(-5)
            deshacerMovida()
        if comando[0] == 'jugador':
            posicionarElemento(comando[0], comando[1], comando[2])
            actualizarContadorDePasos(-1)
            actualizarContadorDeElectricidad(-10)
            

# Se crea una funcion para resetear el juego.

def resetearJuego():
    global zonaDeTransporte, cantidadDeEnergia, cantidadDePasos, \
        lstComandosRealizados, segundos, sin_moverse, nivelCompletado

    zonaDeTransporte = crearZonaDeTransporte()
    cantidadDeEnergia = 7000
    cantidadDePasos = 0
    lstComandosRealizados[:] = []
    segundos = 0
    sin_moverse = 0
    nivelCompletado = False

    actualizarAmenazas()
    dibujarDatosDelJuego()


# Consigna 5 ... se incorporan mejoras.
# Se crea una funcion para escribir datos en un archivo.
# Se utiliza el formato estandar CSV (Comma Separated Values)
#  para almacenar los datos en el archivo.


def escribirEnArchivo(nombre, puntuacion):
    modo = 'a'

    if not os.path.isfile('puntuaciones.txt'):
        modo = 'w'

    with open('puntuaciones.txt', mode=modo) as csvFile:
        writer = csv.writer(csvFile, delimiter=',', lineterminator='\n')
        writer.writerow([nombre, str(puntuacion)])

    csvFile.close()

# Se crea una funcion para escribir en un archivo la puntuacion del jugador ganador.


def escribirPuntuacion():
    global cantidadDeEnergia, segundos, nivelCompletado

    if nivelCompletado is True:
        nombre = ingresar_nombre_jugador()
        puntuacion = cantidadDeEnergia / segundos
        escribirEnArchivo(nombre, puntuacion)
        resetearJuego()


# Se crea una funcion para resetear el juego si el nivel se completa o
#  si Super Tablet no tiene mas bateria.

def estaSinBateria():
    global cantidadDeEnergia

    if nivelCompletado is False and cantidadDeEnergia <= 0:
        resetearJuego()


print (" redes sociales, gonza insta: gonza.ds3, gaston instagram: gastonjua542, instagram luca el programador capo de la vida: https://www.instagram.com/dave__i.g/") 

# Creamos el bucle del juego

while not salirJuego:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            salirJuego = True

        if event.type == pygame.KEYDOWN and not nivelCompletado:
            if event.key == pygame.K_RIGHT:
                irALaDerecha()
                dibujarCartelRondaFinal()
            elif event.key == pygame.K_LEFT:
                irALaIzquierda()
                dibujarCartelRondaFinal()
            elif event.key == pygame.K_UP:
                irArriba()
                dibujarCartelRondaFinal()
            elif event.key == pygame.K_DOWN:
                irAbajo()
                dibujarCartelRondaFinal()
            elif event.key == pygame.K_x:
                deshacerMovida()
                VolverColor()
                

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_m:
                modoDeJuego = "movimientos"
                resetearJuego()
            elif event.key == pygame.K_t:
                modoDeJuego = "tiempo"
                resetearJuego()
            elif event.key == pygame.K_r:
                resetearJuego()
            elif event.key == pygame.K_q:
                salirJuego = True

            dibujarZonaDeTransporte()
            estaSolucionado()
            estaSinBateria()

        if event.type == pygame.USEREVENT + 1 and not nivelCompletado:
            actualizarTiempo()

        # Chequea si el juego llego a su fin por tiempo o cantidad de movimientos
        siFinDelJuego()

pygame.quit()
