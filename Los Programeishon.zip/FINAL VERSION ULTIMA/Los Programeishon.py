#!/usr/bin/env python
#-*- coding: utf-8 -*-
#Inicio Ronda Final - 2019
#La librería Pygame debe estar instalada junto a Python 2.7.13 para que el código se ejecute. 
#Si no lo está, ir en Windows a la aplicación Símbolo del Sistema y con una conexión activa a Internet ejecutar el comando pip install pygame 
#Escuela: María Sánchez de Thompson.
#Equipo: Los Programeishon. Equipo N° 14576
#Integrantes: Galeano Cristian, Miori Joaquín, Paolantonio Santiago
import pygame
import random
import time 

#Inicializamos la librería Pygame y demás variables
pygame.init()
pygame.font.init() 
pygame.mixer.music.load("musicaSinCopy.mp3")
pygame.mixer.music.play(-1)
pygame.display.set_caption("Maraton 2019 - Ronda Final")

#Añadimos las acciones para que se pudiera para, pausar y despausar la musica del juego.
def pararMusica():
    pygame.mixer.music.stop()

def musicaPause():
    pygame.mixer.music.pause()

def musicaUnpause():
    pygame.mixer.music.unpause()

#Mustra en pantalla la tecla a pulsar para efectuar distintas acciones.
def dibujarIndicacionesMusicales():
         textoComentario = tipografiaChiquita.render('Para detener la musica presione "S"', False, colorBlanco)
         ancho=270
         alto=46
         x=646
         y=170
         pygame.draw.rect(pantalla,colorVerde,(x,y,ancho,alto))
         pantalla.blit(textoComentario,(x+5,y,ancho,alto))
         pygame.display.update()

def dibujarIndicacionesMusicales2():
         textoComentario = tipografiaChiquita.render('Para pausar la musica presione "P"', False, colorBlanco)
         ancho=270
         alto=46
         x=646
         y=220
         pygame.draw.rect(pantalla,colorVerde,(x,y,ancho,alto))
         pantalla.blit(textoComentario,(x+5,y,ancho,alto))
         pygame.display.update() 


def dibujarIndicacionesMusicales3():
         textoComentario = tipografiaChiquita.render('Para despausar la musica presione "D"', False, colorBlanco)
         ancho=270
         alto=46
         x=646
         y=270
         pygame.draw.rect(pantalla,colorVerde,(x,y,ancho,alto))
         pantalla.blit(textoComentario,(x+5,y,ancho,alto))
         pygame.display.update()

def dibujarIndicacionSalir():
         textoComentario = tipografiaChiquita.render('Para salir del juego presione "Q"', False, colorBlanco)
         ancho=270
         alto=30
         x=646
         y=320
         pygame.draw.rect(pantalla,colorVerde,(x,y,ancho,alto))
         pantalla.blit(textoComentario,(x+5,y,ancho,alto))
         pygame.display.update()


#Muestra en pantalla el nivel actual.
def dibujarNivel():
        global nivel_actual
        textoComentario = tipografiaChiquita.render('Nivel:' + str(nivel_actual), False, colorBlanco)
        ancho=100
        alto=46
        x=646
        y=70
        pygame.draw.rect(pantalla,colorVerde,(x,y,ancho,alto))
        pantalla.blit(textoComentario,(x+5,y,ancho,alto))
        pygame.display.update()




pantalla= pygame.display.set_mode((1152,648))
tipografia = pygame.font.SysFont('Comic Sans MS', 18)
tipografiaGrande=pygame.font.SysFont('Comic Sans MS', 24)
tipografiaChiquita=pygame.font.SysFont('Comic Sans MS', 15)

global ticksAlComenzar
global cantidadDeEnergia
global lstComandosRealizados
global cantidadDePasos
global zonaDeTransporte
#Contador de niveles
global nivel_actual
global nivel_inicial
global nombre
nivel_actual=1
global estado_reinicia
estado_reinicia=False







 


def ingresaNombre(estado):
    global ticksAlcomenzar
    global cantidadDePasos
    global cantidadDeEnergia
    
    ticksAlComenzar=pygame.time.get_ticks()

    cantidadDePasos=0
    cantidadDeEnergia=7000
    if estado==True:
        ganaste = pygame.image.load("ganaste.png").convert()
        ganaste_rect = ganaste.get_rect()
        pygame.display.update()
        pantalla.blit(ganaste,ganaste_rect)
        pygame.display.flip()
        time.sleep(2)
        

        
        
    #INGRESAMOS EL NOMBRE
    global nombre   
    fuente = pygame.font.Font('freesansbold.ttf', 52)

    #se setea el texto a mostrar en una variable
    nombre=""

    #luego se crea una variable que contendra el mensaje y el color en este caso blanco (255,255,255)
    Entrar=True

#Agregamos una pantalla inicial en la cual escribes tu nombre y aparecen las instrucciones del juego
    background = pygame.image.load("fondo_sin_copy.png").convert()
    background_rect = background.get_rect()
    pygame.display.update()
    pantalla.blit(background, background_rect)


    #se actualiza la ventana.

    pygame.display.flip()
    Mayuscula=False
    while Entrar:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if pygame.key.name(event.key)=="return" or pygame.key.name(event.key)=="enter" or len(nombre)>8:
                    Entrar=False
                    break
                                
                if event.key==pygame.K_RSHIFT: #Verifica que si se presiono shift y una letra, la letra presionada se convierte en mayuscula.
                    
                    Mayuscula=True
                if pygame.key.name(event.key).isalpha(): 
                    
                    if Mayuscula==True:
                        
                        
                        nombre=nombre+pygame.key.name(event.key).upper()
                        
                        Mayuscula=False
                    else:
                        
                        nombre=nombre+pygame.key.name(event.key)
                        
                    mensaje = fuente.render(nombre, False, (255,100,0),(255,202,24))

                                
                    #se muestra en el screen el mensaje en la posicion x,y (15,10).
                    pantalla.blit(mensaje, (400, 300))

                    #se actualiza la ventana.
                    pygame.display.flip()
    
ingresaNombre(estado_reinicia)
tipografia = pygame.font.SysFont('Comic Sans MS', 18)
tipografiaGrande=pygame.font.SysFont('Comic Sans MS', 24)






ticksAlComenzar=pygame.time.get_ticks()

cantidadDePasos=0
cantidadDeEnergia=7000
colorVerde=(1,102,35)
colorAzul=(0,0,255)
colorBlanco=(255,255,255)
colorNegro=(0,0,0)
colorNaranja=(239,27,126)
listaColores=[(1,102,35), (0,0,255), (255,255,255), (0,0,0), (139, 37, 0, 255), (139, 34, 82, 255), (41, 41, 41, 255), (238, 238,  0, 255)] 
color1 = random.choice(listaColores)




cantidadDeCasillasPorLado=8 #Debe ser número par ya que la zona es un cuadrado.
cantPixelesPorLadoCasilla=72
salirJuego = False
lstAreaProtegida=[]
lstComandosRealizados=[]















#Cargamos las imágenes
imgSuperTablet=pygame.image.load("supertablet.png")					#Imagen de supertablet cuando esta inmovil.
imgSuperTabletIzq=pygame.image.load("supertablet_izq.png")			#Imagen de supertablet empujando hacia la izquierda.
imgSuperTabletDch=pygame.image.load("supertablet_dch.png")          #Imagen de supertablet empujando hacia la derecha.
imgSuperTabletArr=pygame.image.load("supertablet_arr.png")          #Imagen de supertablet empujando hacia arriba.
imgSuperTabletAbj=pygame.image.load("supertablet_abj.png")          #Imagen de supertablet empujando hacia abajo.
imgSuperTabletIzqF=pygame.image.load("supertablet_izq_fuerza.png")  #Imagen de supertablet empujando fuertemente hacia la izquierda.
imgSuperTabletDchF=pygame.image.load("supertablet_dch_fuerza.png")  #Imagen de supertablet empujando fuertemente hacia la derecha.
imgSuperTabletArrF=pygame.image.load("supertablet_arr_fuerza.png")  #Imagen de supertablet empujando fuertemente hacia arriba.
imgSuperTabletAbjF=pygame.image.load("supertablet_abj_fuerza.png")  #Imagen de supertablet empujando fuertemente hacia abajo.
imgPared=pygame.image.load("pared.png")#Imagen de la pared circundante.
imgAreaProtegida=pygame.image.load("areaprotegida.png")#Imagen del area protegida.
listaAmenazas  = ["amenaza1.png","amenaza2.png","amenaza3.png","amenaza4.png"]#Imagenes de los distintos virus.
imgAmenaza=pygame.image.load(str(random.choice(listaAmenazas)))#Variable que realiza un proceso de seleccionar una imagen aleatoriamente y cargarla desde listaAmenazas.
#Definimos variables, en las cuales se transforman las dimensiones de algunas imagenes para que se adapte al tamaño de cada casilla.
imgSuperTablet=pygame.transform.scale(imgSuperTablet, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
imgPared=pygame.transform.scale(imgPared, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
imgAmenaza=pygame.transform.scale(imgAmenaza, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
imgAreaProtegida=pygame.transform.scale(imgAreaProtegida, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))

#Creamos el mapa del nivel y algunas operaciones para los elementos que se encuentran dentro de la zona de transporte.




def crearZonaDeTransporte():
    
    global nivel_actual
    restar=0
        
    zonaDeTransporte = [[0 for x in range(cantidadDeCasillasPorLado+1)] for y in range(cantidadDeCasillasPorLado+1)] 


    if nivel_actual<4:
        zonaDeTransporte[1][0+nivel_actual] = 'pared'
        zonaDeTransporte[2][0+nivel_actual] = 'pared'
        zonaDeTransporte[3][0+nivel_actual] = 'pared'
        zonaDeTransporte[4][0+nivel_actual] = 'pared'
        zonaDeTransporte[5][0+nivel_actual] = 'pared'
        zonaDeTransporte[6][0+nivel_actual] = 'pared'
        zonaDeTransporte[7][0+nivel_actual] = 'pared'
        zonaDeTransporte[8][0+nivel_actual] = 'pared'
    else:
        zonaDeTransporte[1][2] = 'pared'
        zonaDeTransporte[2][2] = 'pared'
        zonaDeTransporte[3][2] = 'pared'
        zonaDeTransporte[4][2] = 'pared'
        zonaDeTransporte[5][2] = 'pared'
        zonaDeTransporte[6][2] = 'pared'
        zonaDeTransporte[7][2] = 'pared'
        zonaDeTransporte[8][2] = 'pared'
        
    zonaDeTransporte[1][7] = 'pared'
    zonaDeTransporte[2][7] = 'pared'
    zonaDeTransporte[3][7] = 'pared'
    zonaDeTransporte[4][7] = 'pared'
    zonaDeTransporte[5][7] = 'pared'
    zonaDeTransporte[6][7] = 'pared'
    zonaDeTransporte[7][7] = 'pared'
    zonaDeTransporte[8][7] = 'pared'

    zonaDeTransporte[1][4] = 'pared'
    zonaDeTransporte[1][5] = 'pared'
    zonaDeTransporte[1][6] = 'pared'
    zonaDeTransporte[8][4] = 'pared'
    zonaDeTransporte[8][5] = 'pared'
    zonaDeTransporte[8][6] = 'pared'
    zonaDeTransporte[2][5] = 'jugador'
    #Creamos las distintas zonas de tranporte, la cual cambiará dependiendo del nivel en el cual te encuentres, que se define con una variable global.
    #[x][y]
    if nivel_actual==1 or nivel_actual==4: #Si el nivel es 1 o 4 armamos el tablero.
        zonaDeTransporte[1][2] = 'pared'
        zonaDeTransporte[8][2] = 'pared'
        zonaDeTransporte[1][3] = 'pared'
        zonaDeTransporte[8][3] = 'pared'
        zonaDeTransporte[4][5] = 'virus'    
        zonaDeTransporte[5][5] = 'virus'    
        zonaDeTransporte[6][5] = 'virus' 
        zonaDeTransporte[5][6] = 'virus'
        if nivel_actual==4:
            zonaDeTransporte[4][3] = 'pared'
            zonaDeTransporte[6][3] = 'pared'
            zonaDeTransporte[3][5] = 'virus'      

        else:
            zonaDeTransporte[4][2] = 'pared'
            zonaDeTransporte[5][3] = 'pared'
            zonaDeTransporte[6][3] = 'virus'      

        
    #Creamos otra condicion (si el nivel actual es igual a dos, el segundo nivel, se va a proceder a cargar esta zona de transporte mas la original)
    #Seguimos este patron con las siguientes condiciones.
    elif nivel_actual==2 or nivel_actual==5: #Si el nivel es 2 o 5 armamos el tablero.
        zonaDeTransporte[1][3] = 'pared'
        zonaDeTransporte[8][3] = 'pared'
             
        zonaDeTransporte[4][5] = 'virus'    
        zonaDeTransporte[5][5] = 'virus'    
        zonaDeTransporte[6][5] = 'virus' 
   
        if nivel_actual==5:
            zonaDeTransporte[3][5] = 'virus' 
            zonaDeTransporte[7][5] = 'pared'
            zonaDeTransporte[3][6] = 'pared'
            restar=2
        else:
            zonaDeTransporte[3][4] = 'virus' 
        zonaDeTransporte[5][6-restar] = 'virus'
            
    elif nivel_actual==3:
        zonaDeTransporte[1][3] = 'pared'
        zonaDeTransporte[8][3] = 'pared'
        zonaDeTransporte[3][5] = 'virus'      
        zonaDeTransporte[4][5] = 'virus'    
        zonaDeTransporte[5][5] = 'virus'    
        zonaDeTransporte[6][5] = 'virus' 
        zonaDeTransporte[5][6] = 'virus'
        
    elif nivel_actual==4:
        zonaDeTransporte[3][5] = 'virus'      
        zonaDeTransporte[4][5] = 'virus'    
        zonaDeTransporte[5][5] = 'virus'    
        zonaDeTransporte[6][5] = 'virus' 
        zonaDeTransporte[5][6] = 'virus' 
   

 
 
         
     #Se le asigna una posicion en el mapa a las areas protegidas.
    
        

    lstAreaProtegida.append((2,4))
    lstAreaProtegida.append((2,6))
    lstAreaProtegida.append((7,4))
    lstAreaProtegida.append((7,6))
    lstAreaProtegida.append((4,6))
    
    return zonaDeTransporte

zonaDeTransporte=crearZonaDeTransporte()

def hayAreaProtegidaEn(x,y):
    punto=(x,y)
    return lstAreaProtegida.__contains__(punto)

def posicionarElemento(elemento,x,y): 
    global zonaDeTransporte
    zonaDeTransporte[x][y]=elemento

def borrarElemento(x,y):
    global zonaDeTransporte
    zonaDeTransporte[x][y]=0
    
#Dibujamos la zona de transporte, fondo y reglas
def dibujarZonaDeTransporte():     
    global zonaDeTransporte
    cnt = 0
    for i in range(1,cantidadDeCasillasPorLado+1):
        for j in range(1,cantidadDeCasillasPorLado+1):
            if cnt % 2 == 0:
                pygame.draw.rect(pantalla, colorVerde,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
            else:
                pygame.draw.rect(pantalla, colorVerde, [cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])        

            if (hayAreaProtegidaEn(j,i)==True):
                pantalla.blit(imgAreaProtegida, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i)) 
            if (zonaDeTransporte[j][i]=='jugador'):
               pantalla.blit(imgSuperTablet, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i)) 
            if (zonaDeTransporte[j][i]=='pared'):          
               pantalla.blit(imgPared, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
            if (zonaDeTransporte[j][i]=='virus'):
               pantalla.blit(imgAmenaza, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
            cnt +=1
        cnt-=1

    pygame.draw.rect(pantalla,colorBlanco,[cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla,cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla,cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla],1)       
    pygame.display.update()
 
#Se asigna una imagen de fondo para la ventana del juego.   
def dibujarFondo():
    fondo = pygame.image.load("fondo.png")
    pantalla.blit(fondo, (0, 0))
    
#Creamos una funcion para explicar la jugabilidad (la cual crea recuadros de texto, con la tipografia render).
    
def dibujarReglas():

    textoReglas = tipografia.render('Mover a Super Tablet con las flechas del teclado para que lleve los virus a las zonas protegidas.', False, colorBlanco)
    textoReglas2 = tipografia.render('X-Deshace la movida. R-Reinicia el nivel.', False, colorBlanco)

    ancho=810
    alto=46
    x=340
    y=3
    pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
    pantalla.blit(textoReglas,(x+5,y,ancho,alto))
    
    y=35
    alto=35

    pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
    pantalla.blit(textoReglas2,(x+5,y,ancho,alto))
    
    pygame.display.update()

#Actualizamos el contador de segundos jugados, pasos de Super Tablet y el contador de energía
def actualizarTiempoDeJuego():
    global segundos
    ancho=350
    alto=40
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=cantPixelesPorLadoCasilla*8
    pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
    textoSegundos = tipografiaGrande.render('Segundos transcurridos: ' + str(segundos), False, colorBlanco)
    pantalla.blit(textoSegundos,(x+5,y,ancho,alto))
    pygame.display.update()

def actualizarContadorDePasos(num):
    global cantidadDePasos
    cantidadDePasos=cantidadDePasos+num
    ancho=350
    alto=40
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=cantPixelesPorLadoCasilla*7
    pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
    textoPasos = tipografiaGrande.render('Cantidad de movimientos: ' + str(cantidadDePasos), False, colorBlanco)
    pantalla.blit(textoPasos,(x+5,y,ancho,alto))
    pygame.display.update()

def actualizarContadorDeElectricidad(num):
    global cantidadDeEnergia

    cantidadDeEnergia=cantidadDeEnergia-num    
    ancho=550
    alto=40
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=cantPixelesPorLadoCasilla*6
    pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
    textoEnergia = tipografiaGrande.render('Bateria disponible de Super Tablet: ' + str(cantidadDeEnergia) + 'mA', False, colorBlanco)
    pantalla.blit(textoEnergia,(x+5,y,ancho,alto))
    pygame.display.update()

#Creamos una funcion para crear un recuadro, en el cual aparece escrito el tiempo que estuvo quieto supertablet.
def actualizarTiempoSinPasos(num):
    global cantidadDeEnergia

  
    ancho=550
    alto=40
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=cantPixelesPorLadoCasilla*5
    pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
    textoEnergia = tipografiaGrande.render('Tiempo Quieto de SuperTablet: ' + str(num) + ' Segundos', False, colorBlanco)
    pantalla.blit(textoEnergia,(x+5,y,ancho,alto))
    pygame.display.update()

    
#Creamos operaciones para mostrar la felicitación y el cartel de ronda final
def dibujarFelicitacion():
    global nivelCompletado
    global nivel_actual
    x=50
    y=3
    ancho=275
    alto=46
    
    if (nivelCompletado==True) and nivel_actual==5:
        textoFelicitacion = tipografiaGrande.render('GANASTE :)', False, colorBlanco)
    elif (nivelCompletado==True):
        textoFelicitacion = tipografiaGrande.render('PASASTE DE NIVEL! :)', False, colorBlanco)
    else:
        textoFelicitacion = tipografiaGrande.render(nombre+' esta jugando!', False, colorBlanco)
    
    pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
    pantalla.blit(textoFelicitacion,(x+5,y,ancho,alto))
    pygame.display.update()

def dibujarCartelRondaFinal():
    textoFelicitacion = tipografiaGrande.render('Ronda final', False, colorNaranja)
    
    ancho=160
    alto=46
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=120
    pygame.draw.rect(pantalla,color1,(x,y,ancho,alto))
    pantalla.blit(textoFelicitacion,(x+5,y,ancho,alto))
    pygame.display.update()

#Creamos operaciones relacionadas con la tabla de marcadores
def obtener5QueJugaronPrimero():
  file = open("puntuaciones.txt", "r")
  lstPuntuaciones=[]

  nombreAgregado=False
  par=[]
      
  lineas= file.readlines()
  
  lineas = [line.strip() for line in open('puntuaciones.txt')]
  
  
  for line in lineas:
    
    if not (line==''):
        if (nombreAgregado==False):
            par=[]
            par.append(line)
            nombreAgregado=True
            
        else:    
            par.append(int(line))
            lstPuntuaciones.append(par)
            nombreAgregado=False

  
  
  lstPuntuaciones= sorted(lstPuntuaciones,key=lambda lstPuntuaciones:lstPuntuaciones[1],reverse=True) #PAL  --> Punto 1

  lstPuntuaciones = lstPuntuaciones[:5]

  file.close() 
  
  return lstPuntuaciones

#Creamos una operación que dibuje a los cinco que jugaron primero
def dibujar5QueJugaronPrimero():
    lst5Jugadores=obtener5QueJugaronPrimero()
    ancho=220
    alto=40
    x=350+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    i=8
     
    for par in lst5Jugadores:
        y=(32*i)-135
        textoRanking = tipografiaGrande.render(str(par[0]) + ': ' + str(par[1]), False, colorBlanco)
        pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
        pantalla.blit(textoRanking,(x+5,y,ancho,alto))
        i=i+1
       
    pygame.display.update()
    
#Creamos una operación que dibuje todo
def dibujarTodo():
    dibujarFondo()
    dibujarZonaDeTransporte()
    dibujarCartelRondaFinal()
    dibujarReglas()
    dibujar5QueJugaronPrimero()
    dibujarIndicacionesMusicales()
    dibujarIndicacionesMusicales2()
    dibujarIndicacionesMusicales3()
    dibujarNivel()
    dibujarIndicacionSalir()
    pygame.display.update()

dibujarTodo()

#Creamos una operación que indique si el nivel fue solucionado
def estaSolucionado():
    global nivelCompletado
    global zonaDeTransporte
    global nivel_actual #nivel del juego
    cantVirusSobreAreasProtegidas=0

    for punto in lstAreaProtegida:
        x=punto[0]
        y=punto[1]
        if zonaDeTransporte[x][y]=='virus':
            cantVirusSobreAreasProtegidas=cantVirusSobreAreasProtegidas+1       

    if (cantVirusSobreAreasProtegidas==len(lstAreaProtegida)):
        nivelCompletado=True
        dibujarFelicitacion()
        nivel_actual=nivel_actual+1 #Suma nivel
       

    else:
        nivelCompletado=False

    dibujarFelicitacion()
    dibujarCartelRondaFinal()
    dibujarReglas()
    escribirPuntuacion()
    
#Creamos operaciones para mover a Super Tablet
def irALaDerecha():
    global zonaDeTransporte
    global imgSuperTablet 
    for i in range(1,cantidadDeCasillasPorLado):
        for j in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                if (zonaDeTransporte[j+1][i]==0):
                    posicionarElemento('jugador',j+1,i)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(10)
                    borrarElemento(j,i)
                    comando=('jugador',j,i)       
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j+1,i)       
                    lstComandosRealizados.append(comando)
                    pygame.mixer.Channel(1).play(pygame.mixer.Sound("mover.wav"))
                    color1 = random.choice(listaColores) 
                    break
                if(zonaDeTransporte[j+1][i]=='virus') and not ((zonaDeTransporte[j+2][i]=='pared') or (zonaDeTransporte[j+2][i]=='virus')):
                    imgSuperTablet=pygame.transform.scale(imgSuperTabletDch, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))#PAL
                    posicionarElemento('virus',j+2,i)
                    posicionarElemento('jugador',j+1,i)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(15)
                    borrarElemento(j,i)
                    comando=('jugador',j,i)       
                    lstComandosRealizados.append(comando)
                    comando=('virus',j+1,i)
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j+1,i)       
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j+2,i)       
                    lstComandosRealizados.append(comando)
                    pygame.mixer.Channel(1).play(pygame.mixer.Sound("mover.wav"))
                    
                    
                    break
                if(zonaDeTransporte[j+1][i]=='virus') and (zonaDeTransporte[j+2][i]=='virus'):
                    imgSuperTablet=pygame.transform.scale(imgSuperTabletDchF, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))#PAL
                    actualizarContadorDeElectricidad(200)  
                    comando=('hicemuchafuerza',0,0)
                    lstComandosRealizados.append(comando) 
                    break
    
    
def irArriba():
    global zonaDeTransporte
    global lstComandosRealizados
    global imgSuperTablet 
    for i in range(1,cantidadDeCasillasPorLado):
        for j in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                if (zonaDeTransporte[j][i-1]==0):
                    posicionarElemento('jugador',j,i-1)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(10)
                    borrarElemento(j,i)
                    comando=('jugador',j,i)       
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j,i-1)       
                    lstComandosRealizados.append(comando)
                    pygame.mixer.Channel(1).play(pygame.mixer.Sound("mover.wav"))
                    color1 = random.choice(listaColores)
                    break
                if(zonaDeTransporte[j][i-1]=='virus') and not ((zonaDeTransporte[j][i-2]=='pared') or (zonaDeTransporte[j][i-2]=='virus')):
                    imgSuperTablet=pygame.transform.scale(imgSuperTabletArr, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
            
                    posicionarElemento('virus',j,i-2)
                    posicionarElemento('jugador',j,i-1)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(15)
                    borrarElemento(j,i)
                    comando=('jugador',j,i)       
                    lstComandosRealizados.append(comando)
                    comando=('virus',j,i-1)
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j,i-1)       
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j,i-2)       
                    lstComandosRealizados.append(comando)
                    pygame.mixer.Channel(1).play(pygame.mixer.Sound("mover.wav"))
                    break
                if(zonaDeTransporte[j][i-1]=='virus') and (zonaDeTransporte[j][i-2]=='virus'):
                    imgSuperTablet=pygame.transform.scale(imgSuperTabletArrF, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))#PAL 
                    actualizarContadorDeElectricidad(200)  
                    comando=('hicemuchafuerza',0,0)
                    lstComandosRealizados.append(comando) 
                    break

def irAbajo():
    global zonaDeTransporte
    global imgSuperTablet 
    for j in range(1,cantidadDeCasillasPorLado):
        for i in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                if (zonaDeTransporte[j][i+1]==0):
                    posicionarElemento('jugador',j,i+1)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(10)
                    borrarElemento(j,i)
                    comando=('jugador',j,i)       
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j,i+1)       
                    lstComandosRealizados.append(comando)
                    pygame.mixer.Channel(1).play(pygame.mixer.Sound("mover.wav"))
                    break
                if(zonaDeTransporte[j][i+1]=='virus') and not ((zonaDeTransporte[j][i+2]=='pared') or (zonaDeTransporte[j][i+2]=='virus')):
                    imgSuperTablet=pygame.transform.scale(imgSuperTabletAbj, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))#PAL

                    posicionarElemento('virus',j,i+2)
                    posicionarElemento('jugador',j,i+1)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(15)
                    borrarElemento(j,i)
                    comando=('jugador',j,i)       
                    lstComandosRealizados.append(comando)
                    comando=('virus',j,i+1)
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j,i+1)       
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j,i+2)       
                    lstComandosRealizados.append(comando)
                    pygame.mixer.Channel(1).play(pygame.mixer.Sound("mover.wav"))
                    break
                if(zonaDeTransporte[j][i+1]=='virus') and (zonaDeTransporte[j][i+2]=='virus'):
                    imgSuperTablet=pygame.transform.scale(imgSuperTabletAbjF, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))#PAL
                    actualizarContadorDeElectricidad(200)  
                    comando=('hicemuchafuerza',0,0)
                    lstComandosRealizados.append(comando) 
                    break
        
def irALaIzquierda():
    global zonaDeTransporte
    global imgSuperTablet 
    for i in range(1,cantidadDeCasillasPorLado):
        for j in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                if (zonaDeTransporte[j-1][i]==0):
                    posicionarElemento('jugador',j-1,i)              
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(10)
                    borrarElemento(j,i)
                    comando=('jugador',j,i)       
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j-1,i)       
                    lstComandosRealizados.append(comando)
                    pygame.mixer.Channel(1).play(pygame.mixer.Sound("mover.wav"))
                    break
                if(zonaDeTransporte[j-1][i]=='virus') and not ((zonaDeTransporte[j-2][i]=='pared') or (zonaDeTransporte[j-2][i]=='virus')):
                    imgSuperTablet=pygame.transform.scale(imgSuperTabletIzq, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))#PAL

                    posicionarElemento('virus',j-2,i)
                    posicionarElemento('jugador',j-1,i)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(15)
                    comando=('jugador',j,i)       
                    lstComandosRealizados.append(comando)
                    comando=('virus',j-1,i)
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j-1,i)       
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j-2,i)       
                    lstComandosRealizados.append(comando)               
                    borrarElemento(j,i)
                    pygame.mixer.Channel(1).play(pygame.mixer.Sound("mover.wav"))
                    break
                if(zonaDeTransporte[j-1][i]=='virus') and (zonaDeTransporte[j-2][i]=='virus'):
                    imgSuperTablet=pygame.transform.scale(imgSuperTabletIzqF, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))

                    actualizarContadorDeElectricidad(200)
                    comando=('hicemuchafuerza',0,0)
                    lstComandosRealizados.append(comando) 
                    break

#Creamos una operación que vuelva hacia atrás la última movida.
def deshacerMovida():
    global zonaDeTransporte
    global cantidadDePasos

    if (len(lstComandosRealizados)>0):  
        comando=lstComandosRealizados.pop()
        if (comando[0]=='hicemuchafuerza'):
            actualizarContadorDeElectricidad(-200)
            deshacerMovida()
        if (comando[0]=='borrar'):
            borrarElemento(comando[1],comando[2])
            deshacerMovida()
        if (comando[0]=='virus'):
            posicionarElemento(comando[0],comando[1],comando[2])  
            actualizarContadorDeElectricidad(-5)
            deshacerMovida() 
        if (comando[0]=='jugador'):
            posicionarElemento(comando[0],comando[1],comando[2])
            actualizarContadorDePasos(-1)  
            actualizarContadorDeElectricidad(-10)
    dibujarZonaDeTransporte()

#Creamos una operación para resetear el juego 
def resetearJuego():
    global zonaDeTransporte, cantidadDeEnergia, cantidadDePasos, lstComandosRealizados, ticksAlComenzar
    zonaDeTransporte=crearZonaDeTransporte()
    cantidadDePasos=0
    if nivel_actual<6:
        cantidadDeEnergia=7000
    ticksAlComenzar=pygame.time.get_ticks()
    segundos=0
    lstComandosRealizados[:] = []
    dibujarTodo()

#Creamos una operación para escribir en una archivo
def escribirEnArchivo(nombre, puntuacion):
    file = open("puntuaciones.txt", "a")
    file.write(nombre)
    file.write('\n')
    file.write(str(puntuacion))
    file.write('\n')
    file.close()

#Creamos una operación para escribir la puntuación
def escribirPuntuacion():
    global cantidadDeEnergia, segundos, nivelCompletado,nivel_actual
   
    if (nivelCompletado==True): 
        #nombre = raw_input("Ingrese su nombre")

       



        
        puntuacion= cantidadDeEnergia / segundos

        if(nivel_actual>5): #solo escribe score de quienes completan el nivel 5 final
            escribirEnArchivo(nombre, puntuacion)
            nivel_actual=1
            ingresaNombre(True)
        resetearJuego()


#Creamos una operación para resetear el juego si el nivel se completa o si Super Tablet no tiene más batería
def estaSinBateria():
    global cantidadDeEnergia
    if (nivelCompletado==False) and (cantidadDeEnergia<=0):
        resetearJuego()

#Creamos el bucle del juego
# PAL - punto 2
global ticksparado
ticksparado=pygame.time.get_ticks()
# LAP

while not salirJuego:

    segundos=(pygame.time.get_ticks()-ticksAlComenzar)/1000
    #PAL - punto 2
    segundos_parado=(pygame.time.get_ticks()-ticksparado)/1000
    if segundos_parado==15:
        ticksparado=pygame.time.get_ticks() 
        resetearJuego()
    else:
        actualizarTiempoSinPasos(segundos_parado)
    #LAP
    actualizarTiempoDeJuego()
    imgSuperTablet=pygame.image.load("supertablet.png")#pal
    imgSuperTablet=pygame.transform.scale(imgSuperTablet, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla)) 
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            salirJuego = True
        if event.type == pygame.KEYDOWN:
            ticksparado=pygame.time.get_ticks() #Aca tomamos el tiempo desde el ultimo movimiento de supertablet

            if event.key == pygame.K_RIGHT:
     
                irALaDerecha()
                color1 = random.choice(listaColores)
            elif event.key == pygame.K_LEFT:
                color1 = random.choice(listaColores)
                irALaIzquierda()

            elif event.key == pygame.K_s:

                pararMusica()

            elif event.key == pygame.K_q:
                

                salirJuego = True

            elif event.key == pygame.K_p:

                musicaPause()

            elif event.key == pygame.K_d:

                musicaUnpause()
                
            elif event.key == pygame.K_UP:
                
                color1 = random.choice(listaColores)
                irArriba()
            elif event.key == pygame.K_DOWN:
                color1 = random.choice(listaColores)
                irAbajo()
            elif event.key == pygame.K_x:
                deshacerMovida()
                
            elif event.key == pygame.K_r:
                resetearJuego()

   
        dibujarZonaDeTransporte()
        estaSolucionado()
        estaSinBateria()
        
pygame.quit()

