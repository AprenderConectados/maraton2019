#!/usr/bin/env python
#-*- coding: utf-8 -*-
#Inicio Ronda Final - 2019
                                #ELASTIGIRLS#
                    #LAS AVENTURAS DE APITRANSFORMER#
#ESCUELA EXPERIMENTAL CON ENFASIS EN TECNOLOGIAS DE LA INFORMACION Y LA COMUNICACION#
                    #PROA SEDE VILLA CARLOS PAZ#
                #FECHA DE ENTREGA: 18 DE SEPTIEMBRE DE 2018#

#Este juego trata de consientizar a los niños sobre lo que implica la seguridad de navegar en internet,
# redes sociales, etc. Actualmente las personas, en este caso niños pasan la mayor parte de tiempo jugando,
# navegando en internet, redes sociales y casi nadie sabe sobre la inseguridad que esto implica.
# Internet puede ser muy bien usado, pero tambien lo usan para el mal.

#PARTICIPANTES:
    #Luisina Lavayen
    #Antonella Monteleone
    #Melanie Schmidlin

#PROFESOR:
    #Marco Locati

#VERSIONES:
               # 1.0 : REALIZAMOS LAS CONSIGNAS BASE QUE SERAN EVALUADAS:
                          # - primero relizamos un contador de segundos para que cuando la tablet pase mas de 15 segundos sin moverse que el juego se reinice.
                          # - Realizamos otro nivel al que llamamos "Nivel espejo" que tiene os controles invertidos.
                          # - Realizamos otros niveles con mas dificultad.
               # 1.1:Creamos nuevos fondos, iconos, virus, supertablet, pared en el software PAINT.
               # 1.2: Incorporamos el fondo y una introduccion a el juego contando la historia sobre los Digi Amigos.
               # 1.3: Incorporamos nuevos virus y una nueva super tablet para complementar el juego.
               # 1.4: Incorporamos la nueva pared y un menú que tiene las opciones de cambiar el idioma y una opcion para ver mas información.
               # 1.5: Realizamos un cartel que nos indique cuando el juego se esta reiniciando.
               # 1.6: Decidimos calcular el puntaje acumulando la cantidad de energia restante de cada nivel divido el tiempo que se demoro en solucionar los tres niveles
               # 1.7: Se cambió "Juego en curso" por "Jugando NIVEL ..."

               # 2.0: Chicos de 1er año  probaron el juego, detectaron bugs, estos fueron arreglados.
               # 2.1: Reemplazamos todos los clear()de las listas por while len(lstEjemplo)>0:
                                    #lstEjemplo.pop()
                    #para que sea compatible con python 2.7

#Importamos liberias necesarias para el desarrollo del videojuego.

import pygame

import random

import time #importamos la librería "time" para poder calcular el tiempo actual en el juego

from math import * #importamos la librería "math" para poder utilizar funciones como "pow" o "sqrt" al momento de querer hacer el botón que desactiva la música


#Inicializamos la librería Pygame y demás variables
pygame.init()
pygame.font.init()

#Musica#
pygame.mixer.music.load("MUSICA/musica.ogg") #Insertamos la musica para el juego.
pygame.mixer.music.play(-1)

#Sonido#
sonidoMovimiento=pygame.mixer.Sound("SONIDO/movimiento.ogg")#creamos  un sonido que se  reproduce cada vez que el personaje se mueve

#Configuración de ventana#
pygame.display.set_caption("Maraton de Programacion y Robotica 2019 - RONDA FINAL") #nombre de la barra de títulos de la ventana.
pantalla= pygame.display.set_mode((1152,648)) #Tamaño de la pantalla

#Creamos Tipografias#
textoTime = pygame.font.SysFont('Comic Sans MS', 22)

tipografia = pygame.font.SysFont('Comic Sans MS', 18)

tipografiaGrande=pygame.font.SysFont('Gabriela Normal', 24)

tipografiaNivelEspejo = pygame.font.SysFont('Gabriela Normal',19)#Creamos una tipografia para avisar cuando el nivel tiene los controles invertidos.

tipografiaInstrucciones=pygame.font.SysFont('Bauhaus 93',48)#Creamos una tipografia para explicar como jugar.

tipografiaInstrucciones2=pygame.font.SysFont('Gabriela Normal',45)#Creamos otra tipografia para explicar como jugar.

tipografiaRondaFinal=pygame.font.SysFont('Gabriela Normal',40) #Tipografia creada para el cartel de ronda final.

tipografiaMenu=pygame.font.SysFont('Gabriela Normal',48) #Creamos una tipografia para el menú.

tipografiaReinicio=pygame.font.SysFont ('Gabriela Normal', 38)


#VARIABLES GLOBALES#

global nivel#Creamos una variable para contar los niveles y la inicializamos en 1.
nivel=1

global tr #Creamos una variable para contar el tiemmpo transcurrido desde que el personaje no se mueve. Luego lo inicializamos en 0.
tr=0

global juegoCompletado
juegoCompletado=False

global idiomaIngles
idiomaIngles=False

global cantidadDePasos#Creamos una variable para contar la cantidad de pasos.
global cantidadDeEnergia
global principio#Creamos una variable que sirve para contar el tiempo cuando se inicia el juego, asi sabiendo lugo el tiempo actual.
global mostrarPantalla#Creamos una variable que nos permite saber si la pantalla esta siendo mostrada o no, asi luego permitiendonos que salgamos o no del menu principal.

global lstEstados #Creamos una variable que nos permite guardar los pasos que realiza el jugador, así despues pudiendo usar la funcion "retroceder"
lstEstados = []

global deshaciendo  #Creamos una variable que sera utilizada para poder volver atrás un movimiento
deshaciendo = False #inicializamos la variable anterior como "False"

global ingresarNombre #creamos las siguientes dos variables para que se pueda ingresar un nombre al ganar el juego y luego a una de ellas la declaramos vacia

global nombre
nombre = ''

global quinceSegs #creamos una variable para que registre cuando el jugador se mueva, asi ayudando a una fucion proximamente creada para que cuando el jugador se quede quede quieto por mas de 15 segundos.
global sonidoActivado #Creamos la variable "sonidoActivado" para comprobar si el sonido esta activado o no, asi sabiendo que hacer cundo se precione el boton mute. #Creamos la variabe "menuActivado" para comprobar si el menu estaba aberto o no, asi sabiendo que hacer cuando este abierto o no.

global tabletMujerActivada#Creamos la variable "tabletActivada" para saber cuando hay que mostrar la tablet hombre y cuando hay que mostrar la tablet mujer, asi pudiendo cambiar el personaje.
tabletMujerActivada= False #Variable para que se sepa qué supertablet esta en el tablero o en el menu

global cambiarTablet
cambiarTablet=True

global puntaje
puntaje = 0

global guardePuntaje
guardePuntaje = False

#creamos una variable que nos permite almacenar el nivel de azul aleatoriamente, para asi utilizarlo en una funcion propiamente dicha.
global nivelDeAzul
nivelDeAzul=0

global lstColores
lstColores=["0","150","255"]

#Variables generales
sonidoActivado=True #Inicializamos a "sonido activado" en "True"
ingresarNombre = True  #hicimos que la variable "ingresar nombre" sea "True"
cantidadDePasos=0#Inicializamos la variable en 0
cantidadDeEnergia=7000#Inicializamos la variable "cantidadDeEnergia" en 7000, asi luego decrementandola con una funcion.
colorVerde,colorAzul,colorBlanco,colorNegro, colorNaranja,colorCrema,otroCol,colorGris,otro,color,colorRojo= (11,102,35),(0,0,255),(255,255,255),(0,0,0),(239,27,126),(255,114,86 ),(249,200,114),(100,100,100),(255,200,255),(27,101,99),(255,0,0) #Creamos algunos colores basandonos en la escala de colores de paint.
cantidadDeCasillasPorLado=8 #Debe ser número par ya que la zona es un cuadrado
cantPixelesPorLadoCasilla=72
salirJuego = False #creamos y pusimos en "False" a la variable "salirJuego" que se utiliza para que se pueda salir del juego cuando uno ya ganó
lstAreaProtegida=[]
lstzonaDeTransporte=[]
menuActivado = False #Inicializamos la variable "menuActivado" para saber cuando hay que hacer aparecer distintos iconos en el menu.
distanciaTablet=0

#CARGAMOS IMAGENES#
imgPared=pygame.image.load("IMAGENES/pared.png")
listaAmenazas  = ["IMAGENES/amenaza1.png","IMAGENES/amenaza2.png","IMAGENES/amenaza3.png","IMAGENES/amenaza4.png","IMAGENES/virus 1.png","IMAGENES/virus 2.png","IMAGENES/virus 3.png"]
imgAmenaza=pygame.image.load(str(random.choice(listaAmenazas)))
imgAreaProtegida=pygame.image.load("IMAGENES/areaprotegida.png")

#Transformacion de imagen a escala del cuadrado.
imgPared=pygame.transform.scale(imgPared, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
imgAmenaza=pygame.transform.scale(imgAmenaza, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
imgAreaProtegida=pygame.transform.scale(imgAreaProtegida, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))

#creamos una función que sirve para mostrar las instrucciones del juego, de que trata y quienes aparecen
def dibujarFondoInstr():
    fondoI=pygame.image.load("IMAGENES/fondo1.png") #cargamos el fondo de esta pantalla.
    fondoI=pygame.transform.scale(fondoI, (1155,650))
    pantalla.blit(fondoI, (0, 0))
 #establecemos las medidas del cuadro de instrucciones    
    ancho=800
    alto=50
    x=180
    y=200

    #Instrucciones para la pantalla de inicio.
    pygame.draw.rect(pantalla,colorBlanco,(x,y,ancho,alto))
    textoInstrucciones = tipografiaInstrucciones.render('LAS AVENTURAS DE APITRANSFORMER ', False, colorCrema)
    pantalla.blit(textoInstrucciones,(x+10,y,ancho,alto))

    ancho=720
    alto= 170
    x=400
    y=345
    
    pygame.draw.rect(pantalla,colorCrema,(x,y,ancho,alto))
    textoInstrucciones = tipografiaInstrucciones2.render('Ayudanos a eliminar las amenazas de ELIO,', False, colorBlanco)
    pantalla.blit(textoInstrucciones,(x+25,y+10,ancho,alto))

    textoInstrucciones = tipografiaInstrucciones2.render('y junto a la SUPERTABLET, APITRANSFORMER ', False, colorBlanco)
    pantalla.blit(textoInstrucciones,(x+5,y+50,ancho,alto))

    textoInstrucciones = tipografiaInstrucciones2.render('y a nuestros DIGI AMIGOS destruiremos a', False, colorBlanco)
    pantalla.blit(textoInstrucciones,(x+5,y+90,ancho,alto))

    textoInstrucciones = tipografiaInstrucciones2.render('todos los virus para que ELIO pueda jugar', False, colorBlanco)
    pantalla.blit(textoInstrucciones,(x+5,y+130,ancho,alto))



    ancho=630
    alto=40
    x=310
    y=600    

    pygame.draw.rect(pantalla,colorBlanco,(x,y,ancho,alto))
    textoInstrucciones = tipografiaInstrucciones2.render('PRESIONE "C" PARA EMPEZAR A JUGAR', False, colorCrema)
    pantalla.blit(textoInstrucciones,(x+5,y+5,ancho,alto))
    
    
    pygame.display.update()

    
#Llamamos la función anterior  
dibujarFondoInstr()

#Creamos una función que sirve para salir del menú principal utilizando la tecla "C" para salir.
def salirMenu():
    global presente
    global principio
    global quinceSegs
    mostrarPantalla = True
    while mostrarPantalla:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:
                    mostrarPantalla = False
#Inicializamos el tiempo para que cuando el juego empiece el tiempo comience en 0
                    principio= time.time()
                    quinceSegs=principio
#llamamos a la función anterior                    
salirMenu()

#Agregamos una funcion para mostrar un mensaje en el nivel espejo.
def avisarNivelEspejo():
    global idiomaIngles
    
    ancho=350
    alto=60
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=610
    
    pygame.draw.rect(pantalla,colorRojo,(x,y,ancho,alto))
    
    if (idiomaIngles==False):
        textoNivelEspejo= tipografiaNivelEspejo.render('LOS CONTROLES ESTAN INVERTIDOS CUIDADO' , False, colorBlanco)
    else:
        textoNivelEspejo= tipografiaNivelEspejo.render('THE CONTROLS ARE INVESTED CAREFUL' , False, colorBlanco)
    pantalla.blit(textoNivelEspejo,(x+5,y+15,ancho,alto))

#Creamos el mapa del nivel y algunas operaciones para los elementos que se encuentran dentro de la zona de transporte
def crearZonaDeTransporte():

    if nivel==1:
        
        zonaDeTransporte = [[0 for x in range(cantidadDeCasillasPorLado+1)] for y in range(cantidadDeCasillasPorLado+1)] 
        
        zonaDeTransporte[1][3] = 'pared'
        zonaDeTransporte[2][3] = 'pared'
        zonaDeTransporte[3][3] = 'pared'
        zonaDeTransporte[4][3] = 'pared'
        zonaDeTransporte[5][3] = 'pared'
        zonaDeTransporte[6][3] = 'pared'
        zonaDeTransporte[7][3] = 'pared'
        zonaDeTransporte[8][3] = 'pared'

        zonaDeTransporte[1][1] = 'pared'
        zonaDeTransporte[2][1] = 'pared'
        zonaDeTransporte[3][1] = 'pared'
        zonaDeTransporte[4][1] = 'pared'
        zonaDeTransporte[5][1] = 'pared'
        zonaDeTransporte[6][1] = 'pared'
        zonaDeTransporte[7][1] = 'pared'
        zonaDeTransporte[8][1] = 'pared'

        zonaDeTransporte[1] [2]= 'pared'
        zonaDeTransporte[2] [2]= 'pared'
        zonaDeTransporte[3] [2]= 'pared'
        zonaDeTransporte[4] [2]= 'pared'
        zonaDeTransporte[5] [2]= 'pared'
        zonaDeTransporte[6] [2]= 'pared'
        zonaDeTransporte[7] [2]= 'pared'
        zonaDeTransporte[8] [2]= 'pared'

        zonaDeTransporte[1] [7]= 'pared'
        zonaDeTransporte[2][7] = 'pared'
        zonaDeTransporte[3][7] = 'pared'
        zonaDeTransporte[4] [7]= 'pared'
        zonaDeTransporte[5] [7]= 'pared'
        zonaDeTransporte[6] [7]= 'pared'
        zonaDeTransporte[7] [7]= 'pared'
        zonaDeTransporte[8][7] = 'pared'
        
        zonaDeTransporte[1][8] = 'pared'
        zonaDeTransporte[2][8] = 'pared'
        zonaDeTransporte[3][8] = 'pared'
        zonaDeTransporte[4][8] = 'pared'
        zonaDeTransporte[5][8] = 'pared'
        zonaDeTransporte[6][8] = 'pared'
        zonaDeTransporte[7][8] = 'pared'
        zonaDeTransporte[8][8] = 'pared'

        zonaDeTransporte[1][4] = 'pared'
        zonaDeTransporte[1][5] = 'pared'
        zonaDeTransporte[1][6] = 'pared'
        zonaDeTransporte[8][4] = 'pared'
        zonaDeTransporte[8][5] = 'pared'
        zonaDeTransporte[8][6] = 'pared'

        zonaDeTransporte[2][5] = 'jugador'

        zonaDeTransporte[3][5] = 'virus'      
        zonaDeTransporte[4][5] = 'virus'    
        zonaDeTransporte[5][5] = 'virus'    
        zonaDeTransporte[6][5] = 'virus' 
        zonaDeTransporte[5][6] = 'virus'  

        lstAreaProtegida.append((2,4))
        lstAreaProtegida.append((2,6))
        lstAreaProtegida.append((7,4))
        lstAreaProtegida.append((7,6))
        lstAreaProtegida.append((4,6))
        return zonaDeTransporte

    if nivel==2:
        while len(lstEstados)>0:
            lstEstados.pop()
                                ##para limpiar la lista que almacena los movimientos,
                           ##logrando que cuando se aprete 'x' en el nivel 2 no se pueda volver al nivel 1
        zonaDeTransporte = [[0 for x in range(cantidadDeCasillasPorLado+1)] for y in range(cantidadDeCasillasPorLado+1)] 
        
        zonaDeTransporte[1][3] = 'pared'
        zonaDeTransporte[2][3] = 'pared'
        zonaDeTransporte[3][3] = 'pared'
        zonaDeTransporte[4][3] = 'pared'
        zonaDeTransporte[5][3] = 'pared'
        zonaDeTransporte[6][3] = 'pared'
        zonaDeTransporte[7][3] = 'pared'
        zonaDeTransporte[8][3] = 'pared'

        zonaDeTransporte[1][1] = 'pared'
        zonaDeTransporte[2][1] = 'pared'
        zonaDeTransporte[3][1] = 'pared'
        zonaDeTransporte[4][1] = 'pared'
        zonaDeTransporte[5][1] = 'pared'
        zonaDeTransporte[6][1] = 'pared'
        zonaDeTransporte[7][1] = 'pared'
        zonaDeTransporte[8][1] = 'pared'

        zonaDeTransporte[1][2] = 'pared'
        zonaDeTransporte[2][2] = 'pared'
        zonaDeTransporte[3][2] = 'pared'
        zonaDeTransporte[4][2] = 'pared'
        zonaDeTransporte[5][2] = 'pared'
        zonaDeTransporte[6][2] = 'pared'
        zonaDeTransporte[7][2] = 'pared'
        zonaDeTransporte[8][2] = 'pared'

        zonaDeTransporte[1][7] = 'pared'
        zonaDeTransporte[2][7] = 'pared'
        zonaDeTransporte[3][7] = 'pared'
        zonaDeTransporte[4][7] = 'pared'
        zonaDeTransporte[5][7] = 'pared'
        zonaDeTransporte[6][7] = 'pared'
        zonaDeTransporte[7][7] = 'pared'
        zonaDeTransporte[8][7] = 'pared'
        
        zonaDeTransporte[1][8] = 'pared'
        zonaDeTransporte[2][8] = 'pared'
        zonaDeTransporte[3][8] = 'pared'
        zonaDeTransporte[4][8] = 'pared'
        zonaDeTransporte[5][8] = 'pared'
        zonaDeTransporte[6][8] = 'pared'
        zonaDeTransporte[7][8] = 'pared'
        zonaDeTransporte[8][8] = 'pared'

        zonaDeTransporte[1][4] = 'pared'
        zonaDeTransporte[1][5] = 'pared'
        zonaDeTransporte[1][6] = 'pared'
        zonaDeTransporte[8][4] = 'pared'
        zonaDeTransporte[8][5] = 'pared'
        zonaDeTransporte[8][6] = 'pared'

        zonaDeTransporte[2][5] = 'jugador'

        zonaDeTransporte[3][5] = 'virus'      
        zonaDeTransporte[4][5] = 'virus'    
        zonaDeTransporte[5][5] = 'virus'    
        zonaDeTransporte[6][5] = 'virus' 
        zonaDeTransporte[5][6] = 'virus'  

        lstAreaProtegida.append((2,4))
        lstAreaProtegida.append((2,6))
        lstAreaProtegida.append((7,4))
        lstAreaProtegida.append((7,6))
        lstAreaProtegida.append((4,6))       
        return zonaDeTransporte

    if nivel==3:
        while len(lstEstados)>0:
            lstEstados.pop()
        while len (lstzonaDeTransporte) > 0:
            lstzonaDeTransporte.pop()    # para limpiar la lista que almacena los movimientos,
        while len(lstAreaProtegida) >0:
            lstAreaProtegida.pop()
                            ##logrando que cuando se aprete 'x' en el nivel 2 no se pueda volver al nivel 1
        
        zonaDeTransporte = [[0 for x in range(cantidadDeCasillasPorLado+1)] for y in range(cantidadDeCasillasPorLado+1)] 

        for i in range (1,9):
            zonaDeTransporte[1][i] = 'pared'
            zonaDeTransporte[8][i] = 'pared'
            zonaDeTransporte[i][1] = 'pared'
            zonaDeTransporte[i][8] = 'pared'
        zonaDeTransporte[2][7] = 'pared'
        zonaDeTransporte[2][6] = 'pared'
        zonaDeTransporte[7][2] = 'pared'
        zonaDeTransporte[7][6] = 'pared'
        zonaDeTransporte[3][2] = 'pared'
            
        zonaDeTransporte[2][2] = 'jugador'

        zonaDeTransporte[3][3] = 'virus'      
        zonaDeTransporte[3][5] = 'virus'    
        zonaDeTransporte[4][7] = 'virus'    
        zonaDeTransporte[5][4] = 'virus' 
        zonaDeTransporte[6][4] = 'virus'  

        lstAreaProtegida.append((2,4))
        lstAreaProtegida.append((3,7))
        lstAreaProtegida.append((4,2))
        lstAreaProtegida.append((7,3))
        lstAreaProtegida.append((7,7))

        
        return zonaDeTransporte

        

        
zonaDeTransporte=crearZonaDeTransporte()

def hayAreaProtegidaEn(x,y):
    punto=(x,y)
    return lstAreaProtegida.__contains__(punto)

def posicionarElemento(elemento,x,y):
    
    zonaDeTransporte[x][y]=elemento

def borrarElemento(x,y):
    zonaDeTransporte[x][y]=0
        
#Dibujamos la zona de transporte, fondo, reglas y felicitación
def dibujarZonaDeTransporte():
    global tabletMujerActivada
    cnt = 0
    if (tabletMujerActivada==True):
        imgTablet = pygame.image.load("IMAGENES/2.png")
        imgSuperTablet=pygame.image.load("IMAGENES/supertablet.png")
        imgSuperTablet=pygame.transform.scale(imgSuperTablet, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    else:
        imgTablet = pygame.image.load("IMAGENES/supertablet.png")
        imgTablet=pygame.transform.scale(imgTablet, (80,70))
        imgSuperTablet=pygame.image.load("IMAGENES/2.png")
        imgSuperTablet=pygame.transform.scale(imgSuperTablet, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    for i in range(1,cantidadDeCasillasPorLado+1):
        for j in range(1,cantidadDeCasillasPorLado+1):
            pygame.draw.rect(pantalla, color, [cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])        
            if (hayAreaProtegidaEn(j,i)==True):
                pantalla.blit(imgAreaProtegida, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i)) 
            if (zonaDeTransporte[j][i]=='jugador'):
               pantalla.blit(imgSuperTablet, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i)) 
            if (zonaDeTransporte[j][i]=='pared'):          
               pantalla.blit(imgPared, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
            if (zonaDeTransporte[j][i]=='virus'):
               pantalla.blit(imgAmenaza, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
            cnt +=1
        cnt-=1

    pygame.draw.rect(pantalla,color,[cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla,cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla,cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla],1)       
    pygame.display.update()
#agregamos la imagen que se va a utilizar para el fondo del videojuego
def dibujarFondo():
    fondo = pygame.image.load("IMAGENES/fondo2.png")
    fondo =pygame.transform.scale(fondo, (1155,650))
    pantalla.blit(fondo, (0, 0))
#dibujamos las reglas sobre como mover a la super tablet y en que consiste el juego
def dibujarReglas():
    global idiomaIngles
    if idiomaIngles == False:
        textoReglas = tipografia.render('Mover a Super Tablet con las flechas del teclado para que lleve los virus a las zonas protegidas', False, colorBlanco)
    if idiomaIngles == True:
        textoReglas = tipografia.render('Move to Super Tablet with the arrow keys to bring viruses to protected areas.', False, colorBlanco)
    ancho=800
    alto=46
    x=350
    y=3
    pygame.draw.rect(pantalla,colorCrema,(x,y,ancho,alto))
    pantalla.blit(textoReglas,(x+5,y,ancho,alto))
    pygame.display.update()
    
#agregamos esta funcion para que la bateria de la tablet se vaya acabando a medida que se mueve
def actualizarContadorDeElectricidad(decremento):
    ancho=350
    alto=40
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=cantPixelesPorLadoCasilla*6
    pygame.draw.rect(pantalla,colorCrema,(x,y,ancho,alto))
    if idiomaIngles==False:
        textoEnergia = tipografiaGrande.render('Bateria disponible de Super Tablet: ' + str(cantidadDeEnergia) + 'mA', False, colorBlanco)
    else:
        textoEnergia = tipografiaGrande.render('Available super tablet battery ' + str(cantidadDeEnergia) + 'mA', False, colorBlanco)
    pantalla.blit(textoEnergia,(x+5,y+15,ancho,alto))
    pygame.display.update()

def dibujarEnergiaAcumulada():
    global puntaje
    
    
#dibujamos un mensaje de felicitacion por haber ganado el juego
def dibujarFelicitacion():
    global juegoCompletado
    global nivel

    x=50
    y=3
    ancho=240
    alto=26
    
    if (juegoCompletado==True):
        if idiomaIngles == False:
            textoFelicitacion = tipografiaGrande.render('GANASTE', False, colorBlanco)
        else:
            textoFelicitacion = tipografiaGrande.render('YOU WON', False, colorBlanco)
    
    else:
        if idiomaIngles == False:
            textoFelicitacion = tipografiaGrande.render('Jugando NIVEL ' + str(nivel), False, colorBlanco)
        else:
             textoFelicitacion = tipografiaGrande.render('Playing LEVEL ' + str(nivel), False, colorBlanco)
    
    pygame.draw.rect(pantalla,colorCrema,(x,y,ancho,alto))
    pantalla.blit(textoFelicitacion,(x+5,y,ancho,alto))
    pygame.display.update()
    
#Creamos una función que permite que al tocar un botón se apague la música
def funcionMudo():
   global sonidoActivado
   if sonidoActivado==True:
        pygame.mixer.music.stop()
   else:
        pygame.mixer.music.play()
    
def funcionMenu():
    global menuActivado
    global idiomaIngles
    global sonidoActivado
    global tabletMujerActivada
    global cambiarTablet
    xmouse, ymouse = pygame.mouse.get_pos()
    distanciaIngles = sqrt(pow(1042+15-xmouse, 2)+pow(480+15-ymouse,2))
    distanciaEspaniol = sqrt(pow(1042+15-xmouse, 2)+pow(500+15-ymouse,2))
    distanciaSonido = sqrt(pow(1042+15-xmouse, 2)+pow(400+15-ymouse,2))
    distanciaOpciones = sqrt(pow(1042+15-xmouse, 2)+pow(300+15-ymouse,2))
    distanciaTablet = sqrt(pow(1002+15-xmouse, 2)+pow(560+15-ymouse,2))
    if (menuActivado == False):
        if event.button == 1 and distanciaOpciones<30:
            menuActivado=True
            dibujarIngles()
            dibujarEspaniol()
            dibujarIcono2()
            dibujarTablet()
        
    elif (menuActivado == True):
        if event.button == 1 and distanciaIngles<30:
            idiomaIngles = True
            dibujarReglas()
            dibujarFelicitacion()
            actualizarContadorDeElectricidad(0)
            actualizarContadorDePasos(0)
            if (nivel==2):
                avisarNivelEspejo()
        if event.button == 1 and distanciaEspaniol<30:
            idiomaIngles = False
            dibujarReglas()
            dibujarFelicitacion()
            actualizarContadorDeElectricidad(0)
            actualizarContadorDePasos(0)
            if (nivel==2):
                avisarNivelEspejo()
        if event.button == 1 and distanciaSonido<40 and sonidoActivado == True:
            sonidoActivado = False
            dibujarIcono2()
        elif event.button == 1 and distanciaSonido<40 and sonidoActivado == False:
            sonidoActivado = True
            dibujarIcono2()
        if event.button == 1 and distanciaOpciones<40:
            menuActivado = False
            dibujarTodo()
        if event.button == 1 and distanciaTablet<40 and tabletMujerActivada==False:
            tabletMujerActivada=True
            imgTablet = pygame.image.load("IMAGENES/2.png")
            imgTablet=pygame.transform.scale(imgTablet, (80,70))
            pantalla.blit(imgTablet,(1002, 560, 10, 10))   
            imgSuperTablet=pygame.image.load("IMAGENES/supertablet.png")
        elif event.button == 1 and distanciaTablet<40 and tabletMujerActivada==True:
            tabletMujerActivada=False
            imgTablet = pygame.image.load("IMAGENES/supertablet.png")
            imgTablet=pygame.transform.scale(imgTablet, (80,70))
            pantalla.blit(imgTablet,(1002, 560, 10, 10))   
            imgSuperTablet=pygame.image.load("IMAGENES/2.png")
        pygame.display.update()
    
def dibujarTablet():
    imgTablet = pygame.image.load("IMAGENES/supertablet.png")
    imgTablet=pygame.transform.scale(imgTablet, (80,70))
    pantalla.blit(imgTablet,(1002, 560, 10, 10))
    pygame.display.update()   
    
def dibujarIngles():
    imgIngles = pygame.image.load("IMAGENES/ingles.png")
    imgIngles=pygame.transform.scale(imgIngles, (80,70))
    pantalla.blit(imgIngles,(1012, 435, 10, 10))
    pygame.display.update()
        

def dibujarEspaniol():
    imgEspaniol = pygame.image.load("IMAGENES/español.png")
    imgEspaniol = pygame.transform.scale(imgEspaniol, (80,70))
    pantalla.blit(imgEspaniol,(1012, 500, 10, 10))
    pygame.display.update()    
     
def dibujarIcono():
    global quinceSegs
    quinceSegs=time.time()
    imgMenu = pygame.image.load("IMAGENES/menu.png")
    imgMenu=pygame.transform.scale(imgMenu, (80,70))
    pantalla.blit(imgMenu,(1012, 300, 10, 10))
    pygame.display.update()           
            
#Creamos una función para que aparezca la imagen del botón de mute en la pantalla
def dibujarIcono2():
    if sonidoActivado==True:
        imgBotonMudo = pygame.image.load("IMAGENES/mudo.png")
    else:
        imgBotonMudo = pygame.image.load("IMAGENES/nomudo.png")
    imgBotonMudo=pygame.transform.scale(imgBotonMudo, (80,70))
    pantalla.blit(imgBotonMudo,(1012, 370, 10, 10))
    pygame.display.update()
    funcionMudo()

#Creamos operaciones relacionadas con la tabla de marcadores
def obtener5Mejores():
  file = open("puntuaciones.txt", "r")
  lstPuntuaciones=[]
  lstMejores5=[]
  

  nombreAgregado=False
  par=[]
      
  lineas= file.readlines()
  lineas = [line.strip() for line in open('puntuaciones.txt')]

  for line in lineas:
    
    if not (line==''):
        if (nombreAgregado==False):
            par=[]
            par.append(line)
            nombreAgregado=True
        else:    
            par.append(int(line))
            lstPuntuaciones.append(par)
            nombreAgregado=False
    
    for i in range (0, len(lstPuntuaciones)-1):
        for j in range (0, len(lstPuntuaciones)-i-1):
            if lstPuntuaciones[j+1][1] > lstPuntuaciones[j][1]:
                aux = lstPuntuaciones[j]
                lstPuntuaciones[j] = lstPuntuaciones[j+1]
                lstPuntuaciones[j+1] = aux
    
 
  lstMejores5 = lstPuntuaciones[:5]
  
  file.close()
  return lstMejores5

#agregamos un archivo de texto para guardar el puntaje de cada jugador
def escribirEnArchivo(nombre, puntuacion):
    file = open("puntuaciones.txt", "a")
    file.write(nombre) 
    file.write('\n')
    file.write(str(puntuacion))
    file.write('\n')
    file.close()
    
#hacemos que se escriban los 5 mejores jugadores con sus records.
def dibujar5QueJugaronPrimero():
    lst5Jugadores=obtener5Mejores()
    ancho=150
    alto=40
    x=77+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    i=8

         
    for par in lst5Jugadores:
        y=(32*i)-100
        textoRanking = tipografiaGrande.render(str(par[0]) + ': ' + str(par[1]), False, colorBlanco)
        pygame.draw.rect(pantalla,colorCrema,(x,y,ancho,alto))
        pantalla.blit(textoRanking,(x+5,y,ancho,alto))
        i=i+1
       
    pygame.display.update()

#Actualizamos el contador de pasos de Super Tablet y el contador de energía
def actualizarContadorDePasos(pasos):
    global cantidadDePasos
    global deshaciendo
    if deshaciendo == True:
        cantidadDePasos = pasos
    else:
        cantidadDePasos= cantidadDePasos + pasos
    ancho=280
    alto=40
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=cantPixelesPorLadoCasilla*7
    pygame.draw.rect(pantalla,colorCrema,(x,y,ancho,alto))
    if idiomaIngles == False:
        textoPasos = tipografiaGrande.render('Cantidad de movimientos: ' + str(cantidadDePasos), False, colorBlanco)
    else:
        textoPasos = tipografiaGrande.render('The quantity of movements: ' + str(cantidadDePasos), False, colorBlanco)
    pantalla.blit(textoPasos,(x+5,y,ancho,alto))
    pygame.display.update()

#creamos la función para que se muestre donde se va a ingresar el nombre
def name() :
    ancho=370
    alto=70
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=cantPixelesPorLadoCasilla*5
    pygame.draw.rect(pantalla,colorCrema,(x,y,ancho,alto))
    if idiomaIngles == False:
        textonombre = tipografiaGrande.render('Tu nombre: ' +str( nombre), False, colorBlanco)
    else:
        textonombre = tipografiaGrande.render('Your name: ' +str( nombre), False, colorBlanco)
    pantalla.blit(textonombre,(x+5,y,ancho,alto))
    if idiomaIngles == False:
        textonombre = tipografiaGrande.render('Presiona "Enter" para salir ' , False, colorBlanco)
    else:
        textonombre = tipografiaGrande.render('Press "Enter" to exit ' , False, colorBlanco)
    pantalla.blit(textonombre,(x+5,y+30,ancho,alto))
    pygame.display.update()

def dibujarFinDeJuego():
    #dibujamos un cartel para que cuando la super tablet pase los 15 segundos sin moverse, este le avise cuando se esta reiniciando.
    ancho=500
    alto= 100
    x=300
    y=300
    
    pygame.draw.rect(pantalla,otro,(x,y,ancho,alto))
    textoReinicio = tipografiaReinicio.render('FIN DEL JUEGO', False, colorBlanco)
    pantalla.blit(textoReinicio,(x+25,y+10,ancho,alto))
    textoReinicio = tipografiaReinicio.render('TE ESPERAMOS EN OTRA OCASION', False, colorBlanco)
    pantalla.blit(textoReinicio,(x+25,y+40,ancho,alto))
    textoReinicio = tipografiaReinicio.render('PARA SEGUIR DETECTANDO VIRUS', False, colorBlanco)
    pantalla.blit(textoReinicio,(x+25,y+70,ancho,alto))
               

    #le avisamos cuanto tiempo debera estar en la pantalla, y que luego se actualice 
    pygame.display.update()
    time.sleep(5)

#Creamos una operación que indique si el nivel fue solucionado
def estaSolucionado():
    global juegoCompletado
    global ingresarNombre
    global nombre
    global principio
    global nivel
    global zonaDeTransporte
    global puntaje                                   
    global cantidadDeEnergia
    global guardePuntaje

    cantVirusSobreAreaProtegida=0

    for punto in lstAreaProtegida:
        x=punto[0]
        y=punto[1]
        if zonaDeTransporte[x][y]=='virus':
            cantVirusSobreAreaProtegida=cantVirusSobreAreaProtegida+1       

    if (cantVirusSobreAreaProtegida==len(lstAreaProtegida) and nivel==1):        
        nivel+=1
        crearZonaDeTransporte()
        ingresarNombre=False
        puntaje += cantidadDeEnergia
        reiniciar()
    if (cantVirusSobreAreaProtegida==len(lstAreaProtegida) and nivel==2):
        nivel+=1
        zonaDeTransporte=crearZonaDeTransporte()
        ingresarNombre=False
        puntaje += cantidadDeEnergia
        reiniciar()
    if (cantVirusSobreAreaProtegida==len(lstAreaProtegida) and nivel==3):
        juegoCompletado=True
        if guardePuntaje == False:
            puntaje += cantidadDeEnergia
            guardePuntaje = True
        ingresarNombre=True
        if (ingresarNombre == True):
            name()
            puntaje =int (cantidadDeEnergia/(time.time()-principio))
        #Creamos condiciones para que cuando se presione una letra se guarde en una variable y luego sea mostrada en la pantalla y guardada en una variable junto al puntaje dentro de un archivo.
            while True :
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_a:
                        nombre = nombre + str ('a')
                        name()
                    elif event.key == pygame.K_b:
                        nombre = nombre + str ('b')
                        name()
                    elif event.key == pygame.K_c:
                        nombre = nombre + str ('c')
                        name()
                    elif event.key == pygame.K_d:
                        nombre = nombre + str ('d')
                        name()
                    elif event.key == pygame.K_e:
                        nombre = nombre + str ('e')
                        name()
                    elif event.key == pygame.K_f:
                        nombre = nombre + str ('f')
                        name()
                    elif event.key == pygame.K_g:
                        nombre = nombre + str ('g')
                        name()
                    elif event.key == pygame.K_h:
                        nombre = nombre + str ('h')
                        name()
                    elif event.key == pygame.K_i:
                        nombre = nombre + str ('i')
                        name()
                    elif event.key == pygame.K_j:
                        nombre = nombre + str ('j')
                        name()
                    elif event.key == pygame.K_k:
                        nombre = nombre + str ('k')
                        name()
                    elif event.key == pygame.K_l:
                        nombre = nombre + str ('l')
                        name()
                    elif event.key == pygame.K_m:
                        nombre = nombre + str ('m')
                        name()
                    elif event.key == pygame.K_n:
                        nombre = nombre + str ('n')
                        name()
                    elif event.key == pygame.K_o:
                        nombre = nombre + str ('o')
                        name()
                    elif event.key == pygame.K_p:
                        nombre = nombre + str ('p')
                        name()
                    elif event.key == pygame.K_q:
                        nombre = nombre + str ('q')
                        name()
                    elif event.key == pygame.K_r:
                        nombre = nombre + str ('r')
                        name()
                    elif event.key == pygame.K_s:
                        nombre = nombre + str ('s')
                        name()
                    elif event.key == pygame.K_t:
                        nombre = nombre + str ('t')
                        name()
                    elif event.key == pygame.K_u:
                        nombre = nombre + str ('u')
                        name()
                    elif event.key == pygame.K_v:
                        nombre = nombre + str ('v')
                        name()
                    elif event.key == pygame.K_w:
                        nombre = nombre + str ('w')
                        name()
                    elif event.key == pygame.K_x:
                        nombre = nombre + str ('x')
                        name()
                    elif event.key == pygame.K_y:
                        nombre = nombre + str ('y')
                        name()
                    elif event.key == pygame.K_z:
                        nombre = nombre + str ('z')
                        name()
            #hicimos que al presionar la tecla "Enter" el juego se termine y se guarde el puntaje y el nombre del jugador
                    elif event.key == pygame.K_RETURN:
                        escribirEnArchivo (nombre,puntaje)
                        dibujarFinDeJuego()
                        pygame.quit()
                        quit()
                        

                return
            
            else:
                juegoCompletado=False

                dibujarFelicitacion()
                dibujarReglas()
        



def colorDelCartel():
    global lstColores
    global nivelDeAzul
    nivelDeAzul= (str(random.choice(lstColores)))
    nivelDeAzul= int(nivelDeAzul)
    textoRondaFinal = tipografiaRondaFinal.render('RONDA FINAL', False, colorNegro)
    ancho=195
    alto=40
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=560
    colorRondaFinal= (255,255,nivelDeAzul)
    guardarAhora()
    pygame.draw.rect(pantalla,colorRondaFinal,(x,y,ancho,alto))
    pantalla.blit(textoRondaFinal,(x+5,y,ancho,alto))
    pygame.display.update()

#Creamos operaciones para mover a Super Tablet
            
def irALaDerecha():
    global quinceSegs
    quinceSegs= int (time.time())
#Hicimos que se reproduzca el sonido al moverse
    
    sonidoMovimiento.play()
#utilizamos la variable "cantidadDeEnergia" para que cuando se mueva o cuando empuje un virus se le reste la cantidad de energía correspondiente 
    global cantidadDeEnergia
    guardarAhora()
    colorDelCartel()
    for i in range(1,cantidadDeCasillasPorLado):
        for j in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                if (zonaDeTransporte[j+1][i]==0):
                    sonidoMovimiento.play()
                    posicionarElemento('jugador',j+1,i)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(0)
                    borrarElemento(j,i)
                    cantidadDeEnergia=cantidadDeEnergia-10
                    actualizarContadorDeElectricidad(0)
                    quinceSegs=int (time.time())
                    break
                if(zonaDeTransporte[j+1][i]=='virus') and not ((zonaDeTransporte[j+2][i]=='pared') or (zonaDeTransporte[j+2][i]=='virus')):                  
                    quinceSegs=int (time.time())
                    posicionarElemento('virus',j+2,i)
                    posicionarElemento('jugador',j+1,i)
                    actualizarContadorDePasos(1)
                    borrarElemento(j,i)
                    cantidadDeEnergia=cantidadDeEnergia-15
                    actualizarContadorDeElectricidad(0)
                    break
                if (zonaDeTransporte[j+1][i]=='virus') and (zonaDeTransporte[j+2][i]=='virus'):
                    cantidadDeEnergia=cantidadDeEnergia-200
                    actualizarContadorDeElectricidad(0)
                    break
def irArriba():
    global quinceSegs
    quinceSegs=int (time.time())
#Hicimos que se reproduzca el sonido al moverse
    sonidoMovimiento.play()
#utilizamos la variable "cantidadDeEnergia" para que cuando se mueva o cuando empuje un virus se le reste la cantidad de energía correspondiente
    global cantidadDeEnergia
    guardarAhora()
    colorDelCartel()
    for i in range(1,cantidadDeCasillasPorLado):
        for j in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                if (zonaDeTransporte[j][i-1]==0):
                    sonidoMovimiento.play()
                    posicionarElemento('jugador',j,i-1)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(0)
                    borrarElemento(j,i)
                    cantidadDeEnergia=cantidadDeEnergia-10
                    actualizarContadorDeElectricidad(0)
                    quinceSegs=int (time.time())
                    break
                if(zonaDeTransporte[j][i-1]=='virus') and not ((zonaDeTransporte[j][i-2]=='pared') or (zonaDeTransporte[j][i-2]=='virus')):
                    quinceSegs=int (time.time())
                    posicionarElemento('virus',j,i-2)
                    posicionarElemento('jugador',j,i-1)
                    actualizarContadorDePasos(1)
                    borrarElemento(j,i)
                    cantidadDeEnergia=cantidadDeEnergia-15
                    actualizarContadorDeElectricidad(0)
                    break
                if (zonaDeTransporte[j][i-1]=='virus') and (zonaDeTransporte[j][i-2]=='virus'):
                    cantidadDeEnergia=cantidadDeEnergia-200
                    actualizarContadorDeElectricidad(0)
                    break

def irAbajo():
    global quinceSegs
    quinceSegs=int (time.time())
#Hicimos que se reproduzca el sonido al moverse
    sonidoMovimiento.play()
#utilizamos la variable "cantidadDeEnergia" para que cuando se mueva o cuando empuje un virus se le reste la cantidad de energía correspondiente

    global cantidadDeEnergia
    guardarAhora()
    colorDelCartel()
    for j in range(1,cantidadDeCasillasPorLado):
        for i in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                if (zonaDeTransporte[j][i+1]==0):
                    sonidoMovimiento.play()
                    posicionarElemento('jugador',j,i+1)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(0)
                    borrarElemento(j,i)
                    cantidadDeEnergia=cantidadDeEnergia-10
                    actualizarContadorDeElectricidad(0)
                    quinceSegs=int (time.time())
                    break
                if(zonaDeTransporte[j][i+1]=='virus') and not ((zonaDeTransporte[j][i+2]=='pared') or (zonaDeTransporte[j][i+2]=='virus')):
                    quinceSegs=int (time.time())
                    posicionarElemento('virus',j,i+2)
                    posicionarElemento('jugador',j,i+1)
                    actualizarContadorDePasos(1)
                    borrarElemento(j,i)
                    cantidadDeEnergia=cantidadDeEnergia-15
                    actualizarContadorDeElectricidad(0)
                    break
                if (zonaDeTransporte[j][i+1]=='virus') and (zonaDeTransporte[j][i+2]=='virus'):
                    cantidadDeEnergia=cantidadDeEnergia-200
                    actualizarContadorDeElectricidad(0)
                    break

def irALaIzquierda():
    global quinceSegs
#Hicimos que se reproduzca el sonido al moverse
    sonidoMovimiento.play()
#utilizamos la variable "cantidadDeEnergia" para que cuando se mueva o cuando empuje un virus se le reste la cantidad de energía correspondiente
    global cantidadDeEnergia
    guardarAhora()
    colorDelCartel()
    for i in range(1,cantidadDeCasillasPorLado):
        for j in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                if (zonaDeTransporte[j-1][i]==0):
                    sonidoMovimiento.play()
                    posicionarElemento('jugador',j-1,i)              
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(0)
                    borrarElemento(j,i)
                    cantidadDeEnergia=cantidadDeEnergia-10
                    actualizarContadorDeElectricidad(0)
                    quinceSegs=int (time.time())
                    break
                if(zonaDeTransporte[j-1][i]=='virus') and not ((zonaDeTransporte[j-2][i]=='pared') or (zonaDeTransporte[j-2][i]=='virus')):
                    quinceSegs=int (time.time())
                    posicionarElemento('virus',j-2,i)
                    posicionarElemento('jugador',j-1,i)
                    actualizarContadorDePasos(1)
                    borrarElemento(j,i)
                    cantidadDeEnergia=cantidadDeEnergia-15
                    actualizarContadorDeElectricidad(0)
                    break
                if (zonaDeTransporte[j-1][i]=='virus') and (zonaDeTransporte[j-2][i]=='virus'):
                    cantidadDeEnergia=cantidadDeEnergia-200
                    actualizarContadorDeElectricidad(0)
                    break


#creamos una función que nos permite mostrar el tiempo en la pantalla 
def tiempo():
    global juegoCompletado
    global principio
    global salirPantalla
    global mostrarPantalla
    
    presente = int(time.time() - principio)
    ancho=40
    alto=46
    x=300
    y=3
    pygame.draw.rect(pantalla,colorCrema,(x,y,ancho,alto))
    textoTime = tipografiaGrande.render(str (presente), False, colorBlanco)
    pantalla.blit (textoTime,(x+5,y,ancho,alto))
    pygame.display.update()
#creamos una función que nos permite que cuando la súper  tabletas se queda sin batería el nivel se reinicie automaticamente (en esta función no se llamo a la función "reinicio" ya que esta se realizó anteriormente)
    
def reinicioAutomatico():
    global cantidadDePasos
    global cantidadDeEnergia
    global juegoCompletado
    global presente
    global principio
    global tr
    global nivelDeAzul
    
    if (cantidadDeEnergia<=0) and (juegoCompletado==False):
        tr= int (0)
        for j in range(1,cantidadDeCasillasPorLado):
            for i in range(1,cantidadDeCasillasPorLado):
                if (zonaDeTransporte[j][i]=='jugador'):
                    borrarElemento(j,i)
                if (zonaDeTransporte[j][i]=='virus'):
                    borrarElemento(j,i)

        principio= int (time.time())
        presente=int (time.time()-principio)
        ancho=40
        alto=46
        x=300
        y=3
        pygame.draw.rect(pantalla,colorCrema,(x,y,ancho,alto))
        textoTime = tipografiaGrande.render(str (presente), False, colorBlanco)
        pantalla.blit (textoTime,(x+5,y,ancho,alto))
        cantidadDeEnergia=7000
        cantidadDePasos=0
        pygame.display.update()

        dibujarTodo()
        
            
        if (nivel==1 or nivel==2):
            posicionarElemento('jugador',2,5)
            posicionarElemento('virus'  ,3,5)    
            posicionarElemento('virus', 4,5)   
            posicionarElemento('virus',5,5)    
            posicionarElemento('virus',6,5) 
            posicionarElemento('virus',5,6)
        if (nivel==3):
            posicionarElemento('jugador',2,5)
            posicionarElemento('virus'  ,2,3)    
            posicionarElemento('virus', 3,3)   
            posicionarElemento('virus',4,4)    
            posicionarElemento('virus',5,5) 
            posicionarElemento('virus',6,6)

    return zonaDeTransporte
#creamos una lista con los movimientos y los guardamos en una funcion para poder deshacerlos
            
def retroceder():
    global cantidadDeEnergia
    global deshaciendo
    global nivel
    global nivelDeAzul
   
    if len (lstEstados) > 0:
        deshaciendo = True
        for i in range (1, cantidadDeCasillasPorLado):
            for j in range (1, cantidadDeCasillasPorLado):
                zonaDeTransporte [j] [i] = 0
        tr= int (0)
        if (nivel==1 or nivel==2):
            zonaDeTransporte[1][3] = 'pared'
            zonaDeTransporte[2][3] = 'pared'
            zonaDeTransporte[3][3] = 'pared'
            zonaDeTransporte[4][3] = 'pared'
            zonaDeTransporte[5][3] = 'pared'
            zonaDeTransporte[6][3] = 'pared'
            zonaDeTransporte[7][3] = 'pared'
            zonaDeTransporte[8][3] = 'pared'

            zonaDeTransporte[1][1] = 'pared'
            zonaDeTransporte[2][1] = 'pared'
            zonaDeTransporte[3][1] = 'pared'
            zonaDeTransporte[4][1] = 'pared'
            zonaDeTransporte[5][1] = 'pared'
            zonaDeTransporte[6][1] = 'pared'
            zonaDeTransporte[7][1] = 'pared'
            zonaDeTransporte[8][1] = 'pared'

            zonaDeTransporte[1] [2]= 'pared'
            zonaDeTransporte[2][2] = 'pared'
            zonaDeTransporte[3][2] = 'pared'
            zonaDeTransporte[4] [2]= 'pared'
            zonaDeTransporte[5] [2]= 'pared'
            zonaDeTransporte[6] [2]= 'pared'
            zonaDeTransporte[7] [2]= 'pared'
            zonaDeTransporte[8][2] = 'pared'

            zonaDeTransporte[1] [7]= 'pared'
            zonaDeTransporte[2][7] = 'pared'
            zonaDeTransporte[3][7] = 'pared'
            zonaDeTransporte[4] [7]= 'pared'
            zonaDeTransporte[5] [7]= 'pared'
            zonaDeTransporte[6] [7]= 'pared'
            zonaDeTransporte[7] [7]= 'pared'
            zonaDeTransporte[8][7] = 'pared'
            
            zonaDeTransporte[1][8] = 'pared'
            zonaDeTransporte[2][8] = 'pared'
            zonaDeTransporte[3][8] = 'pared'
            zonaDeTransporte[4][8] = 'pared'
            zonaDeTransporte[5][8] = 'pared'
            zonaDeTransporte[6][8] = 'pared'
            zonaDeTransporte[7][8] = 'pared'
            zonaDeTransporte[8][8] = 'pared'

            zonaDeTransporte[1][4] = 'pared'
            zonaDeTransporte[1][5] = 'pared'
            zonaDeTransporte[1][6] = 'pared'
            zonaDeTransporte[8][4] = 'pared'
            zonaDeTransporte[8][5] = 'pared'
            zonaDeTransporte[8][6] = 'pared'
        if nivel==3:
            for i in range (1,9):
                zonaDeTransporte[1][i] = 'pared'
                zonaDeTransporte[8][i] = 'pared'
                zonaDeTransporte[i][1] = 'pared'
                zonaDeTransporte[i][8] = 'pared'
            zonaDeTransporte[2][7] = 'pared'
            zonaDeTransporte[2][6] = 'pared'
            zonaDeTransporte[7][2] = 'pared'
            zonaDeTransporte[7][6] = 'pared'
            zonaDeTransporte[3][2] = 'pared'

        estadoAnterior = lstEstados.pop()
        zonaDeTransporte[estadoAnterior[0][0]][estadoAnterior[0][1]] = 'jugador'
        zonaDeTransporte[estadoAnterior[1][0][0]][estadoAnterior[1][0][1]] = 'virus'
        zonaDeTransporte[estadoAnterior[1][1][0]][estadoAnterior[1][1][1]] = 'virus'
        zonaDeTransporte[estadoAnterior[1][2][0]][estadoAnterior[1][2][1]] = 'virus'
        zonaDeTransporte[estadoAnterior[1][3][0]][estadoAnterior[1][3][1]] = 'virus'
        zonaDeTransporte[estadoAnterior[1][4][0]][estadoAnterior[1][4][1]] = 'virus'
        cantidadDeEnergia = estadoAnterior[2]
        actualizarContadorDeElectricidad(cantidadDeEnergia)
        cantidadDePasos = estadoAnterior[3]
        actualizarContadorDePasos(cantidadDePasos)
        nivelDeAzul= estadoAnterior[4]
        retrocederColor()
        deshaciendo = False

def retrocederColor():
    textoRondaFinal = tipografiaRondaFinal.render('RONDA FINAL', False, colorNegro)
    ancho=195
    alto=40
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=560
    colorRondaFinal= (255,255,nivelDeAzul)
    pygame.draw.rect(pantalla,colorRondaFinal,(x,y,ancho,alto))
    pantalla.blit(textoRondaFinal,(x+5,y,ancho,alto))
    pygame.display.update()
                
#Creamos  una función para reiniciar el nivel, para esto volvimos al tiempo, a la energia y a los movimientos a su valor inicial y hicimos que al presionar la tecla "R" se llame a esta función    
        
def reiniciar():
    global cantidadDePasos
    global cantidadDeEnergia
    global juegoCompletado
    global presente
    global principio
    global tr
    global nivel
    global nivelDeAzul
    
    while len(lstEstados)>0:
        lstEstados.pop() #Limpia la lista de estados para que cuando se reinicie el nivel no se pueda volver a estados anteriores al reinicio
    principio=int (time.time())
    presente=int (time.time()-principio)
    quinceSegs= int (time.time())
    tr=int (0)
    ancho=40
    alto=46
    x=300
    y=3
    pygame.draw.rect(pantalla,colorCrema,(x,y,ancho,alto))
    textoTime = tipografiaGrande.render(str (presente), False, colorBlanco)
    pantalla.blit (textoTime,(x+5,y,ancho,alto))
    
    for j in range(1,cantidadDeCasillasPorLado):
        for i in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                borrarElemento(j,i)
            if (zonaDeTransporte[j][i]=='virus'):
                borrarElemento(j,i)
    cantidadDeEnergia=7000
    cantidadDePasos=0

    if (nivel==1 or nivel==2):
        posicionarElemento('jugador',2,5)
        posicionarElemento('virus'  ,3,5)    
        posicionarElemento('virus', 4,5)   
        posicionarElemento('virus',5,5)    
        posicionarElemento('virus',6,5) 
        posicionarElemento('virus',5,6)
    if (nivel==3):
        posicionarElemento('jugador',2,2)
        posicionarElemento('virus'  ,2,3)    
        posicionarElemento('virus', 3,5)      
        posicionarElemento('virus',4,7) 
        posicionarElemento('virus',5,4)
        posicionarElemento('virus',6,4)
    dibujarTodo()
    pygame.display.update()
    return zonaDeTransporte
#Creamos la función que guarda los movimientos, así completando a la función que permite deshacerlos
        
def guardarAhora():
    global lstEstados
    global cantidadDeEnergia
    global cantidadDePasos
    global nivelDeAzul

    posVirus = []
    
    for i in range (1,cantidadDeCasillasPorLado+1):
        for j in range (1,cantidadDeCasillasPorLado+1):
            if (zonaDeTransporte[j][i]== 'jugador'):
                posJugador= (j,i)
            elif (zonaDeTransporte[j][i]== 'virus'):
                posVirus.append((j,i))

    lstEstados.append((posJugador, posVirus, cantidadDeEnergia, cantidadDePasos,nivelDeAzul))

#Creamos una función que muestra un cuadro, este especifica que presionando la tecla "R" el nivel se reinicia, y que presionando la tecla "X" se vuelve atrás un movimiento 
    
def mostrarIndicaciones():
    ancho=315
    alto=80
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=cantPixelesPorLadoCasilla
    pygame.draw.rect(pantalla,colorCrema,(x,y,ancho,alto))
    if idiomaIngles==False:
        textoInstrucciones = tipografiaGrande.render('Presiona X dos veces para retroceder ' , False, colorBlanco)
        textoInstrucciones2 = tipografiaGrande.render('Presiona R para reiniciar' , False, colorBlanco)
    else:
        textoInstrucciones = tipografiaGrande.render('press in two times X to go back ' , False, colorBlanco)
        textoInstrucciones2 = tipografiaGrande.render('Press R to restart' , False, colorBlanco)
    pantalla.blit(textoInstrucciones,(x+5,y,ancho,alto))
    pantalla.blit(textoInstrucciones2,(x,cantPixelesPorLadoCasilla+40,ancho,alto))
   
    pygame.display.update()

    
 #creamos la funcion para que si la tablet esta 15 segundos sin desplazarse el juego se reinicie
def AnotarTiempoRestante():
    global quinceSegs
    global tr
    if (juegoCompletado==False):
        tr=int (time.time()-quinceSegs)
        if (tr>=15):
            #dibujamos un cartel para que cuando la super tablet pase los 15 segundos sin moverse, este le avise cuando se esta reiniciando.
            ancho=500
            alto= 100
            x=300
            y=300
            
            pygame.draw.rect(pantalla,colorRojo,(x,y,ancho,alto))
            textoReinicio = tipografiaReinicio.render('REINICIANDO...', False, colorBlanco)
            pantalla.blit(textoReinicio,(x+25,y+10,ancho,alto))
            textoReinicio = tipografiaReinicio.render('un antivirus nunca puede quedar', False, colorBlanco)
            pantalla.blit(textoReinicio,(x+25,y+40,ancho,alto))
            textoReinicio = tipografiaReinicio.render('15 segundos inactivo', False, colorBlanco)
            pantalla.blit(textoReinicio,(x+25,y+70,ancho,alto))  

            #le avisamos cuanto tiempo debera estar en la pantalla, y que luego se actualice 
            pygame.display.update()
            time.sleep(5)
            #reiniciamos el nivel
            reiniciar()
            tr=0

def dibujarTodo():
    dibujarFondo()
    dibujarZonaDeTransporte()
    dibujarReglas()
    dibujar5QueJugaronPrimero()
    actualizarContadorDeElectricidad(0)
    actualizarContadorDePasos(0)
#llamamos a la función creada anteriormente para que cuando se dibuje todo se muestre el icono
    dibujarIcono()
    dibujarFelicitacion()
    pygame.display.update()

dibujarTodo()


#Creamos el bucle del juego
while not salirJuego:
    for event in pygame.event.get():
#Hicimos  un evento que permite salir del juego
        if event.type == pygame.QUIT:
            salirJuego = True
#Hicimos un evento que permite que al hacer click en cualquier parte de la pantalla llame a la funcion "funciónMudo" para que compruebe si se esta cliqueando el botón de mute 
        if event.type==pygame.MOUSEBUTTONDOWN:
            funcionMenu()
        if event.type == pygame.KEYDOWN:
            if nivel==2:
                avisarNivelEspejo()
                if event.key == pygame.K_RIGHT:
                    irALaIzquierda()
                elif event.key == pygame.K_LEFT:
                    irALaDerecha()
                elif event.key == pygame.K_UP:
                    irAbajo()
                elif event.key == pygame.K_DOWN:
                    irArriba()
                elif event.key == pygame.K_r:
                    if (juegoCompletado==False):
                        reiniciar()
                elif event.key == pygame.K_x:
                   if (juegoCompletado==False): 
                        retroceder()
            elif nivel==1 or nivel==3:
                if event.key == pygame.K_RIGHT:
                    irALaDerecha()
                elif event.key == pygame.K_LEFT:
                    irALaIzquierda()
                elif event.key == pygame.K_UP:
                    irArriba()
                elif event.key == pygame.K_DOWN:
                    irAbajo()
                elif event.key == pygame.K_r:
                    if (juegoCompletado==False):
                        reiniciar()
                elif event.key == pygame.K_x:
                   if (juegoCompletado==False): 
                        retroceder()
        dibujarZonaDeTransporte()
        reinicioAutomatico()
        dibujarFelicitacion()
        dibujarZonaDeTransporte()
        estaSolucionado()
    AnotarTiempoRestante()
    tiempo()
    mostrarIndicaciones()
pygame.quit()
        
quit()
