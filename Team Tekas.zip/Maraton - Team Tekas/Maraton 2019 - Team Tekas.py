#!/usr/bin/env python
#-*- coding: utf-8 -*-
#Inicio Ronda Final - Maratón 2019
#Team Tekas
#Integrantes: Lucas - Angel - Ramiro

import pygame
import random

#Inicializamos la librería Pygame y demás variables
pygame.init()
pygame.font.init() 
pygame.mixer.music.load("musicainicio.ogg")
pygame.mixer.music.play(-1)
pygame.display.set_caption("Maraton 2019 - Ronda Final - Team Tekas")
pantalla= pygame.display.set_mode((1152,648))
tipografia = pygame.font.SysFont('Comic Sans MS', 18)
tipografiaGrande=pygame.font.SysFont('Comic Sans MS', 24)
tipografiaGrande2=pygame.font.SysFont('Comic Sans MS', 24)
tipografiaGrande2.set_underline(True)
tipografiaFinal=pygame.font.SysFont('Arial', 45)

global ticksAlComenzar
global segundosSinMoverse
global cantidadDeEnergia
global lstComandosRealizados
global cantidadDePasos
global zonaDeTransporte
global imgAmenaza
global nivelCompletado
global puntuacion
global nombre
global escribirNombre
global colorAleatorio
global colorComando
global i

i=0
colorComando=('color',0,0,0)
colorAleatorio = (random.randrange(0,255),random.randrange(0,255),random.randrange(0,255))

ticksAlComenzar=pygame.time.get_ticks()
segundosSinMoverse=0
nivelCompletado=False
escribirNombre=False
nombre = ''

cantidadDePasos=0
cantidadDeEnergia=7000
colorVerde,colorAzul,colorBlanco,colorNegro, colorNaranja,colorAzul2,colorAmarillo,colorRojo= (0,255,0),(4,90,150),(255,255,255),(0,0,0),(239,27,126),(0,27,126),(255,255,10),(255,0,0)
cantidadDeCasillasPorLado=8 #Debe ser número par ya que la zona es un cuadrado
cantPixelesPorLadoCasilla=72
salirJuego = False
lstAreaProtegida=[]
lstComandosRealizados=[]

#Cargamos las imágenes
imgSuperTablet=pygame.image.load("supertablet.png")
imgPared=pygame.image.load("pared.jpg")
imgAreaProtegida=pygame.image.load("areaprotegida.png")
listaAmenazas  = ["Virus1.png","Virus2.png","Virus3.png","Virus4.png"]
imgAmenaza=pygame.image.load(str(random.choice(listaAmenazas)))

imgSuperTablet=pygame.transform.scale(imgSuperTablet, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
imgPared=pygame.transform.scale(imgPared, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
imgAmenaza=pygame.transform.scale(imgAmenaza, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
imgAreaProtegida=pygame.transform.scale(imgAreaProtegida, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))

#Sonidos 
sonidoMovimiento = pygame.mixer.Sound("movimiento.ogg")
sonidoEmpujar2virus = pygame.mixer.Sound("empujar2virus.wav")

#Creamos el mapa del nivel y algunas operaciones para los elementos que se encuentran dentro de la zona de transporte
def crearZonaDeTransporte():
    global imgAmenaza
    imgAmenaza=pygame.image.load(str(random.choice(listaAmenazas)))
    imgAmenaza=pygame.transform.scale(imgAmenaza, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))

    zonaDeTransporte = [[0 for x in range(cantidadDeCasillasPorLado+1)] for y in range(cantidadDeCasillasPorLado+1)] 
    
    zonaDeTransporte[1][2] = 'pared'        #pared arriba
    zonaDeTransporte[2][2] = 'pared'
    zonaDeTransporte[3][2] = 'pared'
    zonaDeTransporte[4][2] = 'pared'
    zonaDeTransporte[5][2] = 'pared'
    zonaDeTransporte[6][2] = 'pared'
    zonaDeTransporte[7][2] = 'pared'
    zonaDeTransporte[8][2] = 'pared'

    zonaDeTransporte[1][8] = 'pared'        #pared abajo
    zonaDeTransporte[2][8] = 'pared'
    zonaDeTransporte[3][8] = 'pared'
    zonaDeTransporte[4][8] = 'pared'
    zonaDeTransporte[5][8] = 'pared'
    zonaDeTransporte[6][8] = 'pared'
    zonaDeTransporte[7][8] = 'pared'
    zonaDeTransporte[8][8] = 'pared'

    zonaDeTransporte[1][3] = 'pared'        #pared izquierda
    zonaDeTransporte[1][4] = 'pared'
    zonaDeTransporte[1][5] = 'pared'
    zonaDeTransporte[1][6] = 'pared'
    zonaDeTransporte[1][7] = 'pared'
    
    zonaDeTransporte[8][3] = 'pared'        #pared derecha
    zonaDeTransporte[8][4] = 'pared'
    zonaDeTransporte[8][5] = 'pared'
    zonaDeTransporte[8][6] = 'pared'
    zonaDeTransporte[8][7] = 'pared'
    

    zonaDeTransporte[2][5] = 'jugador'

    zonaDeTransporte[3][5] = 'virus'      
    zonaDeTransporte[4][5] = 'virus'    
    zonaDeTransporte[5][5] = 'virus'    
    zonaDeTransporte[6][5] = 'virus' 
    zonaDeTransporte[5][6] = 'virus'  

    lstAreaProtegida.append((2,4))
    lstAreaProtegida.append((2,6))
    lstAreaProtegida.append((7,4))
    lstAreaProtegida.append((7,6))
    lstAreaProtegida.append((4,6))
    
    return zonaDeTransporte

zonaDeTransporte=crearZonaDeTransporte()

def hayAreaProtegidaEn(x,y):
    punto=(x,y)
    return lstAreaProtegida.__contains__(punto)

def posicionarElemento(elemento,x,y): 
    global zonaDeTransporte
    zonaDeTransporte[x][y]=elemento

def borrarElemento(x,y):
    global zonaDeTransporte
    zonaDeTransporte[x][y]=0
    
#Dibujamos la zona de transporte, fondo, reglas, contador de energía y contador de pasos
def dibujarZonaDeTransporte():     
    global zonaDeTransporte
    cnt = 0
    for i in range(1,cantidadDeCasillasPorLado+1):
        for j in range(1,cantidadDeCasillasPorLado+1):
            if cnt % 2 == 0:
                pygame.draw.rect(pantalla, colorAzul,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
            else:
                pygame.draw.rect(pantalla, colorAzul, [cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])        

            if (hayAreaProtegidaEn(j,i)==True):
                pantalla.blit(imgAreaProtegida, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i)) 
            if (zonaDeTransporte[j][i]=='jugador'):
               pantalla.blit(imgSuperTablet, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i)) 
            if (zonaDeTransporte[j][i]=='pared'):          
               pantalla.blit(imgPared, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
            if (zonaDeTransporte[j][i]=='virus'):
               pantalla.blit(imgAmenaza, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
            cnt +=1
        cnt-=1

    pygame.draw.rect(pantalla,colorBlanco,[cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla,cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla,cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla],1)       
    pygame.display.update()
    
def dibujarFondo():
    fondo = pygame.image.load("fondo.png")
    pantalla.blit(fondo, (0, 0))
    
def dibujarReglas():

    textoReglas = tipografia.render('Mover a Super Tablet con las flechas del teclado para llevar a los virus a las zonas protegidas', False, colorBlanco)
    textoReglas2 = tipografia.render('X-Deshacer el movimiento.   R-Reiniciar el nivel.   ESC-Salir del Juego', False, colorBlanco)

    ancho=810
    alto=46
    x=340
    y=3
    pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
    pantalla.blit(textoReglas,(x+5,y,ancho,alto))
    y=35
    alto=35
    pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
    pantalla.blit(textoReglas2,(x+5,y,ancho,alto))
    pygame.display.update()
    
def dibujarContadorDeElectricidad():
    global cantidadDeEnergia
    ancho=550
    alto=40
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=cantPixelesPorLadoCasilla*6
    pygame.draw.rect(pantalla,colorAzul2,(x,y,ancho,alto))
    textoEnergia = tipografiaGrande.render('Bateria disponible de Super Tablet: ' + str(cantidadDeEnergia) + 'mA', False, colorBlanco)
    pantalla.blit(textoEnergia,(x+5,y,ancho,alto))
    #Dibujo Batería Interactiva
    ancho=110
    alto=50
    carga=cantidadDeEnergia*100/7000
    x=175+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=cantPixelesPorLadoCasilla*5
    pygame.draw.rect(pantalla,colorNegro,(x,y,ancho,alto))
    pygame.draw.rect(pantalla,colorNegro,(x,y+15,ancho+10,alto-30))
    if(carga<20):                                    #Cambia el color de acuerdo a la carga   
        pygame.draw.rect(pantalla,colorRojo,(x+5,y+5,carga,alto-10))
    elif(carga<60):
        pygame.draw.rect(pantalla,colorAmarillo,(x+5,y+5,carga,alto-10))
    else:
        pygame.draw.rect(pantalla,colorVerde,(x+5,y+5,carga,alto-10))
    TextBateria = tipografiaGrande.render(str(carga)+"%",True,colorBlanco)
    pantalla.blit(TextBateria,(x+30,y+6))
    pygame.display.update()

def dibujarContadorDePasos():
    global cantidadDePasos                          
    ancho=350
    alto=40
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=cantPixelesPorLadoCasilla*7
    pygame.draw.rect(pantalla,colorAzul2,(x,y,ancho,alto))
    textoPasos = tipografiaGrande.render('Cantidad de movimientos: ' + str(cantidadDePasos), False, colorBlanco)
    pantalla.blit(textoPasos,(x+5,y,ancho,alto))
    pygame.display.update()

#Creamos operaciones para mostrar la felicitación y el cartel de ronda final
def dibujarFelicitacion():
    global nivelCompletado, cantidadDeEnergia

    x=50
    y=3
    ancho=200
    alto=46
    if (nivelCompletado==True):
        textoFelicitacion = tipografiaGrande.render('GANASTE :)', False, colorBlanco)
    else:
        if(cantidadDeEnergia<1400):
            textoFelicitacion = tipografiaGrande.render('BATERIA BAJA', False, colorBlanco)     #cambio el cartel si la batería es baja
        else:
            textoFelicitacion = tipografiaGrande.render('Juego en curso', False, colorBlanco)

    pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
    pantalla.blit(textoFelicitacion,(x+5,y,ancho,alto))
    pygame.display.update()

def dibujarCartelRondaFinal():
    textoFelicitacion = tipografiaGrande.render('RONDA FINAL', False, colorRojo)
    
    ancho=200
    alto=40
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=120
    pygame.draw.rect(pantalla,colorAleatorio,(x,y,ancho,alto))
    pantalla.blit(textoFelicitacion,(x+5,y,ancho,alto))
    pygame.display.update()

#Creamos operaciones relacionadas con la tabla de marcadores
def ordenarPuntaje(valor): 
    return valor[1]         #decimos que ordene la lista de acuerdo al segundo elemento 
    
def obtener5QueJugaronPrimero():
  file = open("puntuaciones.txt", "r")      #archivo que guarda los puntajes
  lstPuntuaciones=[]

  nombreAgregado=False
  par=[]      
  lineas= file.readlines()
  lineas = [line.strip() for line in open('puntuaciones.txt')]

  for line in lineas:
    
    if not (line==''):
        if (nombreAgregado==False):
            par=[]
            par.append(line)
            nombreAgregado=True
        else:    
            par.append(int(line))
            lstPuntuaciones.append(par)
            nombreAgregado=False
  
  lstPuntuaciones.sort(key = ordenarPuntaje, reverse = True)  #ordenamos la lista de acuerdo a los puntajes
  lstPuntuaciones = lstPuntuaciones[:5]     #solo mostramos los 5 primeros puestos
  file.close() 
  
  return lstPuntuaciones

#Creamos una operación que dibuje a los cinco que jugaron primero
def dibujar5QueJugaronPrimero():
    lst5Jugadores=obtener5QueJugaronPrimero()
    ancho=220
    alto=40
    x=350+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=121
    i=9
    
    textoRecord = tipografiaGrande2.render('RECORDS', False, colorNaranja)
    pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
    pantalla.blit(textoRecord,(x+5,y,ancho,alto))
    
    for par in lst5Jugadores:
        y=(32*i)-135
        textoRanking = tipografiaGrande.render(str(par[0]) + ': ' + str(par[1]), False, colorBlanco)
        pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
        pantalla.blit(textoRanking,(x+5,y,ancho,alto))
        i=i+1
    
    pygame.display.update()
    
#Creamos una operación que dibuje todo
def dibujarTodo():
    dibujarFondo()
    dibujarZonaDeTransporte()
    dibujarCartelRondaFinal()
    dibujarReglas()
    dibujar5QueJugaronPrimero()
    dibujarContadorDeElectricidad()
    dibujarContadorDePasos()
    pygame.display.update()

#Actualizamos el contador de segundos jugados, pasos de Super Tablet y el contador de energía
def actualizarTiempoDeJuego():
    global segundos
    ancho=350
    alto=40
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=cantPixelesPorLadoCasilla*8
    pygame.draw.rect(pantalla,colorAzul2,(x,y,ancho,alto))
    textoSegundos = tipografiaGrande.render('Segundos transcurridos: ' + str(segundos), False, colorBlanco)
    pantalla.blit(textoSegundos,(x+5,y,ancho,alto))
    pygame.display.update()

def actualizarContadorDePasos(num):
    global cantidadDePasos, segundosSinMoverse
    global colorAleatorio
    cantidadDePasos=cantidadDePasos+num
    sonidoMovimiento.play()                 #Sonido al moverse
    
    segundosSinMoverse=segundos
    dibujarContadorDePasos()

def actualizarContadorDeElectricidad(num):
    global cantidadDeEnergia
    cantidadDeEnergia=cantidadDeEnergia-num
    dibujarContadorDeElectricidad()

#Creamos una operación que indique si el nivel fue solucionado
def estaSolucionado():
    global nivelCompletado
    global zonaDeTransporte

    cantVirusSobreAreasProtegidas=0

    for punto in lstAreaProtegida:
        x=punto[0]
        y=punto[1]
        if zonaDeTransporte[x][y]=='virus':
            cantVirusSobreAreasProtegidas=cantVirusSobreAreasProtegidas+1       

    if (cantVirusSobreAreasProtegidas==len(lstAreaProtegida)):
        nivelCompletado=True
        dibujarFelicitacion()

    else:
        nivelCompletado=False

    dibujarFelicitacion()
    dibujarCartelRondaFinal()
    dibujarReglas()
    
#Creamos operaciones para mover a Super Tablet
def irALaDerecha():
    global zonaDeTransporte, colorAleatorio
    for i in range(1,cantidadDeCasillasPorLado):
        for j in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                if (zonaDeTransporte[j+1][i]==0):
                    posicionarElemento('jugador',j+1,i)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(10)
                    borrarElemento(j,i)
                    comando=('jugador',j,i)       
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j+1,i)       
                    lstComandosRealizados.append(comando)
                    colorAleatorio = (random.randrange(0,255),random.randrange(0,255),random.randrange(0,255))      #elegimos un color aleatorio
                    comando=('color',colorAleatorio[0],colorAleatorio[1],colorAleatorio[2])
                    lstComandosRealizados.append(comando)
                    #print(comando)
                    break
                if(zonaDeTransporte[j+1][i]=='virus') and not ((zonaDeTransporte[j+2][i]=='pared') or (zonaDeTransporte[j+2][i]=='virus')):                  
                    posicionarElemento('virus',j+2,i)
                    posicionarElemento('jugador',j+1,i)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(15)
                    borrarElemento(j,i)
                    comando=('jugador',j,i)       
                    lstComandosRealizados.append(comando)
                    comando=('virus',j+1,i)
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j+1,i)       
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j+2,i)       
                    lstComandosRealizados.append(comando)
                    colorAleatorio = (random.randrange(0,255),random.randrange(0,255),random.randrange(0,255))  #elegimos un color aleatorio
                    comando=('color',colorAleatorio[0],colorAleatorio[1],colorAleatorio[2])
                    lstComandosRealizados.append(comando)
                    break
                if(zonaDeTransporte[j+1][i]=='virus') and (zonaDeTransporte[j+2][i]=='virus'):
                    actualizarContadorDeElectricidad(200)
                    sonidoEmpujar2virus.play()          #Sonido al empujar 2 virus
                    comando=('hicemuchafuerza',0,0)
                    lstComandosRealizados.append(comando) 
                    break

def irArriba():
    global zonaDeTransporte, colorAleatorio
    global lstComandosRealizados   
    for i in range(1,cantidadDeCasillasPorLado):
        for j in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                if (zonaDeTransporte[j][i-1]==0):
                    posicionarElemento('jugador',j,i-1)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(10)
                    borrarElemento(j,i)
                    comando=('jugador',j,i)       
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j,i-1)       
                    lstComandosRealizados.append(comando)
                    colorAleatorio = (random.randrange(0,255),random.randrange(0,255),random.randrange(0,255))  #elegimos un color aleatorio
                    comando=('color',colorAleatorio[0],colorAleatorio[1],colorAleatorio[2])
                    lstComandosRealizados.append(comando)
                    break
                if(zonaDeTransporte[j][i-1]=='virus') and not ((zonaDeTransporte[j][i-2]=='pared') or (zonaDeTransporte[j][i-2]=='virus')):
                    posicionarElemento('virus',j,i-2)
                    posicionarElemento('jugador',j,i-1)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(15)
                    borrarElemento(j,i)
                    comando=('jugador',j,i)       
                    lstComandosRealizados.append(comando)
                    comando=('virus',j,i-1)
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j,i-1)       
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j,i-2)       
                    lstComandosRealizados.append(comando)
                    colorAleatorio = (random.randrange(0,255),random.randrange(0,255),random.randrange(0,255))  #elegimos un color aleatorio
                    comando=('color',colorAleatorio[0],colorAleatorio[1],colorAleatorio[2])
                    lstComandosRealizados.append(comando)                    
                    break
                if(zonaDeTransporte[j][i-1]=='virus') and (zonaDeTransporte[j][i-2]=='virus'):
                    actualizarContadorDeElectricidad(200)
                    sonidoEmpujar2virus.play()          #Sonido al empujar 2 virus
                    comando=('hicemuchafuerza',0,0)
                    lstComandosRealizados.append(comando) 
                    break

def irAbajo():
    global zonaDeTransporte, colorAleatorio
    for j in range(1,cantidadDeCasillasPorLado):
        for i in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                if (zonaDeTransporte[j][i+1]==0):
                    posicionarElemento('jugador',j,i+1)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(10)
                    borrarElemento(j,i)
                    comando=('jugador',j,i)       
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j,i+1)       
                    lstComandosRealizados.append(comando)
                    colorAleatorio = (random.randrange(0,255),random.randrange(0,255),random.randrange(0,255))  #elegimos un color aleatorio
                    comando=('color',colorAleatorio[0],colorAleatorio[1],colorAleatorio[2])
                    lstComandosRealizados.append(comando)                    
                    break
                if(zonaDeTransporte[j][i+1]=='virus') and not ((zonaDeTransporte[j][i+2]=='pared') or (zonaDeTransporte[j][i+2]=='virus')):
                    posicionarElemento('virus',j,i+2)
                    posicionarElemento('jugador',j,i+1)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(15)
                    borrarElemento(j,i)
                    comando=('jugador',j,i)       
                    lstComandosRealizados.append(comando)
                    comando=('virus',j,i+1)
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j,i+1)       
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j,i+2)       
                    lstComandosRealizados.append(comando)
                    colorAleatorio = (random.randrange(0,255),random.randrange(0,255),random.randrange(0,255))  #elegimos un color aleatorio
                    comando=('color',colorAleatorio[0],colorAleatorio[1],colorAleatorio[2])
                    lstComandosRealizados.append(comando)                    
                    break
                if(zonaDeTransporte[j][i+1]=='virus') and (zonaDeTransporte[j][i+2]=='virus'):
                    actualizarContadorDeElectricidad(200)
                    sonidoEmpujar2virus.play()          #Sonido al empujar 2 virus
                    comando=('hicemuchafuerza',0,0)
                    lstComandosRealizados.append(comando) 
                    break

def irALaIzquierda():
    global zonaDeTransporte, colorAleatorio
    for i in range(1,cantidadDeCasillasPorLado):
        for j in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                if (zonaDeTransporte[j-1][i]==0):
                    posicionarElemento('jugador',j-1,i)              
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(10)
                    borrarElemento(j,i)
                    comando=('jugador',j,i)       
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j-1,i)       
                    lstComandosRealizados.append(comando)
                    colorAleatorio = (random.randrange(0,255),random.randrange(0,255),random.randrange(0,255))  #elegimos un color aleatorio
                    comando=('color',colorAleatorio[0],colorAleatorio[1],colorAleatorio[2])
                    lstComandosRealizados.append(comando)                    
                    break
                if(zonaDeTransporte[j-1][i]=='virus') and not ((zonaDeTransporte[j-2][i]=='pared') or (zonaDeTransporte[j-2][i]=='virus')):
                    posicionarElemento('virus',j-2,i)
                    posicionarElemento('jugador',j-1,i)
                    actualizarContadorDePasos(1)
                    actualizarContadorDeElectricidad(15)
                    comando=('jugador',j,i)       
                    lstComandosRealizados.append(comando)
                    comando=('virus',j-1,i)
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j-1,i)       
                    lstComandosRealizados.append(comando)
                    comando=('borrar',j-2,i)       
                    lstComandosRealizados.append(comando)               
                    borrarElemento(j,i)
                    colorAleatorio = (random.randrange(0,255),random.randrange(0,255),random.randrange(0,255))  #elegimos un color aleatorio
                    comando=('color',colorAleatorio[0],colorAleatorio[1],colorAleatorio[2])
                    lstComandosRealizados.append(comando)                    
                    break
                if(zonaDeTransporte[j-1][i]=='virus') and (zonaDeTransporte[j-2][i]=='virus'):
                    actualizarContadorDeElectricidad(200)
                    sonidoEmpujar2virus.play()          #Sonido al empujar 2 virus
                    comando=('hicemuchafuerza',0,0)
                    lstComandosRealizados.append(comando) 
                    break

#Creamos una operación que vuelva hacia atrás la última movida
def deshacerMovida():
    global zonaDeTransporte
    global cantidadDePasos
    global colorAleatorio
    global i
    
    if (len(lstComandosRealizados)>0):  
        comando=lstComandosRealizados.pop()
        #print(lstComandosRealizados)
        if (comando[0]=='color'and i==0):
                   
            colorAleatorio= (comando[1],comando[2],comando[3])
            dibujarCartelRondaFinal()
            print(i)
            deshacerMovida()
            
        if (comando[0]=='hicemuchafuerza'):
            actualizarContadorDeElectricidad(-200)
            deshacerMovida()
        if (comando[0]=='borrar'):
            borrarElemento(comando[1],comando[2])
            deshacerMovida()
        if (comando[0]=='virus'):
            posicionarElemento(comando[0],comando[1],comando[2])  
            actualizarContadorDeElectricidad(-5)
            deshacerMovida() 
        if (comando[0]=='jugador'):
            posicionarElemento(comando[0],comando[1],comando[2])
            actualizarContadorDePasos(-1)  
            actualizarContadorDeElectricidad(-10)
            if(i==0):
                i=1
                deshacerMovida()
        if (comando[0]=='color'and i==1):
            i=0
            colorAleatorio= (comando[1],comando[2],comando[3])
            
            
            
        
    dibujarZonaDeTransporte()

#Creamos una operación para resetear el juego 
def resetearJuego():
    global zonaDeTransporte, cantidadDeEnergia, cantidadDePasos, lstComandosRealizados 
    global ticksAlComenzar, segundosSinMoverse, nombre
    zonaDeTransporte=crearZonaDeTransporte()
    cantidadDePasos=0
    cantidadDeEnergia=7000
    nombre = ''
    ticksAlComenzar=pygame.time.get_ticks()
    segundosSinMoverse=0
    segundos=0
    lstComandosRealizados[:] = []
    dibujarTodo()



#Función para mostrar la pantalla cuando inicia el juego
def pantallaInicio():
    global ticksAlComenzar
    FondoFinal = pygame.image.load("FondoInicio.jpg")
    FondoFinal = pygame.transform.scale(FondoFinal, (1152,648))
    pantalla.blit(FondoFinal,(0,0))
    pygame.display.update()
    pygame.time.wait(3000)
    ticksAlComenzar=pygame.time.get_ticks()

#Función para mostrar la pantalla cuando ganas
def Finalizaste():
    global puntuacion
    global escribirNombre

    if(segundos!=0):
        puntuacion=cantidadDeEnergia/segundos       #Calculamos el puntaje
    x=330
    y=175
    ancho=325
    alto=30
    ancho2=600
    alto2=60
    FondoFinal = pygame.image.load("FondoFinal.jpg")
    FondoFinal = pygame.transform.scale(FondoFinal, (1152,648))
    pantalla.blit(FondoFinal,(0,0))

    TextGanaste = tipografiaFinal.render("Felicidades por pasar el juego ;v",True,colorBlanco)
    TextGanaste2 = tipografiaFinal.render("Tu Puntaje es:  "+ str(puntuacion),True,colorBlanco)
    TextGanaste3 = tipografiaFinal.render("Ingresa tu Nombre:",True,colorBlanco)
    
    pygame.draw.rect(pantalla,colorNegro,(x-30,y-70,ancho2,alto2))
    
    pantalla.blit(TextGanaste,(x,y-70))
    pantalla.blit(TextGanaste2,(x+60,y+60))
    pantalla.blit(TextGanaste3,(x+70,y+120))
    
    escribirNombre=True
    pygame.display.update()
    actualizarNombre()

#Actualizamos nombre a medida que se ingresa
def actualizarNombre():
    global nombre

    x=400
    y=375
    ancho=325
    alto=35
    TextNombre = tipografiaGrande.render(str(nombre),True,colorNegro)
    pygame.draw.rect(pantalla,colorBlanco,(x,y,ancho,alto))
    pantalla.blit(TextNombre,(x+10,y))
    pygame.display.update()

#Creamos una función para guardar el nombre y el puntaje en un archivo txt
def guardarPuntuacion():
    global nombre
    global puntuacion

    if(nombre == ''):
        nombre='jugador'
    archivo=open("puntuaciones.txt","a")         #Creamos el archivo txt
    escribir=str(nombre)+"\n"
    escribir2=str(puntuacion)+"\n"
    archivo.write(escribir)                 #Escribimos los renglones 
    archivo.write(escribir2)
    archivo.close()                         #Cerramos el archivo 
    
#Creamos una operación para resetear el juego si Super Tablet no tiene más batería
def estaSinBateria():
    global cantidadDeEnergia
    if (nivelCompletado==False) and (cantidadDeEnergia<=0):
        resetearJuego()

#Creamos una operación para resetear el juego si Super Tablet paso más de 15 segundos inactivo
def pasoTiempoInactivo():
    global segundosSinMoverse    
    if (nivelCompletado==False) and (segundos - segundosSinMoverse >= 15):       #Preguntamos si pasaron 15 segundos
        resetearJuego()

pantallaInicio()    #Dibujamos la pantalla de inicio
dibujarTodo()
#Creamos el bucle del juego
while not salirJuego:
    if (not escribirNombre):
        segundos=(pygame.time.get_ticks()-ticksAlComenzar)/1000
        actualizarTiempoDeJuego()

    pasoTiempoInactivo()                #pregunta si pasarón 15 segundos sin moverse 

    if (nivelCompletado):               #pregunta si se completo el nivel
        Finalizaste()
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            salirJuego = True

        if(escribirNombre):             #comandos para escribir el nombre en pantalla
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    escribirNombre=False
                    nivelCompletado=False
                    guardarPuntuacion()
                    resetearJuego()
                elif event.key == pygame.K_BACKSPACE:
                    nombre = nombre[:-1]
                    actualizarNombre()
                else:
                    nombre += event.unicode
                    actualizarNombre()
                        
        else:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:    #salir al presionar escape 
                    salirJuego = True   
                elif event.key == pygame.K_RIGHT:
                    irALaDerecha()
                elif event.key == pygame.K_LEFT:
                    irALaIzquierda()
                elif event.key == pygame.K_UP:
                    irArriba()
                elif event.key == pygame.K_DOWN:
                    irAbajo()
                elif event.key == pygame.K_x:
                    deshacerMovida()
                elif event.key == pygame.K_r:
                    resetearJuego()
            dibujarZonaDeTransporte()
            estaSolucionado()
            estaSinBateria()
        
pygame.quit()
