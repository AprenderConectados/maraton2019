#!/usr/bin/env python
#-*- coding: utf-8 -*-
import pygame
import random

#Inicializamos la librería Pygame y demás variables
pygame.init()
pygame.font.init()

listafinal=[]

#Configuramos las tipografías, el tamaño, las fuentes y demás.
tipografiaGrande=pygame.font.SysFont('Arial', 24)
tipografiatitulo = pygame.font.SysFont("Calibri", 58, bold = True)
tipografiaPuNom = pygame.font.SysFont("Calibri", 30, bold = True)
tipografiaLIST = pygame.font.SysFont("Calibri", 30, bold = True)
tipografia5mejores= pygame.font.SysFont("Calibri",20,bold = True)##################################################
tipografiaLIST2 = pygame.font.SysFont("Calibri", 20, bold = True)###############################################3


#Definimos los colores que utilizaremos.
colorBlanco,colorNegro,colorLila,colorAzul=(255,255,255),(0,0,0),(80,50,75),(0,0,255)


    #Imprime en pantalla la lista de los jugadores    
def jugadores(tope, pantalla, ranking, nivel):
    global listafinal,colorNegro,colorBlanco,tipografiatitulo
    trofeo = pygame.image.load("trofeo.png")
    if len(listafinal)>tope:
        largo=tope
    else:
        largo = len(listafinal)

    #si le funcion jugadores  es llamada cuando termina la partida se carga una pantalla y se muestra los campeones
    if tope == 8:
        x=350
        y=100
        listafinal=archileer(ranking, nivel)  
        pygame.display.set_caption("ranking")
        fondo = pygame.image.load("fondoMenu.png")
        fondo = pygame.transform.scale(fondo, (1152,648))
        pantalla.blit(fondo, (0,0))
        pantalla.blit(trofeo,(x+140,y-80))
        titulo = tipografiatitulo.render("Los Campeones", False,colorBlanco)
        titulonombre =tipografiaPuNom.render("Puntaje:    Nombre:"   ,False,colorBlanco)
        pantalla.blit(titulo,(x,y))
        y=y+80
        pantalla.blit(titulonombre,(x,y))
        y=y+50 
    
        for i in range(largo):
            puntju= tipografiaLIST.render(listafinal[i],False,colorBlanco)
            pantalla.blit(puntju,(x,y,500,500))
            y=y+50
    
        pygame.display.update()
        pygame.time.delay(5000)

    #si la funcion es llamada durante la partida se muestran los 5 mejores en el juego 
    if tope==5:##########################
        x=700#####################
        y=60################
        pygame.draw.rect(pantalla,colorLila,(x,y,350,200))#####################################
        trofeo = pygame.transform.scale(trofeo,(50,50)) 
        mejores = tipografia5mejores.render("Los 5 Mejores",False,colorBlanco)#####################
        pantalla.blit(mejores,(x+100,y+25))######################################33
        pantalla.blit(trofeo,(x+23,y+23))################################
        for i in range(largo):#################################################
            puntju2= tipografiaLIST2.render(listafinal[i],False,colorBlanco)############################################3
            pantalla.blit(puntju2,(x+50,y+50))##################################3
            y=y+20#########################################
            
        pygame.display.update()#######################
        
def archileer(ranking, nivel):
    global listafinal
    #abre el archivo de texto lo separa en el ";" lo carga en una lista lo ordena y lo invierte
    archivo=open(ranking,"r")
    datosjugadores = archivo.readline()
    listafinal = datosjugadores.split(";")
    listafinal.sort()
    if nivel<>3:
        listafinal.reverse()
    archivo.close()
    return listafinal

#Esta funcion carga la pantalla para ingresar el nombre del jugador
def pantallaNOM(pantalla):
    pygame.display.set_caption("ingreso nombre por teclado")
    fondo = pygame.image.load("nombre3.png")
    fondo = pygame.transform.scale(fondo, (1152,648))
    pantalla.blit(fondo, (0,0))
    pygame.display.update()
    
#esta funcion imprime en el archivo de texto  el puntaje y la lista que contiene las letras que forman el nombre de jugador
def grabararchiv(ranking, puntaje, lista, indice): 
    archivo=open(ranking,"a")
    archivo.write("%10s %4s" % (str(puntaje) ," "))
    for i in range(indice+1):
        archivo.write(lista[i])
    archivo.write(";")
    archivo.close()
    
#Esta funcion esta hecha para que se puedan eliminar las lista de jugador, si no existe lo crea y si existe lo sobreescribe  
def reset():
    archivo=open("facilrankingN1.txt","w")############################################
    archivo.close()
    archivo=open("facilrankingN2.txt","w")#########################################
    archivo.close()
    archivo=open("facilrankingN3.txt","w")#########################################
    archivo.close()
    archivo=open("dificilrankingN1.txt","w")##################################33
    archivo.close()
    archivo=open("dificilrankingN2.txt","w")####################################
    archivo.close()
    archivo=open("dificilrankingN3.txt","w")###############################

puntero = pygame.image.load('puntero.png')
punteroRect=puntero.get_rect()

botonRanking = pygame.image.load('botonReiniciarRanking.png')
botonRankingPresionado = pygame.image.load('botonReiniciarRankingPresionado.png')
botonRanking =pygame.transform.scale(botonRanking, (70, 70))
botonRankingPresionado =pygame.transform.scale(botonRankingPresionado, (68, 68))
botonActualRanking=botonRanking
botonRectRanking=botonActualRanking.get_rect()
botonRectRanking.center=(40,600)

def BotonRanking(botonRanking, botonRankingPresionado):
    global punteroRect, botonRectRanking, botonActualRanking
    if punteroRect.colliderect(botonRectRanking):
        botonActualRanking=botonRankingPresionado
    else:
        botonActualRanking=botonRanking
    return botonActualRanking

boton = pygame.image.load('botonReiniciarEnCurso.png')
boton =pygame.transform.scale(boton, (100, 100))
botonActual=boton
botonRect=botonActual.get_rect()
botonRect.center=(750,600)

def BotonReiniciar(boton):
    global punteroRect, botonRect, botonActual
    if punteroRect.colliderect(botonRect):
        botonActual=boton
    else:
        botonActual=boton
    return botonActual

botonReiniciarMulti = pygame.image.load('botonReiniciarJuegoEnCursoSegundo.png')
botonReiniciarMulti = pygame.transform.scale(botonReiniciarMulti, (100, 100))
botonActualReiniciarMulti = botonReiniciarMulti
botonRectReiniciarMulti=botonActualReiniciarMulti.get_rect()
botonRectReiniciarMulti.center=(650,600)

def BotonReiniciarMulti(botonReiniciarMulti):
    global punteroRect, botonRectReiniciarMulti, botonActualReiniciarMulti
    if punteroRect.colliderect(botonRectReiniciarMulti):
        botonActualReiniciarMulti=botonReiniciarMulti
    else:
        botonActualReiniciarMulti=botonReiniciarMulti
    return botonActualReiniciarMulti

boton2 = pygame.image.load('botonSalirDeJuegoEnCurso.png')
boton2 =pygame.transform.scale(boton2, (100, 100))
botonActual2=boton2
botonRect2=botonActual2.get_rect()
botonRect2.center=(1050,600)

def BotonSalir(boton2):
    global punteroRect, botonRect2, botonActual2
    if punteroRect.colliderect(botonRect2):
        botonActual2=boton2
    else:
        botonActual2=boton2
    return botonActual2

boton3 = pygame.image.load('botonPasoAnterior.png')
boton3 =pygame.transform.scale(boton3, (100, 100))
botonActual3=boton3
botonRect3=botonActual3.get_rect()
botonRect3.center=(900,600)

def BotonDeshacer(boton3):
    global punteroRect, botonRect3, botonActual3
    if punteroRect.colliderect(botonRect3):
        botonActual3=boton3
    else:
        botonActual3=boton3
    return botonActual3

botonJugar = pygame.image.load('botonJugar2.png')
botonJugar2 = pygame.image.load('botonJugar.png')
botonJugar = pygame.transform.scale(botonJugar, (140, 140))
botonJugar2 = pygame.transform.scale(botonJugar2, (140, 140))
botonActualJugar=botonJugar
botonRectJugar=botonActualJugar.get_rect()
botonRectJugar.center=(160,340)

def BotonJugar(botonJugar, botonJugar2):
    global punteroRect, botonRectJugar, botonActualJugar
    if punteroRect.colliderect(botonRectJugar):
        botonActualJugar=botonJugar
    else:
        botonActualJugar=botonJugar2
    return botonActualJugar

botonOpciones = pygame.image.load('botonOpciones2.png')
botonOpciones2 = pygame.image.load('botonOpciones.png')
botonOpciones = pygame.transform.scale(botonOpciones, (140, 140))
botonOpciones2 = pygame.transform.scale(botonOpciones2, (140, 140))
botonActualOpciones=botonOpciones
botonRectOpciones=botonActualOpciones.get_rect()
botonRectOpciones.center=(367,340)
                              

def BotonOpciones(botonOpciones, botonOpciones2):
    global punteroRect, botonRectOpciones, botonActualOpciones
    if punteroRect.colliderect(botonRectOpciones):
        botonActualOpciones=botonOpciones
    else:
        botonActualOpciones=botonOpciones2
    return botonActualOpciones

botonGuia = pygame.image.load('botonGuia2.png')
botonGuia2 = pygame.image.load('botonGuia.png')
botonGuia = pygame.transform.scale(botonGuia, (140, 140))
botonGuia2 = pygame.transform.scale(botonGuia2, (140, 140))
botonActualGuia=botonGuia
botonRectGuia=botonActualGuia.get_rect()
botonRectGuia.center=(574,340)

def BotonGuia(botonGuia, botonGuia2):
    global punteroRect, botonRectGuia, botonActualGuia
    if punteroRect.colliderect(botonRectGuia):
        botonActualGuia=botonGuia
    else:
        botonActualGuia=botonGuia2
    return botonActualGuia

botonLogros = pygame.image.load('botonLogros2.png')
botonLogros2 = pygame.image.load('botonLogros.png')
botonLogros = pygame.transform.scale(botonLogros, (140, 140))
botonLogros2 = pygame.transform.scale(botonLogros2, (140, 140))
botonActualLogros=botonLogros
botonRectLogros=botonActualLogros.get_rect()
botonRectLogros.center=(785,340)

def BotonLogros(botonLogros, botonLogros2):
    global punteroRect, botonRectLogros, botonActualLogros
    if punteroRect.colliderect(botonRectLogros):
        botonActualLogros=botonLogros
    else:
        botonActualLogros=botonLogros2
    return botonActualLogros

botonSalirMenu = pygame.image.load('botonSalirMenu2.png')
botonSalirMenu2 = pygame.image.load('botonSalirMenu.png')
botonSalirMenu = pygame.transform.scale(botonSalirMenu, (140, 140))
botonSalirMenu2 = pygame.transform.scale(botonSalirMenu2, (140, 140))
botonActualSalirMenu=botonSalirMenu
botonRectSalirMenu=botonActualSalirMenu.get_rect()
botonRectSalirMenu.center=(996,340)

def BotonSalirMenu(botonSalirMenu, botonSalirMenu2):
    global punteroRect, botonRectSalirMenu, botonActualSalirMenu
    if punteroRect.colliderect(botonRectSalirMenu):
        botonActualSalirMenu=botonSalirMenu
    else:
        botonActualSalirMenu=botonSalirMenu2
    return botonActualSalirMenu

botonUnJugador = pygame.image.load('botonUnJugador.png')
botonUnJugador = pygame.transform.scale(botonUnJugador, (140, 140))
botonActualUnJugador = botonUnJugador
botonRectUnJugador = botonActualUnJugador.get_rect()
botonRectUnJugador.center=(470,340)

def BotonUnJugador(botonUnJugador):
    global punteroRect, botonRectUnJugador, botonActualUnJugador
    if punteroRect.colliderect(botonRectUnJugador):
        botonActualUnJugador=botonUnJugador
    else:
        botonActualUnJugador=botonUnJugador
    return botonActualUnJugador

botonMultijugador = pygame.image.load('botonMultijugador.png')
botonMultijugador = pygame.transform.scale(botonMultijugador, (140, 140))
botonActualMultijugador=botonMultijugador
botonRectMultijugador=botonActualMultijugador.get_rect()
botonRectMultijugador.center=(670,340)

def BotonMultijugador(botonMultijugador):
    global punteroRect, botonRectMultijugador, botonActualMultijugador
    if punteroRect.colliderect(botonRectMultijugador):
        botonActualMultijugador=botonMultijugador
    else:
        botonActualMultijugador=botonMultijugador
    return botonActualMultijugador

botonDificil = pygame.image.load('botonDificil.png')
botonDificil = pygame.transform.scale(botonDificil, (140, 140))
botonActualDificil=botonDificil
botonRectDificil=botonActualDificil.get_rect()
botonRectDificil.center=(670,340)

def BotonDificil(botonDificil):
    global punteroRect, botonRectDificil, botonActualDificil
    if punteroRect.colliderect(botonRectDificil):
        botonActualDificil=botonDificil
    else:
        botonActualDificil=botonDificil
    return botonActualDificil

botonFacil = pygame.image.load('botonFacil.png')
botonFacil = pygame.transform.scale(botonFacil, (140, 140))
botonActualFacil=botonFacil
botonRectFacil=botonActualFacil.get_rect()
botonRectFacil.center=(470,340)

def BotonFacil(botonFacil):
    global punteroRect, botonRectFacil, botonActualFacil
    if punteroRect.colliderect(botonRectFacil):
        botonActualFacil=botonFacil
    else:
        botonActualFacil=botonFacil
    return botonActualFacil

botonVolver = pygame.image.load('botonVolver.png')
botonVolver = pygame.transform.scale(botonVolver, (140, 140))
botonActualVolver = botonVolver
botonRectVolver = botonActualVolver.get_rect()
botonRectVolver.center=(50,60)

def BotonVolver(botonVolver):
    global punteroRect, botonRectVolver, botonActualVolver
    if punteroRect.colliderect(botonRectVolver):
        botonActualVolver=botonVolver
    else:
        botonActualVolver=botonVolver
    return botonActualVolver

botonLVL3Expli = pygame.image.load('nvl3.jpg')
botonLVL3Expli = pygame.transform.scale(botonLVL3Expli, (300, 300))
botonLVL3ExpliImg = pygame.image.load('nvl3Expli.jpg')
botonLVL3ExpliImg = pygame.transform.scale(botonLVL3ExpliImg, (300, 300))
botonActualLVL3Expli = botonLVL3Expli
botonRectLVL3Expli = botonActualLVL3Expli.get_rect()
botonRectLVL3Expli.center=(900,240)

def BotonLVL3Expli(botonLVL3Expli, botonLVL3ExpliImg):
    global punteroRect, botonRectLVL3Expli, botonActualLVL3Expli
    if punteroRect.colliderect(botonRectLVL3Expli):
        botonActualLVL3Expli=botonLVL3ExpliImg
    else:
        botonActualLVL3Expli=botonLVL3Expli
    return botonActualLVL3Expli

botonLVL2Expli = pygame.image.load('nvl2.jpg')
botonLVL2Expli = pygame.transform.scale(botonLVL2Expli, (300, 300))
botonLVL2ExpliImg = pygame.image.load('nvl2Expli.jpg')
botonLVL2ExpliImg = pygame.transform.scale(botonLVL2ExpliImg, (300, 300))
botonActualLVL2Expli = botonLVL2Expli
botonRectLVL2Expli = botonActualLVL2Expli.get_rect()
botonRectLVL2Expli.center=(570,240)

def BotonLVL2Expli(botonLVL2Expli, botonLVL2ExpliImg):
    global punteroRect, botonRectLVL2Expli, botonActualLVL2Expli
    if punteroRect.colliderect(botonRectLVL2Expli):
        botonActualLVL2Expli=botonLVL2ExpliImg
    else:
        botonActualLVL2Expli=botonLVL2Expli
    return botonActualLVL2Expli

botonLVL1Expli = pygame.image.load('nvl1.jpg')
botonLVL1Expli = pygame.transform.scale(botonLVL1Expli, (300, 300))
botonLVL1ExpliImg = pygame.image.load('nvl1Expli.jpg')
botonLVL1ExpliImg = pygame.transform.scale(botonLVL1ExpliImg, (300, 300))
botonActualLVL1Expli = botonLVL1Expli
botonRectLVL1Expli = botonActualLVL1Expli.get_rect()
botonRectLVL1Expli.center=(240,240)

def BotonLVL1Expli(botonLVL1Expli, botonLVL1ExpliImg):
    global punteroRect, botonRectLVL1Expli, botonActualLVL1Expli
    if punteroRect.colliderect(botonRectLVL1Expli):
        botonActualLVL1Expli=botonLVL1ExpliImg
    else:
        botonActualLVL1Expli=botonLVL1Expli
    return botonActualLVL1Expli

botonLVL1 = pygame.image.load('lvl1.png')
botonLVL1 = pygame.transform.scale(botonLVL1, (140, 140))
botonActualLVL1 = botonLVL1
botonRectLVL1 = botonActualLVL1.get_rect()
botonRectLVL1.center=(240,440)

def BotonLVL1(botonLVL1):
    global punteroRect, botonRectLVL1, botonActualLVL1
    if punteroRect.colliderect(botonRectLVL1):
        botonActualLVL1=botonLVL1
    else:
        botonActualLVL1=botonLVL1
    return botonActualLVL1

botonLVL2 = pygame.image.load('lvl2.png')
botonLVL2 = pygame.transform.scale(botonLVL2, (140, 140))
botonActualLVL2 = botonLVL2
botonRectLVL2 = botonActualLVL2.get_rect()
botonRectLVL2.center=(570,440)

def BotonLVL2(botonLVL2):
    global punteroRect, botonRectLVL2, botonActualLVL2
    if punteroRect.colliderect(botonRectLVL2):
        botonActualLVL2=botonLVL2
    else:
        botonActualLVL2=botonLVL2
    return botonActualLVL2

botonLVL3 = pygame.image.load('lvl3.png')
botonLVL3 = pygame.transform.scale(botonLVL3, (140, 140))
botonActualLVL3 = botonLVL3
botonRectLVL3 = botonActualLVL3.get_rect()
botonRectLVL3.center=(900,440)

def BotonLVL3(botonLVL3):
    global punteroRect, botonRectLVL3, botonActualLVL3
    if punteroRect.colliderect(botonRectLVL3):
        botonActualLVL3=botonLVL3
    else:
        botonActualLVL3=botonLVL3
    return botonActualLVL3

######################### BOTONES PARA PANTALLA 'OPCIONES' #############################

botonTeclas = pygame.image.load('botonTeclas.png')
botonTeclas = pygame.transform.scale(botonTeclas, (140, 140))
botonActualTeclas = botonTeclas
botonRectTeclas = botonActualTeclas.get_rect()
botonRectTeclas.center=(570,150)

def BotonTeclas(botonTeclas):
    global punteroRect, botonRectTeclas, botonActualTeclas
    if punteroRect.colliderect(botonRectTeclas):
        botonActualTeclas=botonTeclas
    else:
        botonActualTeclas=botonTeclas
    return botonActualTeclas

botonPantalla = pygame.image.load('botonPantalla.png')
botonPantalla = pygame.transform.scale(botonPantalla, (140, 140))
botonActualPantalla = botonPantalla
botonRectPantalla = botonActualPantalla.get_rect()
botonRectPantalla.center=(570,250)

def BotonPantalla(botonPantalla):
    global punteroRect, botonRectPantalla, botonActualPantalla
    if punteroRect.colliderect(botonRectPantalla):
        botonActualPantalla=botonPantalla
    else:
        botonActualPantalla=botonPantalla
    return botonActualPantalla

botonPantallaCompleta = pygame.image.load('botonPantallaCompleta.png')
botonPantallaCompleta = pygame.transform.scale(botonPantallaCompleta, (140, 140))
botonActualPantallaCompleta = botonPantallaCompleta
botonRectPantallaCompleta = botonActualPantallaCompleta.get_rect()
botonRectPantallaCompleta.center=(670,340)

def BotonPantallaCompleta(botonPantallaCompleta):
    global punteroRect, botonRectPantallaCompleta, botonActualPantallaCompleta
    if punteroRect.colliderect(botonRectPantallaCompleta):
        botonActualPantallaCompleta=botonPantallaCompleta
    else:
        botonActualPantallaCompleta=botonPantallaCompleta
    return botonActualPantallaCompleta

botonPantallaVentana = pygame.image.load('botonPantallaVentana.png')
botonPantallaVentana = pygame.transform.scale(botonPantallaVentana, (140, 140))
botonActualPantallaVentana = botonPantallaVentana
botonRectPantallaVentana = botonActualPantallaVentana.get_rect()
botonRectPantallaVentana.center=(470,340)

def BotonPantallaVentana(botonPantallaVentana):
    global punteroRect, botonRectPantallaVentana, botonActualPantallaVentana
    if punteroRect.colliderect(botonRectPantallaVentana):
        botonActualPantallaVentana=botonPantallaVentana
    else:
        botonActualPantallaVentana=botonPantallaVentana
    return botonActualPantallaVentana

botonAudio = pygame.image.load('botonAudio.png')
botonAudio = pygame.transform.scale(botonAudio, (140, 140))
botonActualAudio = botonAudio
botonRectAudio = botonActualAudio.get_rect()
botonRectAudio.center=(570,360)

def BotonAudio(botonAudio):
    global punteroRect, botonRectAudio, botonActualAudio
    if punteroRect.colliderect(botonRectAudio):
        botonActualAudio=botonAudio
    else:
        botonActualAudio=botonAudio
    return botonActualAudio

botonActivarAudio = pygame.image.load('botonActivarAudio.png')
botonActivarAudio = pygame.transform.scale(botonActivarAudio, (140, 140))
botonActualActivarAudio = botonActivarAudio
botonRectActivarAudio = botonActualActivarAudio.get_rect()
botonRectActivarAudio.center=(670,340)

def BotonActivarAudio(botonActivarAudio):
    global punteroRect, botonRectActivarAudio, botonActualActivarAudio
    if punteroRect.colliderect(botonRectActivarAudio):
        botonActualActivarAudio=botonActivarAudio
    else:
        botonActualActivarAudio=botonActivarAudio
    return botonActualActivarAudio

botonSilenciarAudio = pygame.image.load('botonSilenciarAudio.png')
botonSilenciarAudio = pygame.transform.scale(botonSilenciarAudio, (140, 140))
botonActualSilenciarAudio = botonSilenciarAudio
botonRectSilenciarAudio = botonActualSilenciarAudio.get_rect()
botonRectSilenciarAudio.center=(470,340)

def BotonSilenciarAudio(botonSilenciarAudio):
    global punteroRect, botonRectSilenciarAudio, botonActualSilenciarAudio
    if punteroRect.colliderect(botonRectSilenciarAudio):
        botonActualSilenciarAudio=botonSilenciarAudio
    else:
        botonActualSilenciarAudio=botonSilenciarAudio
    return botonActualSilenciarAudio

botonCreditos = pygame.image.load('botonCreditos.png')
botonCreditos = pygame.transform.scale(botonCreditos, (140, 140))
botonActualCreditos = botonCreditos
botonRectCreditos = botonActualCreditos.get_rect()
botonRectCreditos.center=(570,480)

def BotonCreditos(botonCreditos):
    global punteroRect, botonRectCreditos, botonActualCreditos
    if punteroRect.colliderect(botonRectCreditos):
        botonActualCreditos=botonCreditos
    else:
        botonActualCreditos=botonCreditos
    return botonActualCreditos

botonSaltear = pygame.image.load('botonSaltear.png')
botonSaltear = pygame.transform.scale(botonSaltear, (140, 140))
botonActualSaltear = botonSaltear
botonRectSaltear = botonActualSaltear.get_rect()
botonRectSaltear.center=(1050,580)

def BotonSaltear(botonSaltear):
    global punteroRect, botonRectSaltear, botonActualSaltear
    if punteroRect.colliderect(botonRectSaltear):
        botonActualSaltear=botonSaltear
    else:
        botonActualSaltear=botonSaltear
    return botonActualSaltear

######################################### BOTONES PARA TIPOS DE VIRUS #############################

botonVirusDeBoot = pygame.image.load('botonVirusDeBoot.png')
botonVirusDeBoot = pygame.transform.scale(botonVirusDeBoot, (140, 140))
botonActualVirusDeBoot = botonVirusDeBoot
botonRectVirusDeBoot = botonActualVirusDeBoot.get_rect()
botonRectVirusDeBoot.center=(330,180)

def BotonVirusDeBoot(botonVirusDeBoot):
    global punteroRect, botonRectVirusDeBoot, botonActualVirusDeBoot
    if punteroRect.colliderect(botonRectVirusDeBoot):
        botonActualVirusDeBoot=botonVirusDeBoot
    else:
        botonActualVirusDeBoot=botonVirusDeBoot
    return botonActualVirusDeBoot

botonTimeBomb = pygame.image.load('botonTimeBomb.png')
botonTimeBomb = pygame.transform.scale(botonTimeBomb, (140, 140))
botonActualTimeBomb = botonTimeBomb
botonRectTimeBomb = botonActualTimeBomb.get_rect()
botonRectTimeBomb.center=(570,180)

def BotonTimeBomb(botonTimeBomb):
    global punteroRect, botonRectTimeBomb, botonActualTimeBomb
    if punteroRect.colliderect(botonRectTimeBomb):
        botonActualTimeBomb=botonTimeBomb
    else:
        botonActualTimeBomb=botonTimeBomb
    return botonActualTimeBomb

botonGusanos = pygame.image.load('botonGusanos.png')
botonGusanos = pygame.transform.scale(botonGusanos, (140, 140))
botonActualGusanos = botonGusanos
botonRectGusanos = botonActualGusanos.get_rect()
botonRectGusanos.center=(810,180)

def BotonGusanos(botonGusanos):
    global punteroRect, botonRectGusanos, botonActualGusanos
    if punteroRect.colliderect(botonRectGusanos):
        botonActualGusanos=botonGusanos
    else:
        botonActualGusanos=botonGusanos
    return botonActualGusanos

botonTroyanos = pygame.image.load('botonTroyanos.png')
botonTroyanos = pygame.transform.scale(botonTroyanos, (140, 140))
botonActualTroyanos = botonTroyanos
botonRectTroyanos = botonActualTroyanos.get_rect()
botonRectTroyanos.center=(330,340)

def BotonTroyanos(botonTroyanos):
    global punteroRect, botonRectTroyanos, botonActualTroyanos
    if punteroRect.colliderect(botonRectTroyanos):
        botonActualTroyanos=botonTroyanos
    else:
        botonActualTroyanos=botonTroyanos
    return botonActualTroyanos

botonHijackers = pygame.image.load('botonHijackers.png')
botonHijackers = pygame.transform.scale(botonHijackers, (140, 140))
botonActualHijackers = botonHijackers
botonRectHijackers = botonActualHijackers.get_rect()
botonRectHijackers.center=(570,340)

def BotonHijackers(botonHijackers):
    global punteroRect, botonRectHijackers, botonActualHijackers
    if punteroRect.colliderect(botonRectHijackers):
        botonActualHijackers=botonHijackers
    else:
        botonActualHijackers=botonHijackers
    return botonActualHijackers

botonKeylogger = pygame.image.load('botonKeylogger.png')
botonKeylogger = pygame.transform.scale(botonKeylogger, (140, 140))
botonActualKeylogger = botonKeylogger
botonRectKeylogger = botonActualKeylogger.get_rect()
botonRectKeylogger.center=(810,340)

def BotonKeylogger(botonKeylogger):
    global punteroRect, botonRectKeylogger, botonActualKeylogger
    if punteroRect.colliderect(botonRectKeylogger):
        botonActualKeylogger=botonKeylogger
    else:
        botonActualKeylogger=botonKeylogger
    return botonActualKeylogger

botonZombie = pygame.image.load('botonZombie.png')
botonZombie = pygame.transform.scale(botonZombie, (140, 140))
botonActualZombie = botonZombie
botonRectZombie = botonActualZombie.get_rect()
botonRectZombie.center=(330,500)

def BotonZombie(botonZombie):
    global punteroRect, botonRectZombie, botonActualZombie
    if punteroRect.colliderect(botonRectZombie):
        botonActualZombie=botonZombie
    else:
        botonActualZombie=botonZombie
    return botonActualZombie

botonBackdoors = pygame.image.load('botonBackdoors.png')
botonBackdoors = pygame.transform.scale(botonBackdoors, (140, 140))
botonActualBackdoors = botonBackdoors
botonRectBackdoors = botonActualBackdoors.get_rect()
botonRectBackdoors.center=(570,500)

def BotonBackdoors(botonBackdoors):
    global punteroRect, botonRectBackdoors, botonActualBackdoors
    if punteroRect.colliderect(botonRectBackdoors):
        botonActualBackdoors=botonBackdoors
    else:
        botonActualBackdoors=botonBackdoors
    return botonActualBackdoors

botonVirusDeMacro = pygame.image.load('botonVirusDeMacro.png')
botonVirusDeMacro = pygame.transform.scale(botonVirusDeMacro, (140, 140))
botonActualVirusDeMacro = botonVirusDeMacro
botonRectVirusDeMacro = botonActualVirusDeMacro.get_rect()
botonRectVirusDeMacro.center=(810,500)

def BotonVirusDeMacro(botonVirusDeMacro):
    global punteroRect, botonRectVirusDeMacro, botonActualVirusDeMacro
    if punteroRect.colliderect(botonRectVirusDeMacro):
        botonActualVirusDeMacro=botonVirusDeMacro
    else:
        botonActualVirusDeMacro=botonVirusDeMacro
    return botonActualVirusDeMacro

################################################## PANTALLAS

def pantallaTeclas(punteroRect, pantalla):
     #Cargamos la imagen.
    Opcion=True  #############################################MWMWMWMWMWMWMWM
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoMenu.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648)) # 384, 384
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        textoAIAD = pygame.image.load("AIAD.png")
        textoAIAD = pygame.transform.scale(textoAIAD,(230,230))
        pantalla.blit(textoAIAD,(751,224))
            
        textoWASD = pygame.image.load("WASD.png")
        textoWASD = pygame.transform.scale(textoWASD,(230,230))
        pantalla.blit(textoWASD,(110,224))

        textoAIAD1 = pygame.image.load("AIAD.png")
        textoAIAD1 = pygame.transform.scale(textoAIAD1,(230,230))
        pantalla.blit(textoAIAD1,(418,418))

        textoUnSoloJugador = pygame.image.load("unSoloJugador.png")
        textoUnSoloJugador = pygame.transform.scale(textoUnSoloJugador,(250,250))
        pantalla.blit(textoUnSoloJugador,(418,318))

        textoDosJugadores = pygame.image.load("dosJugadores.png")
        textoDosJugadores = pygame.transform.scale(textoDosJugadores,(250,250))
        pantalla.blit(textoDosJugadores,(418,21))

        textoUnJugador = pygame.image.load("primerJugador.png")
        textoUnJugador =  pygame.transform.scale(textoUnJugador,(250,250))
        pantalla.blit(textoUnJugador,(123,102))
            
        textoSegundoJugador = pygame.image.load("segundoJugador.png")
        textoSegundoJugador = pygame.transform.scale(textoSegundoJugador,(250,250))
        pantalla.blit(textoSegundoJugador,(741,102))

        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:

                if punteroRect.colliderect(botonRectVolver):
                    Opcion=False ###################################  cambie llamado a funcion por opcion false MWMWMWMWMWWM
                    
                    
        punteroRect.center=pygame.mouse.get_pos()
    

def pantallaLogros(punteroRect, Logroganar, cantidadDePasos, cantidadDePasosAnterior, Contrarreloj, pantalla, nivel):
    Opcion = True
    #Cargamos la imagen.
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoMenu.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        if Logroganar == False and not nivel==1 or nivel==3:
            barraLogroGanar=pygame.image.load("barraLogroGanar.png")
            barraLogroGanar=pygame.transform.scale(barraLogroGanar,(774,113))
            pantalla.blit(barraLogroGanar,(176,200))
        else:
            barraLogroGanarCompleto=pygame.image.load("barraLogroGanarCompleto.png")
            barraLogroGanarCompleto=pygame.transform.scale(barraLogroGanarCompleto,(774,113))
            pantalla.blit(barraLogroGanarCompleto,(176,200))

        if cantidadDePasosAnterior == 38 and not nivel==1 or nivel==3:
            barraLogroPasosCompleto=pygame.image.load("barraLogroPasosCompleto.png")
            barraLogroPasosCompleto=pygame.transform.scale(barraLogroPasosCompleto,(774,113))
            pantalla.blit(barraLogroPasosCompleto,(176,315))
        else:
            barraLogroPasos=pygame.image.load("barraLogroPasos.png")
            barraLogroPasos=pygame.transform.scale(barraLogroPasos,(774,113))
            pantalla.blit(barraLogroPasos,(176,315))

        if Contrarreloj == 7 and not nivel==1 or nivel==3:
            barraLogroContrarrelojCompleto=pygame.image.load("barraLogroContrarrelojCompleto.png")
            barraLogroContrarrelojCompleto=pygame.transform.scale(barraLogroContrarrelojCompleto,(774,113))
            pantalla.blit(barraLogroContrarrelojCompleto,(176,430))
        else:
            barraLogroContrarreloj=pygame.image.load("barraLogroContrarreloj.png")
            barraLogroContrarreloj=pygame.transform.scale(barraLogroContrarreloj,(774,113))
            pantalla.blit(barraLogroContrarreloj,(176,430))
                                         
        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectVolver):
                    Opcion = False
                    
                    
        punteroRect.center=pygame.mouse.get_pos()

def pantallaPantalla(pantalla, punteroRect):
    Opcion = True
    #Cargamos la imagen.
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoMenu.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualPantallaCompleta,(botonRectPantallaCompleta.left, botonRectPantallaCompleta.top))
        BotonPantallaCompleta(botonPantallaCompleta)

        pantalla.blit(botonActualPantallaVentana,(botonRectPantallaVentana.left, botonRectPantallaVentana.top))
        BotonPantallaVentana(botonPantallaVentana)

        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectPantallaCompleta):
                    pygame.display.set_mode((1152,648), pygame.FULLSCREEN)
 #                  pantallaPantalla()                    ##############################
                elif punteroRect.colliderect(botonRectPantallaVentana):
                    pygame.display.set_mode((1152,648))
 #                  pantallaPantalla()                   #############################
                elif punteroRect.colliderect(botonRectVolver):
                    Opcion = False                     ##########################
                    
        punteroRect.center=pygame.mouse.get_pos()

#################Comienzan las pantallas de virus ###################

def pantallaVirusDeMacro(punteroRect, pantalla):
    Opcion = True
    #Cargamos la imagen.
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoGuiaTipVirusDeMacro.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectVolver):
                    Opcion = False
                    
        punteroRect.center=pygame.mouse.get_pos()

def pantallaBackdoors(punteroRect, pantalla):
    Opcion = True
    #Cargamos la imagen.
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoGuiaTipBackdoors.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectVolver):
                    Opcion = False
                    
        punteroRect.center=pygame.mouse.get_pos()

def pantallaZombie(punteroRect, pantalla):
    Opcion = True
        #Cargamos la imagen.
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoGuiaTipZombie.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectVolver):
                    Opcion=False
                    
                    
        punteroRect.center=pygame.mouse.get_pos()

def pantallaKeylogger(punteroRect, pantalla):
    Opcion = True
    #Cargamos la imagen.
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoGuiaTipKeylogger.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectVolver):
                    Opcion=False
                    
                    
        punteroRect.center=pygame.mouse.get_pos()

def pantallaHijackers(punteroRect, pantalla):
    Opcion = True
    #Cargamos la imagen.
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoGuiaTipHijackers.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectVolver):
                    Opcion=False
                    
                    
        punteroRect.center=pygame.mouse.get_pos()

   
def pantallaTroyanos(punteroRect, pantalla):
    Opcion = True
    #Cargamos la imagen.
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoGuiaTipTroyanos.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))
        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectVolver):
                    Opcion=False
                    
                    
        punteroRect.center=pygame.mouse.get_pos()

def pantallaGusanos(punteroRect, pantalla):
    Opcion = True
    #Cargamos la imagen.
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoGuiaTipGusanos.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectVolver):
                    Opcion=False
                    
                    
        punteroRect.center=pygame.mouse.get_pos()

def pantallaTimeBomb(punteroRect, pantalla):
    Opcion = True
    #Cargamos la imagen.
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoGuiaTipTimeBomb.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectVolver):
                    Opcion=False
                    
                    
        punteroRect.center=pygame.mouse.get_pos()
            
def pantallaVirusDeBoot(punteroRect, pantalla):
    Opcion=True
    #Cargamos la imagen.
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoGuiaTipVirusDeBoot.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectVolver):
                    Opcion=False
                    
        punteroRect.center=pygame.mouse.get_pos()

###### Terminan las pantallas de virus #####

def pantallaTiposDeVirus(punteroRect, pantalla):
    Opcion=True
    #Cargamos la imagen.
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoMenu.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        boot = pygame.image.load("virusdeboot.png")
        boot = pygame.transform.scale(boot, (90, 90))
        pantalla.blit(boot, (botonRectVirusDeBoot.left+30,botonRectVirusDeBoot.top-50))
        pantalla.blit(botonActualVirusDeBoot,(botonRectVirusDeBoot.left, botonRectVirusDeBoot.top))#F
        BotonVirusDeBoot(botonVirusDeBoot)
        
        timebomb = pygame.image.load("timebomb.png")
        timebomb = pygame.transform.scale(timebomb, (90, 90))
        pantalla.blit(timebomb, (botonRectTimeBomb.left+30,botonRectTimeBomb.top-40))
        pantalla.blit(botonActualTimeBomb,(botonRectTimeBomb.left, botonRectTimeBomb.top))
        BotonTimeBomb(botonTimeBomb)
        
        lombriz = pygame.image.load("lombriz.png")
        lombriz = pygame.transform.scale(lombriz, (90, 90))
        pantalla.blit(lombriz, (botonRectGusanos.left+30, botonRectGusanos.top-35))
        pantalla.blit(botonActualGusanos,(botonRectGusanos.left, botonRectGusanos.top))#F
        BotonGusanos(botonGusanos)

        troyano = pygame.image.load("troyano.png") ######################################
        troyano =pygame.transform.scale(troyano, (90, 90))  ######################################
        pantalla.blit(troyano, (botonRectTroyanos.left+35,botonRectTroyanos.top-50))  ######################################
        pantalla.blit(botonActualTroyanos,(botonRectTroyanos.left, botonRectTroyanos.top))
        BotonTroyanos(botonTroyanos)

        hijackers = pygame.image.load("hijackers.png")
        hijackers = pygame.transform.scale(hijackers, (90, 90))
        pantalla.blit(hijackers, (botonRectHijackers.left+30,botonRectHijackers.top-40))
        pantalla.blit(botonActualHijackers,(botonRectHijackers.left, botonRectHijackers.top))
        BotonHijackers(botonHijackers)

        Keylogger = pygame.image.load("keylogger.png")
        Keylogger = pygame.transform.scale(Keylogger, (90, 90))
        pantalla.blit(Keylogger, (botonRectKeylogger.left+30,botonRectKeylogger.top-50))
        pantalla.blit(botonActualKeylogger,(botonRectKeylogger.left, botonRectKeylogger.top))#F
        BotonKeylogger(botonKeylogger)
        
        zombie = pygame.image.load("zombie.png")
        zombie = pygame.transform.scale(zombie, (90, 90))
        pantalla.blit(zombie, (botonRectZombie.left+30,botonRectZombie.top-35))
        pantalla.blit(botonActualZombie,(botonRectZombie.left, botonRectZombie.top))
        BotonZombie(botonZombie)
                    
        backdoors = pygame.image.load("backdoors.png")
        backdoors = pygame.transform.scale(backdoors, (90, 90))
        pantalla.blit(backdoors, (botonRectBackdoors.left+30,botonRectBackdoors.top-50))
        pantalla.blit(botonActualBackdoors,(botonRectBackdoors.left, botonRectBackdoors.top))
        BotonBackdoors(botonBackdoors)
        
        macro = pygame.image.load("macro.jpg")
        macro = pygame.transform.scale(macro, (80, 80))
        pantalla.blit(macro, (botonRectVirusDeMacro.left+30,botonRectVirusDeMacro.top-50))
        pantalla.blit(botonActualVirusDeMacro,(botonRectVirusDeMacro.left, botonRectVirusDeMacro.top))
        BotonVirusDeMacro(botonVirusDeMacro)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN: 
                if punteroRect.colliderect(botonRectVirusDeBoot):
                    pantallaVirusDeBoot(punteroRect, pantalla)
                elif punteroRect.colliderect(botonRectTimeBomb):
                    pantallaTimeBomb(punteroRect, pantalla)
                elif punteroRect.colliderect(botonRectGusanos):
                    pantallaGusanos(punteroRect, pantalla)
                elif punteroRect.colliderect(botonRectTroyanos):
                    pantallaTroyanos(punteroRect, pantalla)
                elif punteroRect.colliderect(botonRectHijackers):
                    pantallaHijackers(punteroRect, pantalla)
                elif punteroRect.colliderect(botonRectKeylogger):
                    pantallaKeylogger(punteroRect, pantalla)
                elif punteroRect.colliderect(botonRectZombie):
                    pantallaZombie(punteroRect, pantalla)
                elif punteroRect.colliderect(botonRectBackdoors):
                    pantallaBackdoors(punteroRect, pantalla)
                elif punteroRect.colliderect(botonRectVirusDeMacro):
                    pantallaVirusDeMacro(punteroRect, pantalla)
                elif punteroRect.colliderect(botonRectVolver):
                    Opcion=False
                    
        punteroRect.center=pygame.mouse.get_pos()


def pantallaGuiaSegundo(punteroRect, pantalla):
    Opcion=True
    #Cargamos la imagen.
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoGuiaTip2.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        pantalla.blit(botonActualSaltear,(botonRectSaltear.left, botonRectSaltear.top))
        BotonSaltear(botonSaltear)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectSaltear):
                    pantallaTiposDeVirus(punteroRect, pantalla)
                elif punteroRect.colliderect(botonRectVolver):
                    ################### ERROR QUE, AL PRESIONAR EL BOTON VOLVER, TE LLEVA A LA PANTALLA TIPO DE VIRUS################
                    Opcion=False

    
def pantallaGuia(punteroRect, pantalla):
    Opcion=True
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoGuiaTip1.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        pantalla.blit(botonActualSaltear,(botonRectSaltear.left, botonRectSaltear.top))
        BotonSaltear(botonSaltear)
        
            #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectVolver):
                    Opcion=False
                elif punteroRect.colliderect(botonRectSaltear):
                    pantallaGuiaSegundo(punteroRect, pantalla)
                    
        punteroRect.center=pygame.mouse.get_pos()

def pantallaCreditos(punteroRect, pantalla):
    Opcion = True
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoCreditos.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))
        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectVolver):
                    Opcion = False
                    
        punteroRect.center=pygame.mouse.get_pos()

def pantallaAudio(punteroRect, pantalla):
    Opcion = True
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoMenu.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualActivarAudio,(botonRectActivarAudio.left, botonRectActivarAudio.top))
        BotonActivarAudio(botonActivarAudio)

        pantalla.blit(botonActualSilenciarAudio,(botonRectSilenciarAudio.left, botonRectSilenciarAudio.top))
        BotonSilenciarAudio(botonSilenciarAudio)

        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectActivarAudio):
                        pygame.mixer.music.play()
                elif punteroRect.colliderect(botonRectSilenciarAudio):
                        pygame.mixer.music.pause()
                if punteroRect.colliderect(botonRectVolver):
                    Opcion = False
                    
        punteroRect.center=pygame.mouse.get_pos()

def pantallaMenuOpciones(punteroRect, pantalla):
    Opcion = True
        #Cargamos la imagen.
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoMenu.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualAudio,(botonRectAudio.left, botonRectAudio.top))
        BotonAudio(botonAudio)
        pantalla.blit(botonActualPantalla,(botonRectPantalla.left, botonRectPantalla.top))
        BotonPantalla(botonPantalla)
        pantalla.blit(botonActualTeclas,(botonRectTeclas.left, botonRectTeclas.top))
        BotonTeclas(botonTeclas)
        pantalla.blit(botonActualCreditos,(botonRectCreditos.left, botonRectCreditos.top))
        BotonCreditos(botonCreditos)
        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectAudio):
                    pantallaAudio(punteroRect, pantalla)
                elif punteroRect.colliderect(botonRectCreditos):
                    pantallaCreditos(punteroRect, pantalla) 
                elif punteroRect.colliderect(botonRectTeclas):
                    pantallaTeclas(punteroRect, pantalla)
                elif punteroRect.colliderect(botonRectPantalla):
                    pantallaPantalla(pantalla, punteroRect)
                if punteroRect.colliderect(botonRectVolver):
                    Opcion = False
                    
                    
        punteroRect.center=pygame.mouse.get_pos()

def pantallaProximamente(pantalla):
    Opcion=True
    while Opcion == True:
        fondoProximo = pygame.image.load("fondoProximamente.png")
        fondoProximo=pygame.transform.scale(fondoProximo,(1152,648))
        pantalla.blit(fondoProximo,(0,0))
        
        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)

        pygame.display.update()
        pygame.time.delay(2000)
        pygame.quit()
        quit()
        #for event in pygame.event.get():
           # if event.type == pygame.MOUSEBUTTONDOWN:
          #      if punteroRect.colliderect(botonRectVolver):
         #           Opcion=False

        
    
            
def pantallaDificultad(pantalla,multijugador, punteroRect, modoJuego, nivel):
    global listafinal #
    #Cargamos la imagen.
    Opcion=True
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoMenu.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualFacil,(botonRectFacil.left, botonRectFacil.top))
        BotonFacil(botonFacil)
        pantalla.blit(botonActualDificil,(botonRectDificil.left, botonRectDificil.top))
        BotonDificil(botonDificil)
        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
        #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectFacil):
                    modoJuego='Facil'
                    multijugador=False
                    if nivel==1:
                        listafinal=archileer("facilrankingN1.txt", nivel) #
                    elif nivel==2:
                        listafinal=archileer("facilrankingN2.txt", nivel) #
                    elif nivel==3:
                        listafinal=archileer("facilrankingN3.txt", nivel) #
                    Opcion=False

                elif punteroRect.colliderect(botonRectDificil):
                    if nivel==1:
                        modoJuego='Dificil'
                        multijugador=False
                        listafinal=archileer("dificilrankingN1.txt", nivel) #
                        Opcion=False
                    elif nivel==2:
                        modoJuego='Dificil'
                        multijugador=False
                        listafinal=archileer("dificilrankingN2.txt", nivel)
                        Opcion=False
                    elif nivel==3:
                        pantallaProximamente(pantalla)
                        Opcion=False
                if punteroRect.colliderect(botonRectVolver):
                    Opcion=False
                    
                    
        punteroRect.center=pygame.mouse.get_pos()
    return modoJuego

def pantallaNiveles(pantalla,punteroRect, multijugador, modoJuego):
    global botonActualLVL1, botonRectLVL1, botonActualLVL2, botonRectLVL2, botonActualLVL3, botonRectLVL3, botonActualLVL1Expli, botonRectLVL1Expli, botonActualLVL2Expli, botonRectLVL2Expli, botonActualLVL3Expli, botonRectLVL3Expli
    Opcion=True
    #Cargamos la imagen.
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoMenu.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualLVL1,(botonRectLVL1.left, botonRectLVL1.top))
        BotonLVL1(botonLVL1)
        
        pantalla.blit(botonActualLVL2,(botonRectLVL2.left, botonRectLVL2.top))
        BotonLVL2(botonLVL2)

        pantalla.blit(botonActualLVL3,(botonRectLVL3.left, botonRectLVL3.top))
        BotonLVL3(botonLVL3)

        

        pantalla.blit(botonActualLVL1Expli,(botonRectLVL1Expli.left, botonRectLVL1Expli.top))
        BotonLVL1Expli(botonLVL1Expli, botonLVL1ExpliImg)
        
        pantalla.blit(botonActualLVL2Expli,(botonRectLVL2Expli.left, botonRectLVL2Expli.top))
        BotonLVL2Expli(botonLVL2Expli, botonLVL2ExpliImg)

        pantalla.blit(botonActualLVL3Expli,(botonRectLVL3Expli.left, botonRectLVL3Expli.top))
        BotonLVL3Expli(botonLVL3Expli, botonLVL3ExpliImg)
        
        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
              #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectLVL1):
                    nivel=1
                    Opcion=False
                    modoJuego=pantallaDificultad(pantalla,multijugador, punteroRect, modoJuego, nivel)
                elif punteroRect.colliderect(botonRectLVL2):
                    nivel=2
                    Opcion=False
                    modoJuego=pantallaDificultad(pantalla,multijugador, punteroRect, modoJuego, nivel)
                elif punteroRect.colliderect(botonRectLVL3):
                    nivel=3
                    Opcion=False
                    modoJuego=pantallaDificultad(pantalla,multijugador, punteroRect, modoJuego, nivel)
                elif punteroRect.colliderect(botonRectVolver):
                    nivel=2
                    Opcion=False
                    
                    
        punteroRect.center=pygame.mouse.get_pos()
        botonActualLVL1Expli=BotonLVL1Expli(botonLVL1Expli,botonLVL1ExpliImg)
        botonActualLVL2Expli=BotonLVL2Expli(botonLVL2Expli,botonLVL2ExpliImg)
        botonActualLVL3Expli=BotonLVL3Expli(botonLVL3Expli,botonLVL3ExpliImg)
    return nivel, modoJuego
            
def pantallaJugador(multijugador,pantalla,punteroRect, modoJuego):
    Opcion=True
    nivel=2
    #Cargamos la imagen.
    while Opcion == True:
        fondoopcion = pygame.image.load("fondoMenu.png")
        #Colocamos la escala.
        fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
        #Ponemos que aparezca en pantalla.
        pantalla.blit(fondoopcion,(0,0))

        pantalla.blit(botonActualUnJugador,(botonRectUnJugador.left, botonRectUnJugador.top))
        BotonUnJugador(botonUnJugador)
        pantalla.blit(botonActualMultijugador,(botonRectMultijugador.left, botonRectMultijugador.top))
        BotonMultijugador(botonMultijugador)
        pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
        BotonVolver(botonVolver)
        
              #Y colocamos su posición.
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectUnJugador):
                    multijugador=False
                    estado=(pantallaNiveles(pantalla,punteroRect, multijugador, modoJuego))
                    nivel=estado[0]
                    modoJuego=estado[1]
                    Opcion=False
                elif punteroRect.colliderect(botonRectMultijugador):
                    multijugador=True
                    Opcion=False
                elif punteroRect.colliderect(botonRectVolver):
                    Opcion=False
                    
                    
        punteroRect.center=pygame.mouse.get_pos()
    return multijugador, modoJuego, nivel
            
#Actualizamos el contador de pasos de Super Tablet y el contador de energía
def actualizarContadorDePasos(cantidadDePasos, multijugador, pantalla, nivel):
    global colorBlanco
    if multijugador==False and not nivel==3:
        ancho=350
        alto=40
        x=651
        y=504
        pygame.draw.rect(pantalla,colorLila,(x,y,ancho,alto))
        textoPasos = tipografiaGrande.render('Cantidad de movimientos: ' + str(cantidadDePasos), False, colorBlanco)
        pantalla.blit(textoPasos,(x+5,y,ancho,alto))
        cantidadDePasos=cantidadDePasos+1
        pygame.display.update()
    return cantidadDePasos

def hayAreaProtegidaEn(x,y, lstAreaProtegida):
    punto=(x,y)
    return lstAreaProtegida.__contains__(punto)

#Creamos una función para el multijugador.
def hayAreaProtegidaEnSegundo(x,y, lstAreaProtegidaSegundo):
    punto=(x,y)
    return lstAreaProtegidaSegundo.__contains__(punto)

def posicionarElemento(elemento,x,y, zonaDeTransporte): 
    zonaDeTransporte[x][y]=elemento

def borrarElemento(x,y, zonaDeTransporte):
    zonaDeTransporte[x][y]=0

#cramos una función para que se borre la letra escrita con la tecla BACKSPACE
def borrartecla(x,y, indice, pantalla):  
    global colorNegro
    if x >=320:
        indice = indice-1
        x=x-37
        pygame.draw.rect(pantalla,colorNegro,(x,y,37,85))
        pygame.display.update()
    return x, indice

def crearZonaDeTransporte(multijugador, cantidadDeCasillasPorLado,lstAreaProtegida,lstAreaProtegidaSegundo,nivel):
    if multijugador==True:
        #Creamos una variable que contenga la cantidad de casillas en el multijugador.
        cantidad=10
    else:
        cantidad=0
        #Creamos un rectangulo que será la matriz.
    zonaDeTransporte = [[0 for x in range(cantidadDeCasillasPorLado+1)] for y in range(cantidadDeCasillasPorLado+cantidad+1)] 
    #
    if nivel==1:
        for i in range(1,cantidadDeCasillasPorLado+1):
            zonaDeTransporte[i][1] = 'pared'  
            zonaDeTransporte[i][cantidadDeCasillasPorLado] = 'pared'   
            zonaDeTransporte[1][i] = 'pared'  
            zonaDeTransporte[cantidadDeCasillasPorLado][i] = 'pared'   

#Ubicamos el lugar en donde estarán la Súper Tablet y el virus
        zonaDeTransporte[2][4] = 'jugador'
        zonaDeTransporte[5][4] = 'virus'      

        lstAreaProtegida.append((7,2))
    elif nivel==2:
        zonaDeTransporte[1][3] = 'pared'
        zonaDeTransporte[2][3] = 'pared'
        zonaDeTransporte[3][3] = 'pared'
        zonaDeTransporte[4][3] = 'pared'
        zonaDeTransporte[5][3] = 'pared'
        zonaDeTransporte[6][3] = 'pared'
        zonaDeTransporte[7][3] = 'pared'
        zonaDeTransporte[8][3] = 'pared'

        zonaDeTransporte[1][7] = 'pared'
        zonaDeTransporte[2][7] = 'pared'
        zonaDeTransporte[3][7] = 'pared'
        zonaDeTransporte[4][7] = 'pared'
        zonaDeTransporte[5][7] = 'pared'
        zonaDeTransporte[6][7] = 'pared'
        zonaDeTransporte[7][7] = 'pared'
        zonaDeTransporte[8][7] = 'pared'

        zonaDeTransporte[1][4] = 'pared'
        zonaDeTransporte[1][5] = 'pared'
        zonaDeTransporte[1][6] = 'pared'
        zonaDeTransporte[8][4] = 'pared'
        zonaDeTransporte[8][5] = 'pared'
        zonaDeTransporte[8][6] = 'pared'

        zonaDeTransporte[2][5] = 'jugador'

        zonaDeTransporte[3][5] = 'virus'      
        zonaDeTransporte[4][5] = 'virus'    
        zonaDeTransporte[5][5] = 'virus'    
        zonaDeTransporte[6][5] = 'virus' 
        zonaDeTransporte[5][6] = 'virus'  

        lstAreaProtegida.append((2,4))
        lstAreaProtegida.append((2,6))
        lstAreaProtegida.append((7,4))
        lstAreaProtegida.append((7,6))
        lstAreaProtegida.append((4,6))

    elif nivel==3:    

        for i in range(1,cantidadDeCasillasPorLado+1):
            zonaDeTransporte[i][1] = 'pared'  
            zonaDeTransporte[i][cantidadDeCasillasPorLado] = 'pared'   
            zonaDeTransporte[1][i] = 'pared'  
            zonaDeTransporte[cantidadDeCasillasPorLado][i] = 'pared'
            
        #Ubicamos el lugar en donde estarán la Súper Tablet y el virus
 
        zonaDeTransporte[8][3] = 'virus'
        zonaDeTransporte[9][4] = 'virus'
        zonaDeTransporte[4][5] = 'virus'
        zonaDeTransporte[3][8] = 'virus'
        zonaDeTransporte[9][8] = 'virus'
        zonaDeTransporte[5][6] = 'jugador'
        zonaDeTransporte[8][9] = 'virus'

        zonaDeTransporte[2][2] = 'movil'
        zonaDeTransporte[2][3] = 'movil'
        zonaDeTransporte[2][5] = 'movil'
        zonaDeTransporte[2][6] = 'movil'
        zonaDeTransporte[2][7] = 'movil'
        zonaDeTransporte[2][8] = 'movil'
        zonaDeTransporte[2][9] = 'movil'

        zonaDeTransporte[3][3] = 'movil'
        zonaDeTransporte[3][4] = 'movil'
        zonaDeTransporte[3][5] = 'movil'
        zonaDeTransporte[3][6] = 'movil'
        zonaDeTransporte[3][7] = 'movil'
        zonaDeTransporte[3][9] = 'movil'

        zonaDeTransporte[4][2] = 'movil'
        zonaDeTransporte[4][3] = 'movil'
        zonaDeTransporte[4][4] = 'movil'
        zonaDeTransporte[4][6] = 'movil'
        zonaDeTransporte[4][8] = 'movil'
        zonaDeTransporte[4][9] = 'movil'

        zonaDeTransporte[5][3] = 'movil'
        zonaDeTransporte[5][4] = 'movil'
        zonaDeTransporte[5][5] = 'movil'
        zonaDeTransporte[5][7] = 'movil'
        zonaDeTransporte[5][8] = 'movil'
        zonaDeTransporte[5][9] = 'movil'

        zonaDeTransporte[6][2] = 'movil'
        zonaDeTransporte[6][3] = 'movil'
        zonaDeTransporte[6][4] = 'movil'
        zonaDeTransporte[6][5] = 'movil'
        zonaDeTransporte[6][6] = 'movil'
        zonaDeTransporte[6][8] = 'movil'
        zonaDeTransporte[6][9] = 'movil'

        zonaDeTransporte[7][2] = 'movil'
        zonaDeTransporte[7][3] = 'movil'
        zonaDeTransporte[7][4] = 'movil'
        zonaDeTransporte[7][5] = 'movil'
        zonaDeTransporte[7][7] = 'movil'
        zonaDeTransporte[7][8] = 'movil'
        zonaDeTransporte[7][9] = 'movil'

        zonaDeTransporte[8][2] = 'movil'
        zonaDeTransporte[8][4] = 'movil'
        zonaDeTransporte[8][5] = 'movil'
        zonaDeTransporte[8][6] = 'movil'
        zonaDeTransporte[8][7] = 'movil'
        zonaDeTransporte[8][8] = 'movil'

        zonaDeTransporte[9][2] = 'movil'
        zonaDeTransporte[9][3] = 'movil'
        zonaDeTransporte[9][5] = 'movil'
        zonaDeTransporte[9][6] = 'movil'
        zonaDeTransporte[9][7] = 'movil'
        zonaDeTransporte[9][9] = 'movil'

        zonaDeTransporte[2][4] = 'movil'
        zonaDeTransporte[5][2] = 'movil'
        zonaDeTransporte[3][2] = 'movil'
        zonaDeTransporte[7][6] = 'movil'
        zonaDeTransporte[6][7] = 'movil'
        zonaDeTransporte[4][7] = 'movil'

        lstAreaProtegida.append((2,4))
        lstAreaProtegida.append((5,2))
        lstAreaProtegida.append((3,2))
        lstAreaProtegida.append((7,6))
        lstAreaProtegida.append((6,7))
        lstAreaProtegida.append((4,7))
        
    if multijugador==True:
        
        zonaDeTransporte[10][3] = 'pared'
        zonaDeTransporte[11][3] = 'pared'
        zonaDeTransporte[12][3] = 'pared'
        zonaDeTransporte[13][3] = 'pared'
        zonaDeTransporte[14][3] = 'pared'
        zonaDeTransporte[15][3] = 'pared'
        zonaDeTransporte[16][3] = 'pared'
        zonaDeTransporte[17][3] = 'pared'

        zonaDeTransporte[10][7] = 'pared'
        zonaDeTransporte[11][7] = 'pared'
        zonaDeTransporte[12][7] = 'pared'
        zonaDeTransporte[13][7] = 'pared'
        zonaDeTransporte[14][7] = 'pared'
        zonaDeTransporte[15][7] = 'pared'
        zonaDeTransporte[16][7] = 'pared'
        zonaDeTransporte[17][7] = 'pared'

        zonaDeTransporte[10][4] = 'pared'
        zonaDeTransporte[10][5] = 'pared'
        zonaDeTransporte[10][6] = 'pared'
        zonaDeTransporte[17][4] = 'pared'
        zonaDeTransporte[17][5] = 'pared'
        zonaDeTransporte[17][6] = 'pared'

        zonaDeTransporte[11][5] = 'jugador2'

        zonaDeTransporte[12][5] = 'virus'      
        zonaDeTransporte[13][5] = 'virus'    
        zonaDeTransporte[14][5] = 'virus'    
        zonaDeTransporte[15][5] = 'virus' 
        zonaDeTransporte[14][6] = 'virus'

        lstAreaProtegidaSegundo.append((11,4))
        lstAreaProtegidaSegundo.append((11,6))
        lstAreaProtegidaSegundo.append((16,4))
        lstAreaProtegidaSegundo.append((16,6))
        lstAreaProtegidaSegundo.append((13,6))
        
    
    return zonaDeTransporte

def dibujarZonaDeTransporte(zonaDeTransporte, multijugador, cantPixelesPorLadoCasilla, nivel, pantalla, cantidadDeCasillasPorLado, lstAreaProtegida, lstAreaProtegidaSegundo, imgAreaProtegida, imgSuperTablet, imgSuperCelu, imgPared, imgPared2, imgAmenaza):
    global colorLila

    if nivel==1 or nivel==3:
        indice=1 
    else:
        indice=2

    if multijugador==True:
        cantidad=9
    else:
        cantidad=0
        
    cnt = 0
    
    for i in range(indice,cantidadDeCasillasPorLado+1): 
        for j in range(1,cantidadDeCasillasPorLado+cantidad+1): 
            if cnt % 2 == 0:
                pygame.draw.rect(pantalla, colorLila,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
            else:
                pygame.draw.rect(pantalla, colorLila, [cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
            if (zonaDeTransporte[j][i]=='movil'):  
                pantalla.blit(imgPared2, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))  
            if (hayAreaProtegidaEn(j,i, lstAreaProtegida)==True):
                pantalla.blit(imgAreaProtegida, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
            if (hayAreaProtegidaEnSegundo(j,i, lstAreaProtegidaSegundo)==True): 
                pantalla.blit(imgAreaProtegida, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))  
            if (zonaDeTransporte[j][i]=='jugador'):
                pantalla.blit(imgSuperTablet, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
            if (zonaDeTransporte[j][i]=='jugador2'): 
                pantalla.blit(imgSuperCelu, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
            if (zonaDeTransporte[j][i]=='pared'):          
                pantalla.blit(imgPared, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
            if (zonaDeTransporte[j][i]=='virus'):
                pantalla.blit(imgAmenaza, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
            if (zonaDeTransporte[j][i]=='bloqueado'):  
                pantalla.blit(imgAmenaza, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))               
            cnt +=1
        cnt-=1
    pygame.display.update()


