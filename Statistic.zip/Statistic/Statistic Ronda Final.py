#!/usr/bin/env python
#-*- coding: utf-8 -*-
#Inicio Ronda 2 - 2019
#La librería Pygame debe estar instalada junto a Python 2.7.13 para que el código se ejecute. 
#Si no lo está, ir en Windows a la aplicación Símbolo del Sistema y con una conexión activa a Internet ejecutar el comando pip install pygame 

import pygame
import random

#Inicializamos la librería Pygame y demás variables
pygame.init()
pygame.font.init()








#Seleccionamos el color blanco.
colorBlancojaja=(255,255,255)
#Usamos una imagen para que se represente durante la carga al inicio.
cargando = pygame.image.load("fondoDeEspera.jpg")
#La escalamos.
cargando = pygame.transform.scale(cargando,(1152,648))
#Creamos otra tipografía para que aparezca durante la carga.
#tipografiacargando=tipografiaGrande.render('Cargando...',False,colorBlancojaja)
#Configuramos el tamaño de la pantalla.
pantalla= pygame.display.set_mode((1152,648))
#Mostramos en la pantalla.
pantalla.blit(cargando,(0,0))
#Mostramos la tipografía.
#pantalla.blit(tipografiacargando,(1100,600))
#Y actualizamos.
pygame.display.update()








from Funcionesv2 import *
from pygame.locals import *







#Creamos la tipografía grande.
tipografiaGrande=pygame.font.SysFont('Arial', 24)
#Creamos "nombres", "nombres2" y "nombres3" y agregamos frases con respecto a la seguridad y chistes relacionados.
nombres="Virus's Hunter: Puedes derrotarlos"
nombres2="Virus's Hunter: Si al lado del enlace en la pagina hay un escudo eso significa que es segura."
nombres3="Virus's Hunter: Sabias que hay un virus suelto en la ciudad? Y no es una gripe."
nombres4="Virus's Hunter:"
#Luego, lo incluimos en una lista.
listaNombres=[nombres,nombres2,nombres3]
pygame.display.set_caption(listaNombres[random.randint(0, 2)])
#Cargamos la música.
pygame.mixer.music.load("musicaJuego.mp3")
#Ponemos todas las veces que queramos repetir (en este caso, (-1), que es, infinito).
pygame.mixer.music.play(-1)
#Definimos que la variable "ganar" será el sonido que se reproduzca cuando ganamos el juego.
ganar = pygame.mixer.Sound("ganaste1.wav")
desplazar = pygame.mixer.Sound("audio de la tablet.wav")
colorRan = colorLila
colorAnterior=colorNegro









#Configuramos las tipografías, el tamaño, las fuentes y demás.
tipografiaGanaste=pygame.font.SysFont('Arial', 26)
tipografia = pygame.font.SysFont('Arial', 18)
tipografiaNOM = pygame.font.SysFont("Calibri", 48, bold = True)
Logroganar=False
cantidadDePasosAnterior=0
Contrarreloj=0








global nivelCompletado
global cantidadDePasos
global cantidadDeEnergia

#Definimos los colores que utilizaremos.
colorBlanco,colorNegro,colorLila,colorAzul,colorCeleste,colorVioleta,colorRojo,colorGris=(255,255,255),(0,0,0),(80,50,75),(0,0,255),(0,0,127),(160,100,150),(190,0,0),(190,190,190)
#Ponemos que la variable se inicie en verdadero.
RegresarDeCero=True







#El while RegresarDeCero funciona para que una vez que el jugador finalice la partida independientemende del nivel vuelva a la pantalla principal.
while RegresarDeCero:
    #Ponemos que las variables "segundos", "cantidadDePasos", "nivel" y "cantidadDeEnergia" estén en su valor original.
    nivel=0
    segundos=0
    cantidadDePasos=0
    cantidadDeEnergia=7000
    Opcion=True
    estadoDeEnergiaAnterior=cantidadDeEnergia
    modoJuego='EnEspera'
    jugadorPosAnterior=()
    jugadorPosActual=()
    virusPosAnterior=()
    virusPosActual=()
    romper=()
    activarDeshacer=False
    salirescribir = False 
    mayus = False  
    x=300  
    y=300  
    lista=[" "," "," "," "," ","","","","","","","","","","",'','','','','',""]  
    indice=0  
    puntaje=0 
    tecla="a"
    segundosInmovil=0
    multijugador=False
    puntero = pygame.image.load('puntero.png')
    tiempo = pygame.image.load('tiempo.png')
    tiempo = pygame.transform.scale(tiempo,(130,150))







    

    #Esta función sirve para que apenas iniciemos el juego aparezca en pantalla el menú.
    def pantallaOpcion():
        global modoJuego,multijugador, botonActualJugar,botonRectJugar, Opcion, punteroRect, botonActualSalirMenu,botonActualOpciones,botonActualGuia,botonActualLogros,pum
        global Logroganar, cantidadDePasos, cantidadDePasosAnterior, Contrarreloj, nivel, botonActualRanking, botonRectRanking
        #Creamos un while Opcion que tenga como valor verdadero para que esté esperando a que cambie el valor a falso una vez vaya a otra pantalla.
        while Opcion == True:
            fondoopcion = pygame.image.load("fondoMenuMA.png")
            fondoopcion=pygame.transform.scale(fondoopcion,(1152,648))
            pantalla.blit(fondoopcion,(0,0))

            #Ubicamos en pantalla los botones.
            pantalla.blit(botonActualJugar,(botonRectJugar.left, botonRectJugar.top))
            BotonJugar(botonJugar,botonJugar2)
            pantalla.blit(botonActualOpciones,(botonRectOpciones.left, botonRectOpciones.top))
            BotonOpciones(botonOpciones, botonOpciones2)
            pantalla.blit(botonActualGuia,(botonRectGuia.left, botonRectGuia.top))
            BotonGuia(botonGuia,botonGuia2)
            pantalla.blit(botonActualLogros,(botonRectLogros.left, botonRectLogros.top))
            BotonLogros(botonLogros,botonLogros2)
            pantalla.blit(botonActualSalirMenu,(botonRectSalirMenu.left, botonRectSalirMenu.top))
            BotonSalirMenu(botonSalirMenu, botonSalirMenu2)
            pantalla.blit(botonActualRanking,(botonRectRanking.left, botonRectRanking.top))
            BotonRanking(botonRanking, botonRankingPresionado)
            pygame.display.update()
            
            for event in pygame.event.get():
               if event.type == pygame.MOUSEBUTTONDOWN:
                    if punteroRect.colliderect(botonRectJugar):
                        estado=(pantallaJugador(multijugador,pantalla,punteroRect, modoJuego))    
                        multijugador = estado [0]                
                        modoJuego = estado [1]
                        nivel = estado [2]
                        if multijugador==True or modoJuego=='Facil' or modoJuego=='Dificil':
                            Opcion=False
                    elif punteroRect.colliderect(botonRectOpciones):
                        pantallaMenuOpciones(punteroRect, pantalla)
                    elif punteroRect.colliderect(botonRectGuia):
                        pantallaGuia(punteroRect, pantalla)
                    elif punteroRect.colliderect(botonRectLogros):
                        pantallaLogros(punteroRect, Logroganar, cantidadDePasos, cantidadDePasosAnterior, Contrarreloj, pantalla, nivel)
                    elif punteroRect.colliderect(botonRectRanking):
                        reset()
                    elif punteroRect.colliderect(botonRectSalirMenu):
                        pygame.quit()
                        quit()
                    
            #Y actualizamos los botones.
            punteroRect.center=pygame.mouse.get_pos()
            botonActualJugar=BotonJugar(botonJugar,botonJugar2)
            botonActualGuia=BotonGuia(botonGuia,botonGuia2)
            botonActualOpciones=BotonOpciones(botonOpciones,botonOpciones2)
            botonActualLogros=BotonLogros(botonLogros,botonLogros2)
            botonActualSalirMenu=BotonSalirMenu(botonSalirMenu,botonSalirMenu2)
            botonActualRanking=BotonRanking(botonRanking, botonRankingPresionado)

    pantallaOpcion()

    
    
    #Esto funciona para que cambie el tamaño de la matriz.
    if nivel==3:
        cantidadDeCasillasPorLado=10
    else:
        cantidadDeCasillasPorLado=8
    #Esto funciona para que el cuadrado se rompa y se extienda a un rectángulo para el modo multijugador.
    if multijugador==True or nivel==3:
        cantPixelesPorLadoCasilla=60
    else:
        cantPixelesPorLadoCasilla=72

    nivelCompletado=False
    ModoFacil=True  
    salirJuego = False
    lstAreaProtegida=[]
    lstAreaProtegidaSegundo=[]







    

    #Cargamos las imágenes y las definimos en variables para ser más fácil de llamarlas luego. Ambas servirán para armar la "animación".
    tablet=pygame.image.load("supertablet.png")
    tablet2=pygame.image.load("supertablet2.png")
    celu=pygame.image.load("supercelu.png")  
    celu2=pygame.image.load("supercelu2.png")







    

    #Cargamos las demás imágenes.
    imgPared=pygame.image.load("pared.png")
    imgPared2=pygame.image.load ("pared222.png")
    imgAreaProtegida=pygame.image.load("areaprotegida.png")







    

    #Cargamos las imágenes en variables.
    listaAmenazas = ["lombriz.png", "troyano.png", "timebomb.png", "zombie.png"]
    listaAmenazas2 = ["lombriz2.png", "troyano2.png", "timebomb2.png", "zombie2.png"]
    #Definimos que "ind" será el código de random (es decir, que elegirá entre las cuatro imágenes de las listas).
    ind = random.randint(0,3)
    #Definimos que "virus" y "virus2" sean las listas y que las escoja aleatoriamente.
    virus=pygame.image.load(listaAmenazas[ind])
    virus2=pygame.image.load(listaAmenazas2[ind])
    bandera = 1
    #Escalamos cada imagen en las casillas correspondientes.
    tablet=pygame.transform.scale(tablet, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    tablet2=pygame.transform.scale(tablet2, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    celu=pygame.transform.scale(celu, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    celu2=pygame.transform.scale(celu2, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    imgPared=pygame.transform.scale(imgPared, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    imgPared2=pygame.transform.scale(imgPared2, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    virus=pygame.transform.scale(virus, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    virus2=pygame.transform.scale(virus2, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    imgAreaProtegida=pygame.transform.scale(imgAreaProtegida, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    #Ponemos que "imgAmenaza" es igual a "virus" y "imgSuperTablet" es igual a "tablet" luego de escalarlas para no tener problemas con las imágenes.
    imgAmenaza=virus
    imgSuperTablet=tablet
    imgSuperCelu=celu
    
    #Creamos el mapa del nivel y algunas operaciones para los elementos que se encuentran dentro de la zona de transporte
    
    zonaDeTransporte=crearZonaDeTransporte(multijugador, cantidadDeCasillasPorLado,lstAreaProtegida,lstAreaProtegidaSegundo,nivel)







    #Creamos una función para crear el fondo.
    def dibujarFondo():
        #Cargamos la imagen.
        fondo = pygame.image.load("fondoDurante.jpg")
        #Escalamos la imagen de fondo.
        fondo=pygame.transform.scale(fondo,(1152,648))
        #Y la mostramos en pantalla.
        pantalla.blit(fondo, (0, 0))







    #Creamos las reglas.
    def dibujarReglas():
        #Llamamos las variables en la global.
        global colorBlanco, multijugador
        #Creamos el ancho y el alto.    
        ancho=800
        alto=46
        #Ponemos un valor a "x" y "y".
        x=350
        y=3
        pygame.display.update()




        

    def actualizarContadorDeElectricidad(decremento):
        global cantidadDeEnergia, estadoDeEnergiaAnterior,imgPerdiste, multijugador
        if multijugador==False and not nivel==3:

            ancho=550
            alto=40
            x=651
            y=432
            FondoBateria = pygame.image.load("troyano.png")
            troyano = pygame.image.load("troyano.png")

            estadoDeEnergiaAnterior=cantidadDeEnergia
    
            cantidadDeEnergia=cantidadDeEnergia-decremento

            #Si cantidad de energía es mayor a cero se actualiza y muestra en la pantalla.
            if cantidadDeEnergia > 0:
                pygame.draw.rect(pantalla,colorLila,(x,y,ancho,alto))
                textoEnergia = tipografiaGrande.render('Bateria disponible de Super Tablet: ' + str(cantidadDeEnergia) + 'mA', False, colorBlanco)
                pantalla.blit(textoEnergia,(x+5,y,ancho,alto))
                pygame.display.update()
            #Lo siguiente funcionará para que si Super Tablet se queda sin energía se reinicie.
            else:
                #Se escala la imagen de fondo.
                imgPerdiste=pygame.transform.scale(imgPerdiste,(1152,648))
                #Se muestra en la pantalla.
                pantalla.blit(imgPerdiste,(0,0))
                #Reproducimos el sonido.
                pygame.display.update()
                #Esperamos un segundo.
                pygame.time.delay(1500)
                Reiniciar()   






    def puntajeActual():
        global puntaje, cantidadDeEnergia, segundos, multijugador, tipografiaGrande, colorLila, colorBlanco, pantalla, nivel
        ancho=170
        alto=40
        x=651
        y=260
        if multijugador==False and not nivel==3 and segundos>0:
            puntaje = cantidadDeEnergia / segundos
            pygame.draw.rect(pantalla,colorLila,(x,y,ancho,alto))
            textoDePuntajeActual = tipografiaGrande.render(str(puntaje) + ' puntaje.', False, colorBlanco)
            pantalla.blit(textoDePuntajeActual,(x+5,y,ancho,alto))
        elif nivel==3:
            puntaje = segundos
            pygame.draw.rect(pantalla,colorLila,(x,y,ancho,alto))
            textoDePuntajeActual = tipografiaGrande.render(str(puntaje) + ' puntaje.', False, colorBlanco)
            pantalla.blit(textoDePuntajeActual,(x+5,y,ancho,alto))
        
        pygame.display.update()





    def contadorDeSegundosEstandoInmovil(b):
        global multijugador, segundosInmovil, nivel
        segundosInmovil=segundosInmovil+b
        if multijugador==False and segundosInmovil==16:
            Reiniciar()
            pygame.display.update()





            

    def contadorDeSegundos(n):
        global segundos, multijugador, Contrarreloj
        ancho=170
        alto=40
        x=651
        y=360
        if multijugador==False:
            puntajeActual()
            textoEnergia = tipografiaGrande.render(str(segundos) + ' s.', False, colorLila)
            pantalla.blit(tiempo,(x+280,y-40,ancho,alto))
            pantalla.blit(textoEnergia,(x+320,y-32,ancho,alto))
        else:
            y=60
            pygame.draw.rect(pantalla,colorLila,(x-100,y,ancho,alto))
            textoEnergia=tipografiaGrande.render(str(segundos) + ' segundos.', False, colorBlanco)
            pantalla.blit(textoEnergia,(x-90,y,ancho,alto))
        pygame.display.update()
        segundos=segundos+n
        Contrarreloj=segundos




        

    #Imprime en la pantalla las teclas alfabeticas presionadas
    def imprimirtecla(): 
        global x,y,mayus,lista,indice
        if x <740:
            indice = indice+1
            tecla= pygame.key.name(event.key)#se guarda el dato de tecla prisonada
            if tecla=="space": #para verificar si el dato es "space" por la barra espaciadora
                tecla=" "
            teclado = pygame.key.get_pressed()
            if teclado [K_RSHIFT] or teclado [K_LSHIFT]:
                tecla = tecla.upper()
        
            #Escribimos la letra presionada en la pantalla
            nombrejugador = tipografiaNOM.render(tecla, False, colorBlanco)
            pantalla.blit(nombrejugador,(x,y))
            lista[indice]= tecla
            pygame.display.update()
            #Te desplaza hacia la derecha para escribir la próxima letra
            x=x+37





    
    def dibujarCartelRondaFinal():
        global colorBlanco,colorNegro,colorLila,colorAzul,colorCeleste,colorVioleta,colorRojo,colorGris,colorRan,colorAnterior
        lstColor=[colorAzul,colorCeleste,colorVioleta,colorRojo,colorGris]
        colorAnterior=colorRan
        textoFelicitacion = tipografiaGrande.render('Ronda final', False, colorBlanco)
        ancho=160
        alto=46
        if nivel==1:
            x=380
            y=5
        elif nivel==2:
            x=130
            y=60
        elif nivel==3:
            x=130
            y=60
        pygame.draw.rect(pantalla,colorRan,(x,y,ancho,alto))
        pantalla.blit(textoFelicitacion,(x+5,y,ancho,alto))
        colorRan=random.choice(lstColor)
        pygame.display.update()
            







        
    def dibujarFelicitacion():
        global nivelCompletado,cantidadDeEnergia,segundos,Contador,salirJuego, multijugador 
        x=50
        y=3
        ancho=240
        alto=46
        #Aquí dice que si el nivel completado es verdadero, es decir, si ganaste, entonces cambiará a la pantalla en donde te figurará que ganaste.
        if (nivelCompletado==True):
         #   if multijugador==False:
            #    puntaje = cantidadDeEnergia / segundos#######
            fondo2 = pygame.image.load("primera parte del comic.png")
            fondo2=pygame.transform.scale(fondo2,(1152,648))
            pantalla.blit(fondo2,(0,0))
            ganar.play()
            pygame.display.update()
            pygame.time.delay(2000)
            salirJuego = True

        #Por otro lado, si el juego sigue en marcha, entonces seguirá apareciendo este texto en pantalla.
        else:
            textoFelicitacion = tipografiaGanaste.render('Empuja al virus feo', False, colorBlanco)
            pygame.draw.rect(pantalla,colorLila,(x+80,y,ancho,alto))
            pantalla.blit(textoFelicitacion,(x+85,y,ancho,alto))
            pygame.display.update()








    def estaSolucionadoMultijugador():
        global nivelCompletado, multijugador, modoJuego, Logroganar, cantidadDePasos, nivel
        
        cantVirusSobreAreaProtegida=0

        for punto in lstAreaProtegidaSegundo:
            x=punto[0]
            y=punto[1]

            if zonaDeTransporte[x][y]=='virus':
                 cantVirusSobreAreaProtegida=cantVirusSobreAreaProtegida+1  
            
        if (cantVirusSobreAreaProtegida==len(lstAreaProtegidaSegundo)):
            nivelCompletado=True
        else:
            nivelCompletado=False

        dibujarReglas()
        dibujarFelicitacion()






    
    #Creamos una operación que indique si el nivel fue solucionado
    def estaSolucionado():
        global nivelCompletado, multijugador, modoJuego, Logroganar, cantidadDePasos, nivel
        cantVirusSobreAreaProtegida=0
        pieza=1
        for punto in lstAreaProtegida:
            x=punto[0]
            y=punto[1]

            if modoJuego=='Dificil':
                if zonaDeTransporte[x][y]=='virus':
                     borrarElemento(x,y, zonaDeTransporte)  
                     zonaDeTransporte[x][y]='bloqueado'  
                if zonaDeTransporte[x][y]=='bloqueado':
                 cantVirusSobreAreaProtegida=cantVirusSobreAreaProtegida+1  
            else:
                if zonaDeTransporte[x][y]=='virus':
                    cantVirusSobreAreaProtegida=cantVirusSobreAreaProtegida+1  
 
 
        if (cantVirusSobreAreaProtegida==len(lstAreaProtegida)):
            nivelCompletado=True
            Logroganar=True
        else:
            nivelCompletado=False
            
        dibujarReglas()
        dibujarFelicitacion()
        if multijugador==True:
            estaSolucionadoMultijugador()
        
    

    #Creamos una operación que responda a la tecla "r" y al botón cuando el jugador quiera reiniciar el juego.

    def Reiniciar():
        #Llamamos a las variables.
        global segundos, segundosInmovil, cantidadDePasos, cantidadDeEnergia
        #Ponemos que todas las variables llamadas inicien en su valor original.
        segundos=0
        segundosInmovil=0
        cantidadDePasos=0
        cantidadDeEnergia=7000
        #Hacemos que registre toda la matriz.
        for i in range(1,cantidadDeCasillasPorLado):
            for j in range(1,cantidadDeCasillasPorLado):
                #Y si encuentra al jugador, que lo elimine.
                if (zonaDeTransporte[j][i]=='jugador'):
                    borrarElemento(j,i, zonaDeTransporte)
                #O si encuentra al virus, que lo elimine también.
                elif (zonaDeTransporte[j][i]=='virus'):
                    borrarElemento(j,i, zonaDeTransporte)
                elif (zonaDeTransporte[j][i]=='bloqueado'):
                    borrarElemento(j,i, zonaDeTransporte)
                #Y luego, ubicarlos en su posición original.

        #Si nivel es uno entonces Super Tablet y el virus volverán a sus posiciones iniciales.
        if nivel==1:
            zonaDeTransporte[2][4] = 'jugador'
            zonaDeTransporte[5][4] = 'virus'

        #Si nivel es dos entonces Super Tablet y los virus volverán a las posiciones iniciales.
        if nivel==2:
            zonaDeTransporte[2][5] = 'jugador'
            zonaDeTransporte[3][5] = 'virus'
            zonaDeTransporte[4][5] = 'virus'
            zonaDeTransporte[5][5] = 'virus'
            zonaDeTransporte[6][5] = 'virus'
            zonaDeTransporte[5][6] = 'virus'

        #Si nivel es tres entonces Super Tablet y los virus volverán a las posiciones iniciales.
        if nivel==3:
            zonaDeTransporte[8][3] = 'virus'
            zonaDeTransporte[9][4] = 'virus'
            zonaDeTransporte[4][5] = 'virus'
            zonaDeTransporte[3][8] = 'virus'
            zonaDeTransporte[9][8] = 'virus'
            zonaDeTransporte[5][6] = 'jugador'
            zonaDeTransporte[8][9] = 'virus'

            zonaDeTransporte[2][2] = 'movil'
            zonaDeTransporte[2][3] = 'movil'
            zonaDeTransporte[2][5] = 'movil'
            zonaDeTransporte[2][6] = 'movil'
            zonaDeTransporte[2][7] = 'movil'
            zonaDeTransporte[2][8] = 'movil'
            zonaDeTransporte[2][9] = 'movil'

            zonaDeTransporte[3][3] = 'movil'
            zonaDeTransporte[3][4] = 'movil'
            zonaDeTransporte[3][5] = 'movil'
            zonaDeTransporte[3][6] = 'movil'
            zonaDeTransporte[3][7] = 'movil'
            zonaDeTransporte[3][9] = 'movil'

            zonaDeTransporte[4][2] = 'movil'
            zonaDeTransporte[4][3] = 'movil'
            zonaDeTransporte[4][4] = 'movil'
            zonaDeTransporte[4][6] = 'movil'
            zonaDeTransporte[4][8] = 'movil'
            zonaDeTransporte[4][9] = 'movil'

            zonaDeTransporte[5][3] = 'movil'
            zonaDeTransporte[5][4] = 'movil'
            zonaDeTransporte[5][5] = 'movil'
            zonaDeTransporte[5][7] = 'movil'
            zonaDeTransporte[5][8] = 'movil'
            zonaDeTransporte[5][9] = 'movil'

            zonaDeTransporte[6][2] = 'movil'
            zonaDeTransporte[6][3] = 'movil'
            zonaDeTransporte[6][4] = 'movil'
            zonaDeTransporte[6][5] = 'movil'
            zonaDeTransporte[6][6] = 'movil'
            zonaDeTransporte[6][8] = 'movil'
            zonaDeTransporte[6][9] = 'movil'

            zonaDeTransporte[7][2] = 'movil'
            zonaDeTransporte[7][3] = 'movil'
            zonaDeTransporte[7][4] = 'movil'
            zonaDeTransporte[7][5] = 'movil'
            zonaDeTransporte[7][7] = 'movil'
            zonaDeTransporte[7][8] = 'movil'
            zonaDeTransporte[7][9] = 'movil'

            zonaDeTransporte[8][2] = 'movil'
            zonaDeTransporte[8][4] = 'movil'
            zonaDeTransporte[8][5] = 'movil'
            zonaDeTransporte[8][6] = 'movil'
            zonaDeTransporte[8][7] = 'movil'
            zonaDeTransporte[8][8] = 'movil'

            zonaDeTransporte[9][2] = 'movil'
            zonaDeTransporte[9][3] = 'movil'
            zonaDeTransporte[9][5] = 'movil'
            zonaDeTransporte[9][6] = 'movil'
            zonaDeTransporte[9][7] = 'movil'
            zonaDeTransporte[9][9] = 'movil'

            zonaDeTransporte[2][4] = 'movil'
            zonaDeTransporte[5][2] = 'movil'
            zonaDeTransporte[3][2] = 'movil'
            zonaDeTransporte[7][6] = 'movil'
            zonaDeTransporte[6][7] = 'movil'
            zonaDeTransporte[4][7] = 'movil'
        #Y llamamos a la función dibujarTodo.
        dibujarTodo()





        

    def ReiniciarMulti():
        #Hacemos que registre toda la matriz.
        for i in range(1,cantidadDeCasillasPorLado):
            for j in range(11,cantidadDeCasillasPorLado+9):
                #Y si encuentra al jugador, que lo elimine.
                if (zonaDeTransporte[j][i]=='jugador2'):
                    borrarElemento(j,i, zonaDeTransporte)
                #O si encuentra al virus, que lo elimine también.
                elif (zonaDeTransporte[j][i]=='virus'):
                    borrarElemento(j,i, zonaDeTransporte)
                elif (zonaDeTransporte[j][i]=='bloqueado'):
                    borrarElemento(j,i, zonaDeTransporte)
                #Y luego, ubicarlos en su posición original.

        zonaDeTransporte[11][5] = 'jugador2'
        zonaDeTransporte[12][5] = 'virus'      
        zonaDeTransporte[13][5] = 'virus'    
        zonaDeTransporte[14][5] = 'virus'    
        zonaDeTransporte[15][5] = 'virus' 
        zonaDeTransporte[14][6] = 'virus'
        #Y llamamos a la función dibujarTodo.
        dibujarTodo()





        

    def dibujarTodo():
        global multijugador, cantidadDePasos, pantalla, cantPixelesPorLadoCasillas, nivel
        dibujarFondo()
        dibujarCartelRondaFinal()
        dibujarZonaDeTransporte(zonaDeTransporte, multijugador, cantPixelesPorLadoCasilla, nivel, pantalla, cantidadDeCasillasPorLado, lstAreaProtegida, lstAreaProtegidaSegundo, imgAreaProtegida, imgSuperTablet, imgSuperCelu, imgPared, imgPared2, imgAmenaza)
        dibujarReglas()
        if multijugador==False:
            actualizarContadorDeElectricidad(0)
            contadorDeSegundos(0)
            contadorDeSegundosEstandoInmovil(0)
            cantidadDePasos=actualizarContadorDePasos(cantidadDePasos, multijugador, pantalla, nivel)
            pantalla.blit(botonActual,(botonRect.left, botonRect.top))
            pantalla.blit(puntero,(punteroRect.left,punteroRect.top))
            BotonReiniciar(boton)
            pantalla.blit(botonActual2,(botonRect2.left, botonRect2.top))
            BotonSalir(boton2)
            pantalla.blit(botonActual3,(botonRect3.left, botonRect3.top))
            BotonDeshacer(boton3)
            pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
            BotonVolver(botonVolver)
            jugadores(5, pantalla, " ", nivel)
        elif nivel==3:
            pantalla.blit(puntero,(punteroRect.left,punteroRect.top))
            pantalla.blit(botonActual2,(botonRect2.left, botonRect2.top))
            BotonSalir(boton2)
            pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
            BotonVolver(botonVolver)
            jugadores(5, pantalla, " ", nivel)
        elif multijugador==True:
            pantalla.blit(botonActual,(botonRect.left, botonRect.top))
            pantalla.blit(puntero,(punteroRect.left,punteroRect.top))
            BotonReiniciar(boton)
            pantalla.blit(botonActualReiniciarMulti,(botonRectReiniciarMulti.left, botonRectReiniciarMulti.top))
            pantalla.blit(puntero,(punteroRect.left,punteroRect.top))
            BotonReiniciarMulti(botonReiniciarMulti)
            pantalla.blit(botonActualVolver,(botonRectVolver.left, botonRectVolver.top))
            BotonVolver(botonVolver)
        pygame.display.update()










    #Creamos la función de deshacer.
    
    def deshacerMovimiento():
        global cantidadDePasos,nivel,cantidadDeEnergia,romper,estadoDeEnergiaAnterior,jugadorPosAnterior,jugadorPosActual,virusPosAnterior,virusPosActual,activarDeshacer,zonaDeTransporte
        global colorRan, colorAnterior
        #Restamos un paso.
        cantidadDePasos=cantidadDePasos-2
        #Devolvemos la energía a su estado anterior.
        cantidadDeEnergia=estadoDeEnergiaAnterior
        
    
        #Si activarDeshacer es verdadero entonces ocurrirá esto.
        if activarDeshacer:
            colorRan=colorAnterior
            #Si "romper" es igual a "1" entonces retrocederá un paso.
            if romper == 1 and not nivel==3:
                borrarElemento(jugadorPosActual[0],jugadorPosActual[1], zonaDeTransporte)
                zonaDeTransporte[jugadorPosAnterior[0]][jugadorPosAnterior[1]]='jugador'
            #Sino el jugador retrocederá un paso junto con virus si es que lo empujó.
            else:
                borrarElemento(jugadorPosActual[0],jugadorPosActual[1], zonaDeTransporte)
                zonaDeTransporte[jugadorPosAnterior[0]][jugadorPosAnterior[1]]='jugador'
                borrarElemento(virusPosActual[0],virusPosActual[1], zonaDeTransporte)
                zonaDeTransporte[virusPosAnterior[0]][virusPosAnterior[1]]='virus'
            activarDeshacer=False
            dibujarTodo()







            


    #Esto cumple la funcion de mover los virus solos de forma loca.    
    def MoverVirus():   
        global nivelCompletado
        for i in range(1,cantidadDeCasillasPorLado):
            for j in range(1,cantidadDeCasillasPorLado):
                if (zonaDeTransporte[j][i]=='virus'):
                     if not nivelCompletado:
                        if (zonaDeTransporte[j+1][i]==0) and not hayAreaProtegidaEn(j+1,i, lstAreaProtegida):
                            posicionarElemento('virus',j+1,i, zonaDeTransporte)
                            borrarElemento(j,i, zonaDeTransporte)
                            break
                        elif (zonaDeTransporte[j-1][i]==0) and not hayAreaProtegidaEn(j-1,i, lstAreaProtegida):
                            posicionarElemento('virus',j-1,i, zonaDeTransporte)
                            borrarElemento(j,i, zonaDeTransporte)
                            break
                        elif (zonaDeTransporte[j][i-1]==0) and not hayAreaProtegidaEn(j,i-1, lstAreaProtegida):
                            posicionarElemento('virus',j,i-1, zonaDeTransporte)
                            borrarElemento(j,i, zonaDeTransporte)
                            break
                        elif (zonaDeTransporte[j][i+1]==0) and not hayAreaProtegidaEn(j,i+1, lstAreaProtegida):
                            posicionarElemento('virus',j,i+1, zonaDeTransporte)
                            borrarElemento(j,i, zonaDeTransporte)
                            break






                        

    def eventoTiempo(): 
        global contadorDeSegundos, modoJuego, bandera, tablet, celu2, virus2, tablet2, celu, virus, imgSuperTablet, imgSuperCelu, imgAmenaza
        if bandera == 1 or bandera == 3:
            imgSuperTablet = tablet
            imgSuperCelu = celu2
            imgAmenaza = virus2
        else:
            imgSuperTablet = tablet2
            imgSuperCelu = celu
            imgAmenaza = virus
        bandera = bandera+1
        if bandera > 4:
            bandera = 1
        if bandera == 4:
            contadorDeSegundos(1)
            contadorDeSegundosEstandoInmovil(1)
            if modoJuego == 'Dificil': 
                MoverVirus()








#                    Creamos los movimientos de Super Tablet en los niveles tres y cuatro.

    def irALaDerechaN3():
        for i in range(1,cantidadDeCasillasPorLado):
            for j in range(1,cantidadDeCasillasPorLado):
                if (zonaDeTransporte[j][i]=='jugador'):
                    if (zonaDeTransporte[j+1][i] <> 'pared'):
                        desplazar.play()
                        zonaDeTransporte[j][i]=zonaDeTransporte[j+1][i]
                        posicionarElemento('jugador',j+1,i, zonaDeTransporte)
                        break

    def irALaIzquierdaN3():
        for i in range(1,cantidadDeCasillasPorLado):
            for j in range(1,cantidadDeCasillasPorLado):
                if (zonaDeTransporte[j][i]=='jugador'):
                    if (zonaDeTransporte[j-1][i] <> 'pared'):
                        desplazar.play()
                        zonaDeTransporte[j][i]=zonaDeTransporte[j-1][i]
                        posicionarElemento('jugador',j-1,i, zonaDeTransporte)
                        break

    def irArribaN3():
        for j in range(1,cantidadDeCasillasPorLado):
            for i in range(1,cantidadDeCasillasPorLado):
                if (zonaDeTransporte[j][i]=='jugador'):
                    if (zonaDeTransporte[j][i-1] <> 'pared'):
                        desplazar.play()
                        zonaDeTransporte[j][i]=zonaDeTransporte[j][i-1]
                        posicionarElemento('jugador',j,i-1, zonaDeTransporte)
                        break

    def irAbajoN3():
        for j in range(1,cantidadDeCasillasPorLado):
            for i in range(1,cantidadDeCasillasPorLado):
                if (zonaDeTransporte[j][i]=='jugador'):
                    if (zonaDeTransporte[j][i+1] <> 'pared'):
                        desplazar.play()
                        zonaDeTransporte[j][i]=zonaDeTransporte[j][i+1]
                        posicionarElemento('jugador',j,i+1, zonaDeTransporte)
                        break








    #Creamos operaciones para mover a Super Tablet
        
    def irALaDerecha():
        global cantidadDeEnergia,jugadorPosAnterior,jugadorPosActual,virusPosAnterior,virusPosActual,romper,activarDeshacer,pantalla,cantidadDePasos,cantidadDePasosAnterior
        for i in range(1,cantidadDeCasillasPorLado):
            for j in range(1,cantidadDeCasillasPorLado):
                if (zonaDeTransporte[j][i]=='jugador'):
                    if (zonaDeTransporte[j+1][i]==0):
                        desplazar.play()
                        #Cambiamos la variable de "False" (falso) a "True" (verdadero).
                        activarDeshacer=True
                        #La posición anterior del jugador:
                        jugadorPosAnterior=(j,i)
                        #La posición actual del jugador:
                        jugadorPosActual=(j+1,i)
                        #La variable "romper=1" es para saber si el jugador se movió a una casilla vacía.
                        romper=1
                    
                        posicionarElemento('jugador',j+1,i, zonaDeTransporte)
                        cantidadDePasos=actualizarContadorDePasos(cantidadDePasos, multijugador, pantalla, nivel)
                        cantidadDePasosAnterior=cantidadDePasos
                        actualizarContadorDeElectricidad(10)
                        dibujarCartelRondaFinal()
                        borrarElemento(j,i, zonaDeTransporte)
                        break
                    if(zonaDeTransporte[j+1][i]=='virus') and not ((zonaDeTransporte[j+2][i]=='pared') and not(zonaDeTransporte[j+1][i]=='bloqueado') or (zonaDeTransporte[j+2][i]=='virus') or (zonaDeTransporte[j+2][i]=='bloqueado')):
                        #Cambiamos la variable de "False" (falso) a "True" (verdadero).
                        activarDeshacer=True
                        #Repetimos la ubicación anterior del jugador y la actual:
                        jugadorPosAnterior=(j,i)
                        jugadorPosActual=(j+1,i)
                        #Ahora definimos la posición actual del virus:
                        virusPosAnterior=(j+1,i)
                        #Y definimos la posición anterior del virus:
                        virusPosActual=(j+2,i)
                        #La variable "romper=2" es para saber si empujó un virus.
                        romper=2
                    
                        posicionarElemento('virus',j+2,i, zonaDeTransporte)
                        posicionarElemento('jugador',j+1,i, zonaDeTransporte)
                        cantidadDePasos=actualizarContadorDePasos(cantidadDePasos, multijugador, pantalla, nivel)
                        cantidadDePasosAnterior=cantidadDePasos
                        
                        actualizarContadorDeElectricidad(15)
                        dibujarCartelRondaFinal()
                        borrarElemento(j,i, zonaDeTransporte)
                        break
                    if (zonaDeTransporte[j+1][i]=='virus') and (zonaDeTransporte[j+2][i]=='virus'):
                        actualizarContadorDeElectricidad(200)

    def irArriba():
        global cantidadDeEnergia,jugadorPosAnterior,jugadorPosActual,virusPosAnterior,virusPosActual,romper,activarDeshacer,pantalla,cantidadDePasos,cantidadDePasosAnterior
        for i in range(1,cantidadDeCasillasPorLado):
            for j in range(1,cantidadDeCasillasPorLado):
                if (zonaDeTransporte[j][i]=='jugador'):
                    if (zonaDeTransporte[j][i-1]==0):
                        desplazar.play()
                        activarDeshacer=True
                        #La posición anterior del jugador:
                        jugadorPosAnterior=(j,i)
                        #La posición actual del jugador:
                        jugadorPosActual=(j,i-1)
                        #La variable "romper=1" es para saber si el jugador se movió a una casilla vacía.
                        romper=1

                        posicionarElemento('jugador',j,i-1, zonaDeTransporte)
                        cantidadDePasos=actualizarContadorDePasos(cantidadDePasos, multijugador, pantalla, nivel)
                        cantidadDePasosAnterior=cantidadDePasos
                        actualizarContadorDeElectricidad(10)
                        dibujarCartelRondaFinal()
                        borrarElemento(j,i, zonaDeTransporte)
                        break
                    if(zonaDeTransporte[j][i-1]=='virus') and not ((zonaDeTransporte[j][i-2]=='pared') and not (zonaDeTransporte[j][i-1]=='bloqueado') or (zonaDeTransporte[j][i-2]=='virus') or (zonaDeTransporte[j][i-2]=='bloqueado')):
                        activarDeshacer=True
                        #Repetimos la ubicación anterior del jugador y la actual:
                        jugadorPosAnterior=(j,i)
                        jugadorPosActual=(j,i-1)
                        #Ahora definimos la posición actual del virus:
                        virusPosAnterior=(j,i-1)
                        #Y definimos la posición anterior del virus:
                        virusPosActual=(j,i-2)
                        #La variable "romper=2" es para saber si empujó un virus.
                        romper=2
                    
                        posicionarElemento('virus',j,i-2, zonaDeTransporte)
                        posicionarElemento('jugador',j,i-1, zonaDeTransporte)
                        cantidadDePasos=actualizarContadorDePasos(cantidadDePasos, multijugador, pantalla, nivel)
                        cantidadDePasosAnterior=cantidadDePasos
                        actualizarContadorDeElectricidad(15)
                        dibujarCartelRondaFinal()
                        borrarElemento(j,i, zonaDeTransporte)
                        break
                    if (zonaDeTransporte[j][i-1]=='virus') and (zonaDeTransporte[j][i-2]=='virus'):
                        actualizarContadorDeElectricidad(200)

    def irAbajo():
        global cantidadDeEnergia,jugadorPosAnterior,jugadorPosActual,virusPosAnterior,virusPosActual,romper,activarDeshacer,pantalla,cantidadDePasos,cantidadDePasosAnterior
        for j in range(1,cantidadDeCasillasPorLado):
            for i in range(1,cantidadDeCasillasPorLado):
                if (zonaDeTransporte[j][i]=='jugador'):
                    if (zonaDeTransporte[j][i+1]==0):
                        desplazar.play()
                        activarDeshacer=True
                        #La posición anterior del jugador:
                        jugadorPosAnterior=(j,i)
                        #La posición actual del jugador:
                        jugadorPosActual=(j,i+1)
                        #La variable "romper=1" es para saber si el jugador se movió a una casilla vacía.
                        romper=1

                        posicionarElemento('jugador',j,i+1, zonaDeTransporte)
                        cantidadDePasos=actualizarContadorDePasos(cantidadDePasos, multijugador, pantalla, nivel)
                        cantidadDePasosAnterior=cantidadDePasos
                        actualizarContadorDeElectricidad(10)
                        dibujarCartelRondaFinal()
                        borrarElemento(j,i, zonaDeTransporte)
                        break
                    #Esta función (if) es para cuando el jugador intente empujar un virus (lo cual sí puede) y gaste energía.
                    if(zonaDeTransporte[j][i+1]=='virus') and not ((zonaDeTransporte[j][i+2]=='pared') and not (zonaDeTransporte[j][i+1]=='bloqueado') or (zonaDeTransporte[j][i+2]=='virus')or (zonaDeTransporte[j][i+2]=='bloqueado')):
                        activarDeshacer=True
                        #Repetimos la ubicación anterior del jugador y la actual:
                        jugadorPosAnterior=(j,i)
                        jugadorPosActual=(j,i+1)
                        #Ahora definimos la posición actual del virus:
                        virusPosAnterior=(j,i+1)
                        #Y definimos la posición anterior del virus:
                        virusPosActual=(j,i+2)
                        #La variable "romper=2" es para saber si empujó un virus.
                        romper=2
                    
                        posicionarElemento('virus',j,i+2, zonaDeTransporte)
                        posicionarElemento('jugador',j,i+1, zonaDeTransporte)
                        cantidadDePasos=actualizarContadorDePasos(cantidadDePasos, multijugador, pantalla, nivel)
                        cantidadDePasosAnterior=cantidadDePasos
                        actualizarContadorDeElectricidad(15)
                        dibujarCartelRondaFinal()
                        borrarElemento(j,i, zonaDeTransporte)
                        break
                    #Esta función (if) es para cuando el jugador intente empujar dos virus (lo cual no puede) y gaste energía.
                    if (zonaDeTransporte[j][i+1]=='virus') and (zonaDeTransporte[j][i+2]=='virus'):
                        actualizarContadorDeElectricidad(200)

    def irALaIzquierda():
        global cantidadDeEnergia,jugadorPosAnterior,jugadorPosActual,virusPosAnterior,virusPosActual,romper,activarDeshacer,pantalla,cantidadDePasos,cantidadDePasosAnterior
        for i in range(1,cantidadDeCasillasPorLado):
            for j in range(1,cantidadDeCasillasPorLado):
                if (zonaDeTransporte[j][i]=='jugador'):
                    if (zonaDeTransporte[j-1][i]==0):
                        desplazar.play()
                        activarDeshacer=True
                        #La posición anterior del jugador:
                        jugadorPosAnterior=(j,i)
                        #La posición actual del jugador:
                        jugadorPosActual=(j-1,i)
                        #La variable "romper=1" es para saber si el jugador se movió a una casilla vacía.
                        romper=1
                    
                        posicionarElemento('jugador',j-1,i, zonaDeTransporte)
                        cantidadDePasos=actualizarContadorDePasos(cantidadDePasos, multijugador, pantalla, nivel)
                        cantidadDePasosAnterior=cantidadDePasos
                        actualizarContadorDeElectricidad(10)
                        dibujarCartelRondaFinal()
                        borrarElemento(j,i, zonaDeTransporte)
                        break
                    if (zonaDeTransporte[j-1][i]=='virus') and not ((zonaDeTransporte[j-2][i]=='pared') and not (zonaDeTransporte[j-1][i]=='bloqueado')or (zonaDeTransporte[j-2][i]=='virus')or (zonaDeTransporte[j-2][i]=='bloqueado')):
                        activarDeshacer=True
                        #Repetimos la ubicación anterior del jugador y la actual:
                        jugadorPosAnterior=(j,i)
                        jugadorPosActual=(j-1,i)
                        #Ahora definimos la posición actual del virus:
                        virusPosAnterior=(j-1,i)
                        #Y definimos la posición anterior del virus:
                        virusPosActual=(j-2,i)
                        #La variable "romper=2" es para saber si empujó un virus.
                        romper=2
                    
                        posicionarElemento('virus',j-2,i, zonaDeTransporte)
                        posicionarElemento('jugador',j-1,i, zonaDeTransporte)
                        cantidadDePasos=actualizarContadorDePasos(cantidadDePasos, multijugador, pantalla, nivel)
                        cantidadDePasosAnterior=cantidadDePasos
                        actualizarContadorDeElectricidad(15)
                        dibujarCartelRondaFinal()
                        borrarElemento(j,i, zonaDeTransporte)
                        break
                    if (zonaDeTransporte[j-1][i]=='virus') and (zonaDeTransporte[j-2][i]=='virus'):
                        actualizarContadorDeElectricidad(200)


    def irALaDerechaSegundo():
        global jugadorPosAnteriorSegundo,jugadorPosActualSegundo,virusPosAnterior,virusPosActual,romperSegundo,activarDeshacer,pantalla,cantidadDePasos
        for i in range(3,cantidadDeCasillasPorLado):
            for j in range(11,cantidadDeCasillasPorLado+9):
                if (zonaDeTransporte[j][i]=='jugador2'):
                    if (zonaDeTransporte[j+1][i]==0):
                        desplazar.play()
                        #Cambiamos la variable de "False" (falso) a "True" (verdadero).
                        activarDeshacer=True
                        #La posición anterior del jugador:
                        jugadorPosAnteriorSegundo=(j,i)
                        #La posición actual del jugador:
                        jugadorPosActualSegundo=(j+1,i)
                        #La variable "romper=1" es para saber si el jugador se movió a una casilla vacía.
                        romperSegundo=1
                    
                        posicionarElemento('jugador2',j+1,i, zonaDeTransporte)
                        borrarElemento(j,i, zonaDeTransporte)
                        break
                    if (zonaDeTransporte[j+1][i]=='virus') and not ((zonaDeTransporte[j+2][i]=='pared') or (zonaDeTransporte[j+2][i]=='virus')):
                        #Cambiamos la variable de "False" (falso) a "True" (verdadero).
                        activarDeshacer=True
                        #Repetimos la ubicación anterior del jugador y la actual:
                        jugadorPosAnteriorSegundo=(j,i)
                        jugadorPosActualSegundo=(j+1,i)
                        #Ahora definimos la posición actual del virus:
                        virusPosAnterior=(j+1,i)
                        #Y definimos la posición anterior del virus:
                        virusPosActual=(j+2,i)
                        #La variable "romper=2" es para saber si empujó un virus.
                        romperSegundo=2
                    
                        posicionarElemento('virus',j+2,i, zonaDeTransporte)
                        posicionarElemento('jugador2',j+1,i, zonaDeTransporte)
                        borrarElemento(j,i, zonaDeTransporte)
                        break
                    if (zonaDeTransporte[j+1][i]=='virus') and (zonaDeTransporte[j+2][i]=='virus'):
                        actualizarContadorDeElectricidad(200)

    def irArribaSegundo():
        global jugadorPosAnteriorSegundo,jugadorPosActualSegundo,virusPosAnterior,virusPosActual,romperSegundo,activarDeshacer
        for i in range(3,cantidadDeCasillasPorLado):
            for j in range(11,cantidadDeCasillasPorLado+9):
                if (zonaDeTransporte[j][i]=='jugador2'):
                    if (zonaDeTransporte[j][i-1]==0):
                        desplazar.play()
                        activarDeshacer=True
                        #La posición anterior del jugador:
                        jugadorPosAnteriorSegundo=(j,i)
                        #La posición actual del jugador:
                        jugadorPosActualSegundo=(j,i-1)
                        #La variable "romper=1" es para saber si el jugador se movió a una casilla vacía.
                        romperSegundo=1
                        posicionarElemento('jugador2',j,i-1, zonaDeTransporte)
                        borrarElemento(j,i, zonaDeTransporte)
                        break
                    if(zonaDeTransporte[j][i-1]=='virus') and not ((zonaDeTransporte[j][i-2]=='pared') or (zonaDeTransporte[j][i-2]=='virus')):
                        activarDeshacer=True
                        #Repetimos la ubicación anterior del jugador y la actual:
                        jugadorPosAnteriorSegundo=(j,i)
                        jugadorPosActualSegundo=(j,i-1)
                        #Ahora definimos la posición actual del virus:
                        virusPosAnterior=(j,i-1)
                        #Y definimos la posición anterior del virus:
                        virusPosActual=(j,i-2)
                        #La variable "romper=2" es para saber si empujó un virus.
                        romperSegundo=2
                    
                        posicionarElemento('virus',j,i-2, zonaDeTransporte)
                        posicionarElemento('jugador2',j,i-1, zonaDeTransporte)
                        borrarElemento(j,i, zonaDeTransporte)
                        break
                    if (zonaDeTransporte[j][i-1]=='virus') and (zonaDeTransporte[j][i-2]=='virus'):
                        actualizarContadorDeElectricidad(200)

    def irAbajoSegundo():
        global jugadorPosAnteriorSegundo,jugadorPosActualSegundo,virusPosAnterior,virusPosActual,romperSegundo,activarDeshacer
        for j in range(11,cantidadDeCasillasPorLado+9):
            for i in range(3,cantidadDeCasillasPorLado):
                if (zonaDeTransporte[j][i]=='jugador2'):
                    if (zonaDeTransporte[j][i+1]==0):
                        desplazar.play()
                        activarDeshacer=True
                        #La posición anterior del jugador:
                        jugadorPosAnteriorSegundo=(j,i)
                        #La posición actual del jugador:
                        jugadorPosActualSegundo=(j,i+1)
                        #La variable "romper=1" es para saber si el jugador se movió a una casilla vacía.
                        romperSegundo=1

                        posicionarElemento('jugador2',j,i+1, zonaDeTransporte)
                        borrarElemento(j,i, zonaDeTransporte)
                        break
                    #Esta función (if) es para cuando el jugador intente empujar un virus (lo cual sí puede) y gaste energía.
                    if(zonaDeTransporte[j][i+1]=='virus') and not ((zonaDeTransporte[j][i+2]=='pared') or (zonaDeTransporte[j][i+2]=='virus')):
                        activarDeshacer=True
                        #Repetimos la ubicación anterior del jugador y la actual:
                        jugadorPosAnteriorSegundo=(j,i)
                        jugadorPosActualSegundo=(j,i+1)
                        #Ahora definimos la posición actual del virus:
                        virusPosAnterior=(j,i+1)
                        #Y definimos la posición anterior del virus:
                        virusPosActual=(j,i+2)
                        #La variable "romper=2" es para saber si empujó un virus.
                        romperSegundo=2
                    
                        posicionarElemento('virus',j,i+2, zonaDeTransporte)
                        posicionarElemento('jugador2',j,i+1, zonaDeTransporte)
                        borrarElemento(j,i, zonaDeTransporte)
                        break
                    #Esta función (if) es para cuando el jugador intente empujar dos virus (lo cual no puede) y gaste energía.
                    if (zonaDeTransporte[j][i+1]=='virus') and (zonaDeTransporte[j][i+2]=='virus'):
                        actualizarContadorDeElectricidad(200)

    def irALaIzquierdaSegundo():
        global jugadorPosAnteriorSegundo,jugadorPosActualSegundo,virusPosAnterior,virusPosActual,romperSegundo,activarDeshacer
        for i in range(3,cantidadDeCasillasPorLado):
            for j in range(11,cantidadDeCasillasPorLado+9):
                if (zonaDeTransporte[j][i]=='jugador2'):
                    if (zonaDeTransporte[j-1][i]==0):
                        desplazar.play()
                        activarDeshacer=True
                        #La posición anterior del jugador:
                        jugadorPosAnteriorSegundo=(j,i)
                        #La posición actual del jugador:
                        jugadorPosActualSegu1ndo=(j-1,i)
                        #La variable "romper=1" es para saber si el jugador se movió a una casilla vacía.
                        romperSegundo=1
                    
                        posicionarElemento('jugador2',j-1,i, zonaDeTransporte)
                        borrarElemento(j,i, zonaDeTransporte)
                        break
                    if (zonaDeTransporte[j-1][i]=='virus') and not ((zonaDeTransporte[j-2][i]=='pared') or (zonaDeTransporte[j-2][i]=='virus')):
                        activarDeshacer=True
                        #Repetimos la ubicación anterior del jugador y la actual:
                        jugadorPosAnteriorSegundo=(j,i)
                        jugadorPosActualSegundo=(j-1,i)
                        #Ahora definimos la posición actual del virus:
                        virusPosAnterior=(j-1,i)
                        #Y definimos la posición anterior del virus:
                        virusPosActual=(j-2,i)
                        #La variable "romper=2" es para saber si empujó un virus.
                        romperSegundo=2
                    
                        posicionarElemento('virus',j-2,i, zonaDeTransporte)
                        posicionarElemento('jugador2',j-1,i, zonaDeTransporte)
                        borrarElemento(j,i,  zonaDeTransporte)
                        break
                    if (zonaDeTransporte[j-1][i]=='virus') and (zonaDeTransporte[j-2][i]=='virus'):
                        actualizarContadorDeElectricidad(200)


    #Creamos una pantalla que aparezca apenas inicie el juego.


    zonaDeTransporte=crearZonaDeTransporte(multijugador, cantidadDeCasillasPorLado,lstAreaProtegida,lstAreaProtegidaSegundo,nivel)
    dibujarTodo()

    pygame.time.set_timer(pygame.USEREVENT, 250)

    #Creamos el bucle del juego
    while not salirJuego:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                salirJuego = True
            #A continuación, creamos una función para la animación de Super Tablet y los virus.
            if event.type == pygame.USEREVENT:
                eventoTiempo()
            if event.type == pygame.KEYDOWN:
                #Definimos que la flecha derecha mueva a Super Tablet hacia la derecha.
                if event.key == pygame.K_RIGHT:
                    if nivel==1 or nivel ==2 and not multijugador:
                        irALaDerecha()
                    elif multijugador==True:
                        irALaDerechaSegundo()
                    elif nivel==3:
                        irALaDerechaN3()
                    segundosInmovil=0
                #Definimos que la flecha izquierda mueva a Super Tablet hacia la izquierda.
                elif event.key == pygame.K_LEFT:
                    if nivel==1 or nivel ==2 and not multijugador:
                        irALaIzquierda()
                    elif multijugador==True:
                        irALaIzquierdaSegundo()
                    elif nivel==3:
                        irALaIzquierdaN3()
                    segundosInmovil=0
                #Definimos que la flecha arriba mueva a Super Tablet hacia arriba.
                elif event.key == pygame.K_UP:
                    if nivel==1 or nivel ==2 and not multijugador:
                        irArriba()
                    elif multijugador==True:
                        irArribaSegundo()
                    elif nivel==3:
                        irArribaN3()
                    segundosInmovil=0
                #Definimos que la flecha abajo mueva a Super Tablet hacia abajo.
                elif event.key == pygame.K_DOWN:
                    if nivel==1 or nivel ==2 and not multijugador:
                        irAbajo()
                    elif multijugador==True:
                        irAbajoSegundo()
                    elif nivel==3:
                        irAbajoN3()
                    segundosInmovil=0
                #Definimos que la tecla "d" mueva a Super Celu hacia la derecha.
                elif event.key == pygame.K_d:
                    if multijugador==True:
                        irALaDerecha()
                #Definimos que la tecla "s" mueva a Super Celu hacia la izquierda.
                elif event.key == pygame.K_a:
                    if multijugador==True:
                        irALaIzquierda()
                #Definimos que la tecla "w" mueva a Super Celu hacia arriba.
                elif event.key == pygame.K_w:
                    if multijugador==True:
                        irArriba()
                #Definimos que la tecla "s" mueva a Super Celu hacia abajo.
                elif event.key == pygame.K_s:
                    if multijugador==True:
                        irAbajo()
                #Definimos que la tecla "r" reinicie el juego.
                elif event.key == pygame.K_r:
                    Reiniciar()
                elif event.key == pygame.K_u:
                    if multijugador==True:
                        ReiniciarMulti()
                #Definimos que la tecla "x" deshaga el movimiento actual.
                elif event.key == pygame.K_x:
                    if multijugador==False:
                        deshacerMovimiento()
                elif event.key == pygame.K_b:
                    reset()
                #Definimos que la tecla "ESC/ESCAPE" sirva para salir.
                elif event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if punteroRect.colliderect(botonRectReiniciarMulti):
                    ReiniciarMulti()
                elif punteroRect.colliderect(botonRect):
                    Reiniciar()
                elif punteroRect.colliderect(botonRect2):
                    pygame.quit()
                    quit()
                elif punteroRect.colliderect(botonRect3):       
                    deshacerMovimiento()
                elif punteroRect.colliderect(botonRectSalirMenu):
                    pygame.quit()
                    quit()
                elif punteroRect.colliderect(botonRectVolver):
                    salirJuego = True
    
            dibujarZonaDeTransporte(zonaDeTransporte, multijugador, cantPixelesPorLadoCasilla, nivel, pantalla, cantidadDeCasillasPorLado, lstAreaProtegida, lstAreaProtegidaSegundo, imgAreaProtegida, imgSuperTablet, imgSuperCelu, imgPared, imgPared2, imgAmenaza)
            punteroRect.center=pygame.mouse.get_pos()
            estaSolucionado()

    if multijugador==False and nivelCompletado == True:
        pantallaNOM(pantalla)  
    else:
        salirescribir = True
    
    while not salirescribir:  
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                salirescribir = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:
                    imprimirtecla()
                elif event.key == pygame.K_b:
                    imprimirtecla()
                elif event.key == pygame.K_c:
                    imprimirtecla()
                elif event.key == pygame.K_d:
                    imprimirtecla()
                elif event.key == pygame.K_e:
                   imprimirtecla()
                elif event.key == pygame.K_f:
                    imprimirtecla()
                elif event.key == pygame.K_g:
                    imprimirtecla()
                elif event.key == pygame.K_h:
                    imprimirtecla()
                elif event.key == pygame.K_i:
                    imprimirtecla()
                elif event.key == pygame.K_j:
                    imprimirtecla()
                elif event.key == pygame.K_k:
                    imprimirtecla()
                elif event.key == pygame.K_l:
                    imprimirtecla()
                elif event.key == pygame.K_m:
                    imprimirtecla()
                elif event.key == pygame.K_n:
                    imprimirtecla()
                elif event.key == pygame.K_o:
                    imprimirtecla()
                elif event.key == pygame.K_p:
                    imprimirtecla()
                elif event.key == pygame.K_q:
                    imprimirtecla()
                elif event.key == pygame.K_r:
                    imprimirtecla()
                elif event.key == pygame.K_s:
                    imprimirtecla()
                elif event.key == pygame.K_t:
                    imprimirtecla()
                elif event.key == pygame.K_u:
                    imprimirtecla()
                elif event.key == pygame.K_v:
                    imprimirtecla()
                elif event.key == pygame.K_w:
                    imprimirtecla()
                elif event.key == pygame.K_x:
                    imprimirtecla()
                elif event.key == pygame.K_y:
                    imprimirtecla()
                elif event.key == pygame.K_z:
                    imprimirtecla()
                elif event.key == pygame.K_0:
                    imprimirtecla()
                elif event.key == pygame.K_1:
                    imprimirtecla()
                elif event.key == pygame.K_2:
                    imprimirtecla() 
                elif event.key == pygame.K_3:
                    imprimirtecla()
                elif event.key == pygame.K_4:
                    imprimirtecla()
                elif event.key == pygame.K_5:
                    imprimirtecla()
                elif event.key == pygame.K_6:
                    imprimirtecla()
                elif event.key == pygame.K_7:
                    imprimirtecla()
                elif event.key == pygame.K_8:
                    imprimirtecla()
                elif event.key == pygame.K_9:
                    imprimirtecla()
                elif event.key == pygame.K_SPACE:
                    imprimirtecla()
                elif event.key == pygame.K_BACKSPACE:
                    retornodeborrar=(borrartecla(x,y, indice, pantalla))
                    x=retornodeborrar[0]
                    indice=retornodeborrar[1]
                elif event.key == pygame.K_RETURN:
                    if modoJuego== "Facil" and nivel==1:
                        grabararchiv("facilrankingN1.txt", puntaje, lista, indice)
                        jugadores(8, pantalla, "facilrankingN1.txt", nivel)
                    elif modoJuego== "Facil" and nivel==2:
                        grabararchiv("facilrankingN2.txt", puntaje, lista, indice)
                        jugadores(8, pantalla, "facilrankingN2.txt", nivel)
                    elif modoJuego== "Facil" and nivel==3:
                        grabararchiv("facilrankingN3.txt", puntaje, lista, indice)
                        jugadores(8, pantalla, "facilrankingN3.txt", nivel)
                    elif modoJuego== "Dificil" and nivel==1:
                        grabararchiv("dificilrankingN1.txt", puntaje, lista, indice)
                        jugadores(8, pantalla, "dificilrankingN1.txt", nivel)
                    elif modoJuego== "Dificil" and nivel==2:
                        grabararchiv("dificilrankingN2.txt", puntaje, lista, indice)
                        jugadores(8, pantalla, "dificilrankingN2.txt", nivel)
                    elif modoJuego== "Dificil" and nivel==3:
                        grabararchiv("dificilrankingN3.txt", puntaje, lista, indice)
                        jugadores(8, pantalla, "dificilrankingN3.txt", nivel)
                    salirescribir = True
                    

pygame.quit()
quit()
