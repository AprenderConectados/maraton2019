#-*- coding: utf-8 -*-
#Imprime el menu inicial
"""Equipo: Meaningful Name; Integrantes:
Asteasuain Martina, Garcia Romina y Zentrigen Rocio.
Colegio : Escuela Superior de Comercio "Prudencio Cornejo", Bahia Blanca"""

#.....................................................................
#Importacion de librerias
import pygame
import sys
from pygame.locals import *
import random
import time
pygame.init() #se inicializa la libreria pygame
  
#.............................................................................
def ventanaInicial(ventana):
  inicio = True #variable para determinar si la pantalla de inicio se esta ejecutando
  #importacion de imagenes
  fondo = pygame.image.load("imagenes/imagenInicio.png")
  tablet = pygame.image.load("imagenes/tablet0.png")
  globo = pygame.image.load("imagenes/globo.png")
  costume = pygame.image.load("imagenes/randomfactV.png")
  musicae = pygame.image.load("imagenes/musica_encendido.png")
  musicaa = pygame.image.load("imagenes/musica_apagado.png")
  musicaArribae = pygame.image.load("imagenes/musica_encendido_pressed.png")
  musicaArribaa = pygame.image.load("imagenes/musica_apagado_pressed.png")
  #declaracion de variables
  font = pygame.font.Font("BOOKOS.TTF",25)
  menu = [0,0,0,0]
  dialogo = -1
  mensajes = random_facts()
  hecho = iter(mensajes[0])
  us = iter(mensajes[1])
  gracias = iter(mensajes[2])
  fact = random.choice(mensajes[0])
  texto = font.render(("Ronda Final"),0,(0,0,0))#Texto de la Ronda Final

  #variables de la música
  if pygame.mixer.music.get_busy():
   musica = musicae
   musicaArriba = musicaArribae
  else:
   musica = musicaa
   musicaArriba = musicaArribaa
   
  #las siguientes variables corresponden a la animacion de super tablet
  posY = 280 # donde se imprime la imagen   
  subir = 0 #aumenta en cada while e indica cuando cambiar el movimiento 
  contador = 0 #maneja la direccion del movimiento

  #los siguientes objetos corresponden a los botones interactivos del programa
  botonI = pygame.Rect(650,300,250,50) #boton para cuando el usuario quiera iniciar el juego
  botonIn = pygame.Rect(650,400,250,50) #boton para cuando el usuario pida ver las instrucciones
  botonPos = pygame.Rect(650,500,250,50) #boton para cuando el usuario puda ver la tabla de las posiciones
  botonS = pygame.Rect(920,542,130,50) #boton para cuando el usuario quiera salir del juego
  botonF = pygame.Rect(490,60,60,60) #boton para cuando el usuario quiera salir del juego
  botonRF = pygame.Rect(500,132,60,60) #boton de mensajes sobre ciberseguridad 
  botonA = pygame.Rect(500,202,60,60) #boton de mensajes de agradecimieto
  botonG = pygame.Rect(500,272,60,60) #boton de integrantes del grupo
  botonC = pygame.Rect(500,342,60,60) #boton para sacar el globo de diálogo y/o el disfráz de Super Tablet
  musica_rect = pygame.Rect(970,50,musica.get_size()[0],musica.get_size()[1]) #boton para cuando el usuario quiera desactivar/activar la música

  #las siguientes imagenes se van a activar cuando el mouse este arriba de los botones
  botonArriba1 = pygame.image.load("imagenes/botonA.png") #botones de iniciar/instruc./posiciones
  botonArriba2 = pygame.image.load("imagenes/boton2A.png") #boton salir
  
  #a continuacion se importaran los textos necesarios para los botones y la fuente 
  mensaje_iniciar = pygame.image.load("imagenes/iniciarT.png")
  mensaje_instruc = pygame.image.load("imagenes/instT.png")
  mensaje_pos = pygame.image.load("imagenes/posT.png")
  mensaje_salir = pygame.image.load("imagenes/salirT.png")
  bfacts = pygame.image.load("imagenes/random.png")
  babout = pygame.image.load("imagenes/about.png")
  bgrax = pygame.image.load("imagenes/thanks.png")
  bclose = pygame.image.load("imagenes/close.png")
  barriba = pygame.image.load("imagenes/botonArriba3.png")
  bflecha = pygame.image.load("imagenes/flecha_menu.png")
  bflecha2 = pygame.image.load("imagenes/flecha_menu_pressed.png")
  botones = [bfacts,babout,bgrax,bclose,bflecha,bflecha2]
  for i in range(0,4):
    botones[i]=pygame.transform.scale(botones[i],(60,60))
  botones[4]=pygame.transform.scale(botones[4],(85,60))
  botones[5]=pygame.transform.scale(botones[5],(85,60))

  #bucle principal de la pantalla inicial
  while inicio:
    #se imprime el fondo
    ventana.blit(fondo,(0,0))
    
    #animacion de menu desplegable
    for i in range(0,4):
      try:
        if menu[i-1]>7 and menu[i]<1:
          menu[i]=1
      except:
        pass
      if (menu[i]>0) and (menu[i]<8):
        menu[i] = menu[i] + 1
    mouse = pygame.mouse.get_pos() #obtiene la posXeY del mouse para las imagenes c/transparencia
    
    for event in pygame.event.get():

      if event.type == QUIT: #para que se cierre la ventana cuando el usuario lo quiera
        pygame.quit()
        sys.exit()    

      if event.type == pygame.MOUSEBUTTONDOWN: #de esta manera se guarda la posicion del mouse para saber si esta apretando algun boton
        mouse_pos = event.pos
        
        if botonS.collidepoint(mouse_pos): #sirve para salir del juego cuando el usuario selecciona el boton indicado
          pygame.quit()
          sys.exit()

        #si se presiona sobre el botón música, se inicia o se detiene y se cambian las variables de la foto que se imprime
        if musica_rect.collidepoint(mouse_pos):
          if pygame.mixer.music.get_busy():
            pygame.mixer.music.stop()
            musica = musicaa 
            musicaArriba = musicaArribaa 
          else:
            pygame.mixer.music.play(-1)
            musica = musicae
            musicaArriba = musicaArribae

        if botonIn.collidepoint(mouse_pos): #sirve para iniciar la pantalla de instrucciones
          return "instrucciones"
        if botonI.collidepoint(mouse_pos): #sirve para iniciar la pantalla inicial del juego
          return "iniciar"
        if botonPos.collidepoint(mouse_pos): #sirve para iniciar la pantalla con la tabla de posiciones
          return "posiciones"
        
        #Al apretar la flecha se desplega el menu
        if botonF.collidepoint(mouse_pos):
          if menu[0]>0:
            menu = [0,0,0,0]
          else:
            menu[0] = 1
          
        if menu[3]> 7:
          #Si se apreta el 1er boton muestra un mensaje sobre la ciberseguridad
          if botonRF.collidepoint(mouse_pos):
            dialogo = 1
            try:
              fact = next(hecho)
            except:
              hecho = iter(mensajes[0])
              fact = next(hecho)

          #Si se apreta el 2do boton muestra un mensaje sobre las creadoras del juego
          if botonA.collidepoint(mouse_pos):
            dialogo = 2
            try:
              fact = next(us)
            except:
              us = iter(mensajes[1])
              fact = next(us)

          #Si se apreta el 3er boton muestra un mensaje de agradecimiento
          if botonG.collidepoint(mouse_pos):
            dialogo = 3
            try:
              fact = next(gracias)
            except:
              gracias = iter(mensajes[2])
              fact = next(gracias)
              
          #Si se apreta el 4to boton cierra la burbuja de dialogo y/o el disfraz de tablet
          if botonC.collidepoint(mouse_pos):
            dialogo = -1
            
        
            
        
    #las siguientes lineas de codigo hacen referencia a la impresion de los botones y su respectiva imagen-texto
    pygame.draw.rect(ventana,(255,255,255),botonI) 
    ventana.blit(mensaje_iniciar,(647,300))
                   
    pygame.draw.rect(ventana,(255,255,255),botonIn)
    ventana.blit(mensaje_instruc,(650,400))
                   
    pygame.draw.rect(ventana,(255,255,255),botonPos)
    ventana.blit(mensaje_pos,(655,500))
                   
    pygame.draw.rect(ventana,(255,0,0),botonS)
    ventana.blit(mensaje_salir,(920,542))

    pygame.draw.rect(ventana,(14,77,87),botonF)
    ventana.blit(botones[4],(490,60))

    ventana.blit(texto,(980,598))

    #las siguientes lineas de codigo son para imprimir una imagen c/transparencia para indicar que el mouse esta sobre el boton correspondiente
    if botonI.collidepoint(mouse):
      ventana.blit(botonArriba1,(650,300))
    elif botonIn.collidepoint(mouse):
      ventana.blit(botonArriba1,(650,400))
    elif botonPos.collidepoint(mouse):
      ventana.blit(botonArriba1,(650,500))
    elif botonS.collidepoint(mouse):
      ventana.blit(botonArriba2,(920,542))
    elif botonF.collidepoint(mouse):
      ventana.blit(botones[5],(490,60))
      
    #impresion de botones desplegables
    if menu[0] > 7:
      ventana.blit(botones[0],(500,132))
      if botonRF.collidepoint(mouse): #si el mouse está sobre el botón imprime la foto con transparencia
       ventana.blit(pygame.transform.scale(barriba,(60,60)),(500,132))
    if menu[1] > 7:
      ventana.blit(botones[1],(500,202))
      if botonA.collidepoint(mouse): #si el mouse está sobre el botón imprime la foto con transparencia
       ventana.blit(pygame.transform.scale(barriba,(60,60)),(500,202))
    if menu[2] > 7:
      ventana.blit(botones[2],(500,272))
      if botonG.collidepoint(mouse): #si el mouse está sobre el botón imprime la foto con transparencia
       ventana.blit(pygame.transform.scale(barriba,(60,60)),(500,272))
    if menu[3] > 7:
      ventana.blit(botones[3],(500,342))
      if botonC.collidepoint(mouse): #si el mouse está sobre el botón imprime la foto con transparencia
       ventana.blit(pygame.transform.scale(barriba,(60,60)),(500,342))     

    #animacion de super tablet:
    if contador % 2 == 0:
      posY = posY + 2       #el movimiento de la tableta va hacia arriba y abajo -
    else:                   #cambiando con el contador, cosa que sucede cada 15 while
      posY = posY - 2
    subir = subir + 1
    if subir % 15 == 0:    # cada 15 veces que se repita el while, suma contador
      contador = contador + 1
      
    ventana.blit(tablet,(155,posY))
    if dialogo == 1:
      ventana.blit(costume,(155,posY))
    if (dialogo > 0):
      ventana.blit(globo,(60,80))
      imprimir_fact(fact,ventana,(100,95),(0,0,0))

    #se imprime el botón para activar/desactivar la música
    if musica_rect.collidepoint(mouse):
      ventana.blit(musicaArriba,(970,50))
    else:
      ventana.blit(musica,(970,50))
                         
    pygame.display.flip() #hace un update de la pantalla
            
                    

def random_facts():
  #Declaracion de variables
  todo = []
  lineas = []
  # Se abre el archivo para leer y se guarda el texto en una variable
  archivo = open("archivos/texto_globo_menu.txt", "r")
  todo = archivo.read().splitlines()
  #Se separa el texto en lineas que contienen los distintos mensajes
  lineas = todo[0].split(",")
  about = todo[1].split(",")
  grax = todo[2].split(",")
  return [lineas,about,grax]

#esta funcion utiliza un archivo de texto para imprimir mensajes
def imprimir_fact(mensaje,pantalla,(ancho,altura),color):
  linea = ""
  fact = mensaje.split(";")
  font = pygame.font.SysFont("Bookman Old Style", 35)
  for linea in fact:
    line = font.render(linea,0,color)
    pantalla.blit(line,(ancho,altura))
    altura = altura + 35







 

	
	
