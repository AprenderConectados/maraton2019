#Funciones que determinan si se gano o perdio el nivel
"""Equipo: Meaningful Name; Integrantes:
Asteasuain Martina, Garcia Romina y Zentrigen Rocio.
Colegio : Escuela Superior de Comercio "Prudencio Cornejo", Bahia Blanca"""

#..........................................................................
#Definicion de librerias
import pygame
from pygame import *
import time

#..........................................................................
#Funcion que devuelve True si se gano el juego, se llevaron todas las amenazas a las zonas seguras
def victoria(enemigos,zona_seg):
    if enemigos.derrotados == enemigos.max_derrotar:
        return True
    else:
        return False

#Funcion que devuelve False si se quedo sin bateria o Super Tablet estuvo inactiva mas de 15 segundos
def derrota(jugador,enemigos,tiempo,paredes):

    if (jugador.bateria <= 10)or(jugador.tiempo_quieto/1000 >= 17):
        return True
    else:
        return False

