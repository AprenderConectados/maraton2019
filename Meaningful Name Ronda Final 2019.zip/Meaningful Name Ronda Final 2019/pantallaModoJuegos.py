#IMprime la pantalla a elegir el modo de juego
"""Equipo: Meaningful Name; Integrantes:
Asteasuain Martina, Garcia Romina y Zentrigen Rocio.
Colegio : Escuela Superior de Comercio "Prudencio Cornejo", Bahia Blanca"""

#.......................................................................
#se importaran las librerias necesarias para el desarrollo del programa
import pygame
import sys
from pygame.locals import *

pygame.init() #se inicializa la liberia pygame

#............................................................................
def pantallaModoDeJuego(ventana):
    inicio = True #variable usada para la ejecucion del programa
    fondo = pygame.image.load("imagenes/modosjuego.jpg")
    font = pygame.font.Font("BOOKOS.TTF",25)    

    #3 imagenes usadas como explicacion de cada modo de juego cuando el usuario lo selecciona
    textoClasico = pygame.image.load("imagenes/textoclasico.png")
    textoExperto = pygame.image.load("imagenes/textoexperto.png")
    textoNocturno = pygame.image.load("imagenes/textonocturno.png")
    
    botonC = pygame.Rect(150,225,187,190) #boton para seleccionar el modo de juego clasico
    botonE = pygame.Rect(470,225,187,190) #boton para seleccionar el modo de juego experto
    botonN = pygame.Rect(795,225,187,190) #boton para seleccionar el modo de juego nocturno
    botonV = pygame.Rect(935,530,130,50)#Boton que vuelve al inicio
    texto_volver = pygame.image.load("imagenes/volverT.png") 
    botonArriba2 = pygame.image.load("imagenes/boton2A.png") #imagen para indicar que el mouse esta sobre el boton
    texto = font.render("Ronda Final",0,(0,0,0))
    
    #bucle principal de los modos de juego
    while inicio:
        ventana.blit(fondo,(0,0))
        pygame.draw.rect(ventana,(255,255,255),botonV)
        ventana.blit(texto_volver,(935,530))
        ventana.blit(texto,(980,598))
        mouse = pygame.mouse.get_pos() ##obtiene la posXeY del mouse para la imagen c/transparencia

        for event in pygame.event.get(): #para que se cierre la ventana cuando el usuario lo quiera
            if event.type == QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN: #de esta manera se guarda la posicion del mouse para saber si esta apretando el boton
                mouse_pos = event.pos

                if botonC.collidepoint(mouse_pos): #devuelve que el modo de juego elegido es el clasico 
                    return "clasico"
                    
                if botonE.collidepoint(mouse_pos): #devuelve que el modo de juego elegido es el experto 
                    return "experto"
                    
                if botonN.collidepoint(mouse_pos): #devuelve que el modo de juego elegido es el nocturno 
                    return "nocturno"

                if botonV.collidepoint(mouse_pos): #devuelve si el usuario desea regresar a la pantalla anterior
                    return "v"
                    

        
        if botonC.collidepoint(mouse): #devuelve que el modo de juego sobre el que esta parado es el clasico e imprime su descripcion
            ventana.blit(textoClasico,(170,290))
        if botonE.collidepoint(mouse): #devuelve que el modo de juego sobre el que esta parado es el experto e imprime su descripcion
            ventana.blit(textoExperto,(170,290))
        if botonN.collidepoint(mouse): #devuelve que el modo de juego  sobre el que esta parado es el nocturno e imprime su descripcion
            ventana.blit(textoNocturno,(170,290))
        if botonV.collidepoint(mouse): #imprime una imagen con transparencia que indica que el cursor esta arriba del boton
            ventana.blit(botonArriba2,(935,530))
            

        pygame.display.flip() #actualiza la pantalla




        
            
                    
            
    

    
    
