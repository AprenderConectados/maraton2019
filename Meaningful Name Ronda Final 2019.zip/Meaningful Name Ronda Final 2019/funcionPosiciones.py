#Posiciona la cantidad de objetos dados en lugares aleatorios posibles
"""Equipo: Meaningful Name; Integrantes:
Asteasuain Martina, Garcia Romina y Zentrigen Rocio.
Colegio : Escuela Superior de Comercio "Prudencio Cornejo", Bahia Blanca"""

#...........................................................................
#Definicion de librerias
import pygame
from pygame import *
import random
pygame.init()

#...........................................................................
#Funcion que genera las posiciones random, recibiendo la cantidad de objetos de
#cada clase que se requieren
def lugares_random(casillasL,casillasA,pos_areasegura,cant_segura,amenaza,cant_amenazas,pos_paredes,jugador):

    #Definicion de variables
    jugada = [0,0,0,0,0,0] # guarda la jugada inicial
    pos_libre = [] 
    pos_esquinas = [] #posiciones en que aparecen las zonas protegidas
    posx = 0
    posy = 0
    cas = 0 #iterador
    i = 0 #iterador

    #Agrega las 4 esquinas a la lista 
    pos_esquinas.append((1,1))
    pos_esquinas.append((1,casillasA-2))
    pos_esquinas.append((casillasL-2,1))
    pos_esquinas.append((casillasL-2,casillasA-2))
        
    #llama a la funcion que genera una lista con las posiciones vacias del tablero
    pos_libre = lugares_libres(pos_esquinas,amenaza,jugador,casillasL,casillasA)

    #Posiciona las paredes en el borde exterior del tablero
    for i in range(0,casillasL-1):
        if (i<casillasA):
            pos_paredes.append((0,casillasA-1-i))
            pos_paredes.append((casillasL-1,casillasA-1-i))         
        pos_paredes.append((i,0))
        pos_paredes.append((i,casillasA-1))

    #Genera la cantidad de areas protegidas requeridas
    for cas in range(0,cant_segura):
        pos = random.choice(pos_esquinas)
        pos_areasegura.append(pos)
        pos_esquinas.remove(pos)
        #Saca los lugares cercanos a las zonas seguras para bajar la dificultad del juego

        
        
    #Llama a la funcion que genera la cantidad de amenazas requeridas
    amenaza_random(amenaza,cant_amenazas,pos_libre)
    #Guarda la jugada inicial random en la lista de jugadas
    jugada[0]=jugador.posicion #posicion de tableta
    jugada[1]=amenaza.posicion[:] #posicion de los virus
    jugada[2]=dict(amenaza.tipo_virus)#tipos de virus en posicion
    jugada[3]=jugador.contador#guarda la cantidad de movimientos
    jugada[4]=jugador.bateria#guarda la bateria
    jugada[5]=jugador.color_final_actual#Guarda el color de fondo de Ronda Final
    jugador.jugadas.append(jugada)

#Funcion que devuelve una lista con las posiciones libres del tablero
def lugares_libres(pos_esquinas,amenazas,jugador,casillasL,casillasA):

    pos_centro = []
    #Genera una lista con las posiciones del tablero
    for posx in range(1,casillasL-1):
        for posy in range(1,casillasA-1):
            pos_centro.append((posx,posy))

    #Le intenta sacar a la lista las posiciones ocupadas
    try:
        pos_centro.remove(jugador.posicion)
    except:
        pass
    pos_centro.remove((5,2))
    pos_centro.remove((1,2))
    pos_centro.remove((6,2))
    for cas in amenazas.posicion:
        try:
            pos_centro.remove(cas)
        except:
            pass
    for cas in pos_esquinas:
        try:
            pos_centro.remove(cas)
        except:
            pass
    return pos_centro #devuelve la lista con los lugares vacios

#Funcion que genera nuevas amenazas
def amenaza_random(amenaza,cant,posiciones):
    for cas in range(0,cant):
        #Genera una posicion random
        ubicacion = random.choice(posiciones)
        while ubicacion in amenaza.posicion:
            ubicacion = random.choice(posiciones)
        #La agrega a la lista de posiciones de amenaza
        amenaza.posicion.append(ubicacion)
        #Le asigna la foto correspondiente
        foto = amenaza.orden[len(amenaza.posicion)+amenaza.derrotados-1]
        amenaza.tipo_virus[ubicacion]=foto
        #Saca la ubicacion de la lista de posiciones libres
        posiciones.remove(ubicacion)
        #Saca las del costado para bajar la dificultad del juego
        try:
            posiciones.remove((ubicacion[0]+1,ubicacion[1]))
        except:
            pass
        try:
            posiciones.remove((ubicacion[0]-1,ubicacion[1]))
        except:
            pass

#Funcion que asigna las posiciones iniciales
def iniciar_pos(niv,amenaza,pos_paredes,casillas_lado,casillas_alto,zonas_prot,jugador):
    
    jugada = [0,0,0,0,0,0]# guarda la jugada inicial
    #Segun el nivel se generan las posiciones de los virus y zonas protegidas
    if niv == 1 or niv == 3:
        posiciones = [(1,2),(3,2),(4,2),(5,1),(5,3)]
        zonas = [(1,1),(6,1),(6,3),(5,2),(3,3)]
    if niv == 5 or niv == 7:
        posiciones = [(2,1),(2,2),(4,1),(4,3),(5,2)]
        zonas = [(1,1),(6,1),(6,3),(1,2),(3,1)]
    if niv == 6 or niv == 4 or niv == 8:
        posiciones = [(2,2),(3,2),(4,2),(5,2),(4,3)]
        zonas = [(1,1),(6,1),(6,3),(1,3),(3,3)]
    
    for i in posiciones:
        #Se llama a la funcion que agrega cada posicion a la lista de posiciones de los virus
        pos_virus(amenaza,i)

    #Se agregan las posiciones del borde del tablero a la lista de paredes
    for i in range(0,casillas_lado-1):
        if (i<casillas_alto):
            pos_paredes.append((0,casillas_alto-1-i))
            pos_paredes.append((casillas_lado-1,casillas_alto-1-i))         
        pos_paredes.append((i,0))
        pos_paredes.append((i,casillas_alto-1))

    #Se agregan a la lista de zonas protegidas sus posiciones
    zonas_prot.extend(zonas)
    #se guarda la jugada inicial en la lista de jugadas
    jugada[0]=jugador.posicion #guarda la posicion de la tableta
    jugada[1]=amenaza.posicion[:]#guarda las posiciones del virus
    jugada[2]=dict(amenaza.tipo_virus)#guarda los tipos de virus para cada posicion
    jugada[3]=jugador.contador#guarda la cantidad de movimientos
    jugada[4]=jugador.bateria#guarda la bateria
    jugada[5]=jugador.color_final_actual#Guarda el color de fondo de Ronda Final
    jugador.jugadas.append(jugada)
    

#funcion que asigna una foto a las posiciones de los virus
def pos_virus(amenaza,ubicacion): 
    amenaza.posicion.append(ubicacion)
    foto = amenaza.orden[len(amenaza.posicion)+amenaza.derrotados-1]
    amenaza.tipo_virus[ubicacion]=foto
    









