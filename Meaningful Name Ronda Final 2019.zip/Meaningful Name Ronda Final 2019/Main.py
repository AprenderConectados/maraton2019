#-*- coding: utf-8 -*-
#Inicio Ronda 3 - 2019
"""Equipo: Meaningful Name; Integrantes:
Asteasuain Martina, Garcia Romina y Zentrigen Rocio.
Colegio : Escuela Superior de Comercio "Prudencio Cornejo", Bahia Blanca"""
"""Propone 3 modos de juego uno clasico replicando el de la consigna, el experto
en el que se generan niveles aleatorios y el nocturno con vision reducida"""

#.........................................................................
#Declaracion de librerias
import pygame
import sys
import random
#Importacion de modulos
from pantallaInicio import ventanaInicial
from funcionModos import *

#..........................................................................
#Inicializacion de la libreria Pygame, musica y variables de tipografia
pygame.init()
pygame.font.init()
pygame.mixer.init()
pygame.mixer.music.load('musica/03-lasergun1.mp3')
pygame.mixer.music.play(-1)
pygame.display.set_caption("Maraton 2019 - Ronda Final")

#.........................................................................
#Inicializacion de variables
ancho = 1152
alto = 648
pantalla = pygame.display.set_mode((ancho,alto))
inicio_tablero=(300,150) #Posicion en la que se imprime el tablero
salir = False #Salir del juego
evento = [5,0,0,0] #en esta variable se guardan los datos del nivel [resultado,movimientos,tiempo]
bateria = 7000
#Variables que guardan el progreso de los modos
progreso_cla = [0,0,0] #[sonido(on/off),ultimo nivel,puntaje]
progreso_exp = [0,7000,0]#[ultimo nivel,bateria,sonido(on/off)]
progreso_noc = [0,0,0]#[sonido(on/off),ultimo nivel,puntaje]
modo = "" #Devuelve que boton se apreta en el menu inicial
modo_juego = "" #Devuelve que modo de juego se elige
estado_sonido = 1 #Indica el estado del sonido al mover super tablet, 1 encendido -1 apagado

#....................................................................................................
#bucle principal del juego
while not salir:
    #Termina el juego si se cierra la ventana
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            salir = True
    #ventanaInicial muestra el menu inicial y devuelve el boton presionado
    modo = ventanaInicial(pantalla)
    
    if modo == "iniciar": #Si se presiona el boton iniciar va a la pantalla elegir modo de juego
        modo_juego = elejir(pantalla)
        #Cada modo devuelve el ultimo nivel al que se llego y el estado del sonido
        if modo_juego == "clasico":
            progreso_cla = nivel_clasico(pantalla,estado_sonido,progreso_cla)
            estado_sonido = progreso_cla[0]
        if modo_juego == "nocturno":
            progreso_noc = nivel_nocturno(pantalla,estado_sonido,progreso_noc)
            estado_sonido = progreso_noc[0]
        if modo_juego == "experto":
            progreso_exp = nivel_experto(pantalla,progreso_exp,estado_sonido)
            estado_sonido = progreso_exp[2]
        
    if modo == "instrucciones":#Si se presiona el boton instrucciones muestra las instrucciones
        tutorial(pantalla)

    if modo == "posiciones":#Si se presiona el boton posiciones muestra la tabla de puntajes de todo los modos
        tablas_puntaje(pantalla)

    
pygame.quit()
quit()
