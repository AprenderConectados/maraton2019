#Ejecuta el nivel 
"""Equipo: Meaningful Name; Integrantes:
Asteasuain Martina, Garcia Romina y Zentrigen Rocio.
Colegio : Escuela Superior de Comercio "Prudencio Cornejo" """
#.......................................................................................
#Declaracion de librerias
import pygame
import sys
import random
import time
#importacion de modulos
from claseJugador import jugador
from pantallaInicio import *
from claseEnemigo import enemigo
from funciondibujar import *
from funcionMover import mover
from funcionPosiciones import *
from terminarNivel import *
from TablaPuntaje import *
#.......................................................................................
#Funcion Nivel, corre un nivel 
def nivel(niv,max_virus,max_bateria,niv_experto,pantalla,inicio_tablero,estado_sonido): 
    #.........................................................................               
    #inicializacion de variables
    dimensiones = (1153,648)
    scores = [] #Guardara el contenido del archivo de los puntajes
    devolucion_pausa = 0 
    #Crea un reloj del cual se sacan cuanto segundos pasaron desde el inico de pygame
    clock = pygame.time.Clock()
    tinicio = pygame.time.get_ticks()
    contador_tiempo = 0 #contador del que se obtiene el tiempo en formato mm:ss (siguientes dos variables)
    horas = 0
    minutos = 0
    segundos = 0
    resta = 0 #al tiempo transcurrido en juego le resta el tiempo en pausa
    tiempo = "00:00"
    tipografia = pygame.font.Font("BOOKOS.TTF", 28)
    font = pygame.font.Font("BOOKOS.TTF",25)
    #listas que contendran las posiciones de los objetos
    zonas_prot = [] 
    pos_paredes = []
    libre = []
    #Dimensiones del tablero de juego
    casillas_lado = 8
    casillas_alto = 5
    pixeles_casilla = 65
    #Inicializacion de objetos
    tableta=jugador(pixeles_casilla,(2,3))
    amenaza=enemigo(pixeles_casilla,max_virus)
    tableta.ultima_jugada = tinicio
    tableta.bateria = max_bateria
    #Se cargan y escalan las imagenes
    area_protegida = pygame.image.load("imagenes/areaprotegida.PNG")
    area_protegida = pygame.transform.scale(area_protegida,(pixeles_casilla,pixeles_casilla))
    fondo = pygame.image.load("imagenes/monitor.jpg")
    fondo = pygame.transform.scale(fondo,dimensiones)
    pared = pygame.image.load("imagenes/pared.jpg")
    pared = pygame.transform.scale(pared,(pixeles_casilla,pixeles_casilla))
    botonP = pygame.Rect(868,460,130,50)#Boton Pausa
    botonArriba2 = pygame.image.load("imagenes/boton2A.png")

    #.........................................................................
    #llamadas a funciones que inician el nivel
    #Dependiendo del modo las posiciones son fijas o se generan aleatoriamente
    if niv == 2:
        scores = LeerPuntaje("archivos/PuntajesTiempo.txt")
        #lugares_random genera posiciones aleatorias
        lugares_random(casillas_lado,casillas_alto,zonas_prot,max_virus,amenaza,max_virus,pos_paredes,tableta)
    else:
        #iniciar_pos inicializa las posiciones de cada objeto
        iniciar_pos(niv,amenaza,pos_paredes,casillas_lado,casillas_alto,zonas_prot,tableta)
        if niv == 1 or niv == 5 or niv == 6:
            scores = LeerPuntaje("archivos/Puntajes.txt")
        else:
            if niv == 3 or niv == 7 or niv == 8:
                scores = LeerPuntaje("archivos/PuntajesLuz.txt")
            else:
                scores = LeerPuntaje("archivos/PuntajesTiempo.txt")
    #imprime los objetos en la pantalla con las posiciones dadas anteriormente   
    imprimir_todo(scores,casillas_lado,casillas_alto,pantalla,fondo,area_protegida,zonas_prot,tableta,amenaza,pixeles_casilla,inicio_tablero,pared,pos_paredes,(dimensiones[0]/2-115,75),tiempo,tipografia,font,niv,niv_experto)
    pygame.display.update()
    
    #.........................................................................
    #Bucle principal del nivel, se repite mientras no se pierda o se gane
    while not victoria(amenaza,zonas_prot) and not derrota(tableta,amenaza,contador_tiempo,pos_paredes):

        #Contador tiempo guarda cuanto tiempo paso desde el inicio del nivel
        contador_tiempo = pygame.time.get_ticks() - tinicio - resta
        tableta.tiempo_quieto = pygame.time.get_ticks() - tableta.ultima_jugada
        
        #se definen las variables segun contador_tiempo
        if (contador_tiempo/1000 < 60):
            minutos = 0
            segundos = contador_tiempo/1000
        else:
            if(contador_tiempo/1000 > 3600): #si el juego permanece abierto mas de 60min se inicia el contador horas
                horas = int(contador_tiempo/1000 // 3600)
            else:
                horas = 0
            minutos = int(contador_tiempo/1000 // 60) - (horas*60)
            segundos = int(contador_tiempo/1000 % 60)

        #se le asigna valor a tiempo con las variables minutos y segundos separados por un :, concatenados a 0 cuando sean menores a 10.
        if (minutos < 10 and segundos < 10):
            tiempo = "0" + str(minutos) + ":0" + str(segundos)
        elif (minutos < 10):
            tiempo = "0" + str(minutos) + ":" + str(segundos)
        elif (segundos < 10):
            tiempo = str(minutos) + ":0" + str(segundos)
        if horas>0:
            tiempo = horas+":"+tiempo
    
        # Se fija cuantos virus fueron llevados a las areas seguras  
        amenaza.destruido(zonas_prot,pantalla,pixeles_casilla,inicio_tablero)

        #Se cambia la tablet segun la bateria restante
        tableta.cambiar_skin(pixeles_casilla)
                   
        #obtiene la posXeY del mouse para el uso de los botones
        mouse = pygame.mouse.get_pos() 
        
        #Renueva las posiciones de los objetos dependiendo de la tecla que se presione
        for event in pygame.event.get():
            #Se cierra el programa si se presiona la tecla para cerrar
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
                   
            #se guarda la posicion del mouse si se se apreto
            if event.type == pygame.MOUSEBUTTONDOWN: 
                mouse_pos = event.pos

                #Si se preciona el boton de opciones el juego se pausa y se puede acceder a varias opciones
                if botonP.collidepoint(mouse_pos):
                    devolucion_pausa = en_pausa(pantalla,estado_sonido)
                    estado_sonido = devolucion_pausa[1]
                    if devolucion_pausa[0] == "i":
                        return ["v",1,1000,tableta.bateria,estado_sonido]
                    else:
                        resta = resta + devolucion_pausa[0]
                    tableta.ultima_jugada = tableta.ultima_jugada + devolucion_pausa[0]
                                    
                   
            #Detectecta la tecla presionada y procede adecuadamente
            if event.type == pygame.KEYDOWN:
                # Tanto las flechitas como WASD mueven la tableta (si es que se puede mover)
                if event.key == pygame.K_RIGHT or event.key == pygame.K_d:
                    mover(estado_sonido,tableta,amenaza,(tableta.posicion[0]+1,tableta.posicion[1]),(tableta.posicion[0]+2,tableta.posicion[1]),pos_paredes)
                elif event.key == pygame.K_LEFT or event.key == pygame.K_a:
                    mover(estado_sonido,tableta,amenaza,(tableta.posicion[0]-1,tableta.posicion[1]),(tableta.posicion[0]-2,tableta.posicion[1]),pos_paredes)
                elif event.key == pygame.K_UP or event.key == pygame.K_w:
                    mover(estado_sonido,tableta,amenaza,(tableta.posicion[0],tableta.posicion[1]-1),(tableta.posicion[0],tableta.posicion[1]-2),pos_paredes)
                elif event.key == pygame.K_DOWN or event.key == pygame.K_s:
                    mover(estado_sonido,tableta,amenaza,(tableta.posicion[0],tableta.posicion[1]+1),(tableta.posicion[0],tableta.posicion[1]+2),pos_paredes)
                #R empieza de cero el nivel
                elif event.key == pygame.K_r:
                    return [5,0,1000,tableta.bateria,estado_sonido]
                #X retrocede un paso, tantas veces como se quiera
                elif event.key == pygame.K_x:
                    if len(tableta.jugadas)>1:
                        tableta.ultima_jugada = pygame.time.get_ticks() #Actualiza cuando se hizo el ultimo movimiento
                        tableta.jugadas.pop() #se borra la ultima jugada
                        #Se guarda la jugada anterior en retroceder
                        retroceder = tableta.jugadas.pop()
                        #En base a esta se actualizan las posiciones y contadores
                        tableta.posicion = retroceder[0]
                        amenaza.posicion = retroceder[1][:]
                        amenaza.tipo_virus = dict(retroceder[2])
                        tableta.contador = retroceder[3]
                        tableta.bateria = retroceder[4]
                        tableta.color_final_actual = retroceder[5]
                        #Se vuelve a agregar esta jugada a la lista
                        tableta.jugadas.append(retroceder)
                        
        # Se fija cuantos virus fueron llevados a las areas seguras  
        amenaza.destruido(zonas_prot,pantalla,pixeles_casilla,inicio_tablero)
        
        # vuelve a imprimir todas las imagenes en las posiciones correspondientes
        imprimir_todo(scores,casillas_lado,casillas_alto,pantalla,fondo,area_protegida,zonas_prot,tableta,amenaza,pixeles_casilla,inicio_tablero,pared,pos_paredes,(dimensiones[0]/2-115,75),tiempo,tipografia,font,niv,niv_experto)      
        #Si el mouse esta arriba de un boton, cambia de color
        if botonP.collidepoint(mouse):
            pantalla.blit(botonArriba2,(868,460))
        pygame.display.update()
    #.......Fin.Bucle............................................................................................................................

    # una vez terminado el nivel devuelve si se gano o no, los movimientos y el tiempo     
    if victoria(amenaza,zonas_prot):
        #Animacion de la desintegracion de los virus, salvo en el modo nocturno
        if niv != 3 and niv != 7 and niv != 8:
            amenaza.todos_derrotados(zonas_prot,pantalla,pixeles_casilla,inicio_tablero)
        return [True,tableta.contador,contador_tiempo,tableta.bateria,estado_sonido]
    else:
        return [False,tableta.contador,contador_tiempo,tableta.bateria,estado_sonido]

#funcion que ejecuta la pantalla de pausa
def en_pausa(pantalla,estado_sonido):
    #Inicializacion de variables
    sound = estado_sonido
    mensajes = random_facts()
    hecho = mensajes[0]
    font = pygame.font.Font("BOOKOS.TTF",25)
    pausa_inicio = pygame.time.get_ticks() #tiempo que inicia la pausa
    botonV2 = pygame.Rect(500,360,130,50)#boton para cuando el usuario quiera volver al juego
    botonS = pygame.Rect(700,360,130,50)#boton para cuando quiera salir del juego
    botonI = pygame.Rect(300,360,130,50)#boton para cuando quiera volver al menu
    
    #Se cargan las imagenes
    ipausa = pygame.image.load("imagenes/pantallapausa.jpg") #imagen de pausa
    mensaje_volver = pygame.image.load("imagenes/reanudarT.png")
    mensaje_salir = pygame.image.load("imagenes/salirT.png")
    mensaje_inicio = pygame.image.load("imagenes/inicioT.png")
    tablet_fact = pygame.image.load("imagenes/tabletC.png")
    botonArriba2 = pygame.image.load("imagenes/boton2A.png") #imagen que se imprime cuando el cursor este arriba del boton
    musicae = pygame.image.load("imagenes/musica_encendido.png")
    sonidoe = pygame.image.load("imagenes/sonido_encendido.png")
    musicaa = pygame.image.load("imagenes/musica_apagado.png")
    sonidoa = pygame.image.load("imagenes/sonido_apagado.png")
    musicaArribae = pygame.image.load("imagenes/musica_encendido_pressed.png")
    sonidoArribae = pygame.image.load("imagenes/sonido_encendido_pressed.png")
    musicaArribaa = pygame.image.load("imagenes/musica_apagado_pressed.png")
    sonidoArribaa = pygame.image.load("imagenes/sonido_apagado_pressed.png")
    #Texto correspondiente a la Ronda Final
    texto = font.render("Ronda Final",0,(0,0,0))

    #Inicializacion de las variables de la musica, asignandole imagenes
    if pygame.mixer.music.get_busy():
        musica = musicae
        musicaArriba = musicaArribae
    else:
        musica = musicaa
        musicaArriba = musicaArribaa
    if sound > 0:
        sonido = sonidoe
        sonidoArriba = sonidoArribae
    else:
        sonido = sonidoa
        sonidoArriba = sonidoArribaa

    musica_rect = pygame.Rect(410,200,musica.get_size()[0],musica.get_size()[1])
    sonido_rect = pygame.Rect(610,200,sonido.get_size()[0],sonido.get_size()[1])
    fact = random.choice(hecho)
    while True:
        pantalla.blit(ipausa,(0,0)) #imprime la imagen de pausa
        mouse = pygame.mouse.get_pos()  #obtiene x e y del mouse
        for event in pygame.event.get():
            #Se cierra el programa si se presiona la tecla para cerrar
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
                   
            #se guarda la posicion del mouse si se se apreto
            if event.type == pygame.MOUSEBUTTONDOWN: 
                mouse_pos = event.pos
                #Sale de la pantalla de pausa si se presiona el boton volver al juego
                if botonV2.collidepoint(mouse_pos):
                    return [(pygame.time.get_ticks() - pausa_inicio),sound] #devuelve el tiempo que el juego estuvo en pausa
                if botonI.collidepoint(mouse_pos):
                    return ["i",sound]
                #si la musica esta encendida, se apaga y viceversa. Se asignan las imagenes
                if musica_rect.collidepoint(mouse_pos):
                    if pygame.mixer.music.get_busy():
                        pygame.mixer.music.stop()
                        musica = musicaa
                        musicaArriba = musicaArribaa
                    else:
                        pygame.mixer.music.play(-1)
                        musica = musicae
                        musicaArriba = musicaArribae

                #si el sonido esta encendido, se apaga y viceversa. Se asignan las imagenes        
                if sonido_rect.collidepoint(mouse_pos):
                    sound = sound * -1
                    if sound < 0:
                        sonido = sonidoa
                        sonidoArriba = sonidoArribaa
                    if sound > 0:
                        sonido = sonidoe
                        sonidoArriba = sonidoArribae

                #se cierra el programa si se oprime el boton de salir   
                if botonS.collidepoint(mouse_pos):
                    pygame.quit()
                    sys.exit()
                    
        #imprime los botones y sus textos o imagenes
        pygame.draw.rect(pantalla,(255,255,255),botonV2)
        pantalla.blit(mensaje_volver,(500,360))
        
        pygame.draw.rect(pantalla,(255,0,0),botonS)
        pantalla.blit(mensaje_salir,(700,360))
        
        pygame.draw.rect(pantalla,(255,255,255),botonI)
        pantalla.blit(mensaje_inicio,(300,360))

        pantalla.blit(musica, (410,200))

        pantalla.blit(sonido, (610,200))
        pantalla.blit(texto,(980,598))

        imprimir_fact(fact,pantalla,(500,430),(255,255,255))
        pantalla.blit(tablet_fact,(350,460))
        #si el mouse esta arriba del boton cambia de color
        if botonV2.collidepoint(mouse):
            pantalla.blit(botonArriba2,(500,360))
        elif botonS.collidepoint(mouse):
            pantalla.blit(botonArriba2,(700,360))
        elif botonI.collidepoint(mouse):
            pantalla.blit(botonArriba2,(300,360))
        elif musica_rect.collidepoint(mouse):
            pantalla.blit(musicaArriba,(410,200))
        elif sonido_rect.collidepoint(mouse):
            pantalla.blit(sonidoArriba,(610,200))


        pygame.display.update()
