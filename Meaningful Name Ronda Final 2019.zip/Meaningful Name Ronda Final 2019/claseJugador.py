#Clase de super tablet
"""Equipo: Meaningful Name; Integrantes:
Asteasuain Martina, Garcia Romina y Zentrigen Rocio.
Colegio : Escuela Superior de Comercio "Prudencio Cornejo", Bahia Blanca"""

#..........................................................................
#Importacion de librerias
import pygame
import random
from pygame import *

#.........................................................................
#Clase enemigo da las cualidades que posee super tablet 
class jugador (pygame.sprite.Sprite):

    #Inicializa super tablet
    def __init__(self,tam_casilla,casilla_inicial):
        pygame.sprite.Sprite.__init__(self)
        #Se cargan las distintas imagenes de tablet
        self.imagen0 = pygame.image.load("imagenes/tablet0.png")
        self.imagen0 = pygame.transform.scale(self.imagen0,(tam_casilla,tam_casilla))
        self.imagen1 = pygame.image.load("imagenes/tablet1.png")
        self.imagen1 = pygame.transform.scale(self.imagen1,(tam_casilla,tam_casilla))
        self.imagen2 = pygame.image.load("imagenes/tablet2.png")
        self.imagen2 = pygame.transform.scale(self.imagen2,(tam_casilla,tam_casilla))
        self.imagen = self.imagen0
        self.color_final_actual = (random.choice(range(50,253)),random.choice(range(65,255)),random.choice(range(34,255)))
        self.posicion = casilla_inicial #(x,y)del punto inicial
        self.contador = int(0) #Guarda la cantidad de movimientos de super tablet
        self.obstaculo = [] 
        self.bateria = 7000 #Guarda los amper de la bateria
        self.luz_imagen = pygame.image.load("imagenes/pantallaNegra.png")#carga la pantalla del modo nocturno
        self.amigo_imagen = pygame.image.load("imagenes/amigo.png")
        #La lista jugadas guarda toda la informacion cada ves que super tablet se mueve
        self.jugadas = []
        self.tiempo_quieto = 0 #Este es el tiempo que super tablet no se mueve, se reinicia si se mueve
        self.ultima_jugada = 0 #Es el tiempo en el que se realizo l aultima jugada

        
    #Cambia la imagen de super tablet segun la cantidad de la bateria
    def cambiar_skin(self,tam_casilla):
        if self.bateria > 3851:
            self.imagen = self.imagen0 #imagen bateria llena
        if self.bateria < 3850:
            self.imagen = self.imagen1#imagen bateria medio
        if self.bateria < 1400:
            self.imagen = self.imagen2 #imagen bateria poca


    #Funcion que devuelve si super tablet se puede mover o no
    def puede_mover(self,pos_a_mover,pos_sigue,paredes,virus):
        #Se fija si delante de super tablet hay una pared o 2 virus seguidos
        if (pos_a_mover in virus and pos_sigue in virus ):
            self.bateria -= 200
        if(pos_a_mover in paredes or pos_a_mover in self.obstaculo or (pos_a_mover in virus and pos_sigue in virus )):
            return False
        else:
            return True

    #Funcion que devuelve si adelante de super tablet hay un virus o no
    def mover_virus(self,pos_a_mover,amenazas):
        if(pos_a_mover in amenazas):
            return True
        else:
            return False

    #Funcion que devuelve si delante de super tablet hay un virus y una pared
    def virus_pared(self,pos_a_mover,pos_sigue,virus,pared):
        if(pos_a_mover in virus and pos_sigue in pared):
            return True
        else:
            return False
        
