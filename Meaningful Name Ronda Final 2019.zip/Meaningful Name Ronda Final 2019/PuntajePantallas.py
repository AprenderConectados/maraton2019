#Muestra una pantalla si ganaste o perdiste con los puntos obtenidos
"""Equipo: Meaningful Name; Integrantes:
Asteasuain Martina, Garcia Romina y Zentrigen Rocio.
Colegio : Escuela Superior de Comercio "Prudencio Cornejo", Bahia Blanca"""

#.........................................................................
#Declaracion de librerias
import pygame
import time
import sys
from pygame import *
from pantallaPosiciones import *

#.........................................................................
# Funcion que muestra los anuncios de ganaste o perdiste
def imprimir_pantalla(nivel,pantalla,resultados,cantvirus,niveles):
    #Declaracion de variables
    #La lista resultados contiene los datos obtenidos al finalizar el nivel
    dimensiones = (1152,648)
    clock = pygame.time.Clock()
    resultadofinal = resultados[0] #Ganaste o Perdiste
    movimientos = resultados[1] # Movimientos realizados
    tiempo = resultados[2]/1000 # Tiempo en el que se hizo la partida
    bateria = resultados[3] # Bateria sobrante
    #Formula del puntaje
    if tiempo < 1:
        tiempo = 1
    try:
        puntos = resultados[5]
    except:
        puntos = bateria/tiempo
    
    contador = 600
    nombre = ""
    #Se inicializan las tipografias
    font = pygame.font.Font("BOOKOS.TTF", 50)
    font2 = pygame.font.Font("BOOKOS.TTF", 25)
    fondo = pygame.image.load("imagenes/monitor.jpg")
    fondo = pygame.transform.scale(fondo,dimensiones)
    texto = font2.render("Ronda Final",0,(0,0,0))

    if puntos < 0:
        puntos = 0
    #El 5 representa que se quiere reiniciar el nivel por lo que ninguna pantalla debe ser mostrada
    if resultadofinal == 5:
        return False
    #La v representa que see apreto el boton volver por lo que debe volver al menu
    if resultadofinal == "v":
        return True
    
    #.........................................................................................
    # imprime pantalla ganaste el nivel si ganaste       
    if  resultadofinal == True:
        inicio = pygame.time.get_ticks() #cantidad de segundos desde la inicializacion del juego
        en_pantalla = True #booleano sobre si se imprime la pantalla del juego
        iganaste = pygame.image.load("imagenes/pantallaganaste.jpg")
        while en_pantalla:
            #Durante 5 segundos imprime la foto ganaste
            contador = 5000 - (pygame.time.get_ticks() - inicio)
            timer = font.render(str(contador/1000),0,(0,0,0))
            pantalla.blit(iganaste,(0,0))
            pantalla.blit(timer,(550,405))
            pantalla.blit(texto,(980,598))
            #si pasan 15seg de tablet inactivo no se imprime la pantalla
            if contador < 100:
                en_pantalla = False
            pygame.display.update() #actualizacion de la pantalla
        #Llama a la funcion de escribir tu nombre
        nombre = LeerNombre(pantalla,puntos)
        #Dependiendo del modo guarda el puntaje en la tabla correspondiente
        if nivel == 1:
            GuardarPuntaje(nombre,puntos,"archivos/Puntajes.txt")
            tablaPosiciones(pantalla,0,False)
        if nivel == 3:
            GuardarPuntaje(nombre,puntos,"archivos/PuntajesLuz.txt")
            tablaPosiciones(pantalla,2,False)

    #.........................................................................        
    #imprime pantalla perdiste el nivel si perdiste
    else:
        #si se quedo sin bateria imprime la imagen de perdiste
        if bateria <11:
            pos = (855,340)
            if nivel ==2: #si el nivel es el experto, se imprime la pantalla que dice que van a aparecer las posiciones
                imagenperdiste = pygame.image.load("imagenes/pantallaperdiste2.jpg")
            #Prepara las cosas a imprimir
            else: #en los demas, expresa que se va a reiniciar el nivel
                imagenperdiste = pygame.image.load("imagenes/pantallaperdiste.jpg")
        else:
            pos = (885,355)
            #si la tablet estuvo inactiva por 15seg imprime la imagen sobre ello
            imagenperdiste = pygame.image.load("imagenes/pantallainactiva.jpg")
        contador = 250
        inicio = pygame.time.get_ticks()

        #Imprime las cosas por 5 segundos
        while True:
            contador = 5000 - (pygame.time.get_ticks() - inicio)
            
            for event in pygame.event.get(): 
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
            #imprime los segundos que faltan
            falta = font.render(str(contador/1000),0,(0,0,0))
            if contador <= 100:
                if nivel == 2:
                    break
                return False
            #Imprime la pantalla
            pantalla.blit(imagenperdiste,(0,0))
            pantalla.blit(falta,pos)
            pantalla.blit(texto,(980,598))
            pygame.display.update()
        #Si es el modo experto guarda el puntaje en la tabla correspondiente    
        if nivel == 2 and bateria < 11:
            nombre = LeerNombre(pantalla,niveles)
            GuardarPuntaje(nombre,niveles,"archivos/PuntajesTiempo.txt")
            tablaPosiciones(pantalla,1,False)


        
