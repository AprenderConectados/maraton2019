#Funciones sobre el puntaje de los niveles
# -*- coding: cp1252 -*-
"""Equipo: Meaningful Name; Integrantes:
Asteasuain Martina, Garcia Romina y Zentrigen Rocio.
Colegio : Escuela Superior de Comercio "Prudencio Cornejo", Bahia Blanca"""

#..........................................................................
#Importacion de librerias
import pygame
import sys
from pygame import *

#.....................................................................................
#LeerNombre genera la pantalla en la que el jugador ingresa su nombre y lo guarda
def LeerNombre(pantalla,puntos):
    #Se cargan las fuentes e imagenes
    font = pygame.font.Font("BOOKOS.TTF", 60)
    #font2 = pygame.font.Font("BOOKOS.TTF", 85)
    font3 = pygame.font.Font("BOOKOS.TTF", 25)
    fondo = pygame.image.load("imagenes/ingresarN.jpg")
    puntaje = font.render("Puntaje:" + str(puntos),0,(255,255,255))
    texto = font3.render("Ronda Final",0,(0,0,0))
    #Declaracion de variables
    texto1 = "Ingrese su nombre:"
    nombre = ""
    terminar = False
    botonS = pygame.Rect(880,500,130,50) #boton para cuando el usuario quiera salir del juego
    botonArriba2 = pygame.image.load("imagenes/boton2A.png") #boton salir
    mensaje_salir = pygame.image.load("imagenes/salirT.png")

    #Bucle principal
    while terminar == False:
        
        mouse = pygame.mouse.get_pos() #obtiene la posXeY del mouse 
            
        for event in pygame.event.get():
            #Se cierra el programa si se preciona la tecla para cerrar
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN: #de esta manera se guarda la posicion del mouse para saber si esta apretando algun boton
                mouse_pos = event.pos
                
                if botonS.collidepoint(mouse_pos): #sirve para salir del juego cuando el usuario selecciona el boton indicado
                  pygame.quit()
                  sys.exit()
                
            #Detectecta la tecla presionada y procede adecuadamente
            if event.type == pygame.KEYDOWN:
                
                #Con la tecla "Entrar" se acepta el nombre
                if event.key == pygame.K_RETURN:
                    terminar = True
                    
                #Con la tecla de borrar "retroceso" se borra el ultimo caracter
                elif event.key == pygame.K_BACKSPACE:
                    if len(nombre)>0:
                        nombre = nombre[:-1]
                        
                #Con cualquiera de las demas teclas oprimidas se agregan al nombre     
                else:
                    if len(nombre)<10:
                        try:
                            nombre= nombre + (chr(event.key))
                        except:
                            pass
                    
        #Se imprime el nombre a medida que se escribe en la pantalla                     
        texto_nombre = font.render(nombre,0,(0,0,0))
        pantalla.blit(fondo,(0,0))
        pantalla.blit(texto_nombre,(285,300))
        pantalla.blit(puntaje,(380,459))
        pygame.draw.rect(pantalla,(255,0,0),botonS)
        pantalla.blit(mensaje_salir,(880,500))
        pantalla.blit(texto,(980,598))
        #Si el mouse esta arriba del boton cambia el color
        if botonS.collidepoint(mouse):
            pantalla.blit(botonArriba2,(880,500))
        pygame.display.update()

    return nombre 

#GuardarPuntaje guarda el nombre del jugador y el puntaje en un archivo Puntajes
def GuardarPuntaje(nombre,puntos,documento):
    #Se abre el archivo para escribir y se agrega el nombre y puntaje dados
    archivo = open(documento, "a")
    archivo.write(str(puntos)+"_"+nombre+":")
    archivo.close()

#Lee el archivo de puntajes y devuelve una variable con el contenido
def LeerPuntaje(documento):
    #Declaracion de variables
    orden = []
    relacion = []
    todo = "" #Contenido del archivo
    lineas = "" #Contenido separado por mensajes
    altura = 200
    font = pygame.font.SysFont("Courier New", 35)
    # Se abre el archivo para leer y se guarda el texto en una variable
    archivo = open(documento, "r")
    todo = archivo.read().splitlines()
    #Se separa el texto en lineas que contienen nombre y puntaje
    lineas = todo[1].split(":")
    for i in range(0,len(lineas)-1):
        #Se separa el nombre del puntaje guardando este ultimo en una lista para ordenarlo
        lineas[i] = lineas[i].split("_")
        orden.append(lineas[i][0]) #Lista con solo los puntajes
        relacion.append(lineas[i][0])
        relacion.append(lineas[i][1]) #Lista que relaciona los puntajes con los nombres
    #Se ordena la lista con los puntajes
    orden.sort(key=int, reverse=True)
    return [orden,relacion,lineas,todo]

#imprimir_puntaje imprime la tabla de puntajes con la informacion del archivo Puntajes
def imprimir_puntaje(pantalla,puntajes,niv):
    #Declaracion de variables
    orden = puntajes[0][:]
    relacion = puntajes[1][:]
    lineas = puntajes[2][:]
    color = (255,255,255)
    #Si se imprime en la pantalla posiciones de inicio
    if niv == 0:
        altura = 260
        posx = 290
        pos_titulo = (400,168)
        suma = 50
        puntos = "...."
        tam = 45
    #Si se imprime mientras se juega el nivel
    else:
        altura = 170
        posx = 80
        pos_titulo = (110,150)
        suma = 20
        puntos = "."
        tam = 20
        #Si es el modo nocturno se imprime en verde
        if niv == 3 or niv == 7 or niv == 8:
            color = (0,255,0)
    todo = puntajes[3][:]
    font = pygame.font.SysFont("Courier New", tam)
    titulo = font.render(todo[0],0,color)
    #Se imprime el modo de juego del puntaje
    pantalla.blit(titulo,pos_titulo)
    #Se imprimen los 5 puntajes mas altos
    for i in range(0,5):
        if i>=len(lineas):
            break
        try:
            #Busca en la lista cada nombre del puntaje en orden
            linea = [orden[i],0]
            linea[1] = relacion[relacion.index(orden[i])+1]
            espacio = 10 - len(linea[1])
            if i == 9:
                espacio = espacio - 1                
            ceros = 4 - len(linea[0])
            #Hace el formato en el que va a ser impresa cada linea
            texto = str(i+1)+" "+linea[1]+"."*espacio+puntos+"0"*ceros+linea[0]
            mensaje = font.render(texto,0,color)
            #Imprime en la pantalla
            pantalla.blit(mensaje,(posx,altura))
            altura = altura + suma
            #borra el nombre y puntaje ya impresos
            del relacion[relacion.index(orden[i])]
            del relacion[relacion.index(orden[i]+1)]
        except:
            pass

        
