#Cambia las posiciones de los objetos
"""Equipo: Meaningful Name; Integrantes:
Asteasuain Martina, Garcia Romina y Zentrigen Rocio.
Colegio : Escuela Superior de Comercio "Prudencio Cornejo", Bahia Blanca"""

#..............................................................................
#Definicion de librerias
import pygame
import random
from pygame import*

#..............................................................................
#Funcion mover cambia las listas de posiciones dependiendo de la tecla recibida
def mover(estado_sonido,jugador,virus,posicion,posicion_sgte,lista_pared):
    jugada = [0,0,0,0,0,0] #Guarda la jugada realizada
    color = 0 #Guarda el color de fondo de ronda final

    if jugador.puede_mover(posicion,posicion_sgte,lista_pared,virus.posicion)and not jugador.virus_pared(posicion,posicion_sgte,virus.posicion,lista_pared):
        if jugador.mover_virus(posicion,virus.posicion):
            #Mueve la amenaza si la tiene delante
            virus.posicion.remove(posicion)
            foto = virus.tipo_virus[posicion]
            virus.tipo_virus.pop(posicion)
            virus.posicion.append(posicion_sgte)
            virus.tipo_virus[posicion_sgte] = foto
            jugador.bateria = jugador.bateria - 5 #resta la bateria
        # La tableta se mueve siempre que no haya una pared o dos amenazas delante
        jugador.posicion=posicion
        effect = pygame.mixer.Sound('musica/tabletSeMueve.wav')
        if estado_sonido > 0 :
            effect.play() #Hace el ruido de mover la tablet si el sonido esta encendido
        #Se genera un color random, entre un rango para que quede acorde a la estetica
        color = (random.choice(range(50,253)),random.choice(range(65,255)),random.choice(range(34,255)))
        #Si el color generado es igual al anterior se genera otro
        while (color == jugador.color_final_actual):
            color = (random.choice(range(50,253)),random.choice(range(65,255)),random.choice(range(34,255)))
        jugador.color_final_actual = color
        jugador.contador = jugador.contador + 1 #aumenta la cant de movimientos
        jugador.bateria = jugador.bateria - 10 #resta la bateria
        jugador.ultima_jugada = pygame.time.get_ticks() #Actualiza cuando se hizo el ultimo movimiento
        #Guarda las nuevas posiciones en la lista de jugadas
        jugada[0]=jugador.posicion #guarda la posicion de la tablet
        jugada[1]=virus.posicion[:] #guarda las posiciones de los virus
        jugada[2]=dict(virus.tipo_virus) #guarda los tipos de virus en cada posicion
        jugada[3]=jugador.contador #guarda la cantidad de movimientos
        jugada[4]=jugador.bateria #guarda el nivel de la bateria
        jugada[5]=jugador.color_final_actual #guarda el color de fondo de Ronda Final
        jugador.jugadas.append(jugada)
        
