#Imprime la tabla de posiciones
"""Equipo: Meaningful Name; Integrantes:
Asteasuain Martina, Garcia Romina y Zentrigen Rocio.
Colegio : Escuela Superior de Comercio "Prudencio Cornejo", Bahia Blanca"""

#............................................................................
#se importan las librerias necesarias para el desarrollo del programa
import pygame
import sys
from TablaPuntaje import *
from pygame.locals import *

#.............................................................................
def tablaPosiciones(ventana,hoja,menu): #funcion utilizada para ejecutar la pantalla con el Top 15 mejores puntuaciones del juego
    
    inicio = True #variable para determinar la ejecucion del programa
    fondo = pygame.image.load("imagenes/posicionesI.jpg")
    estrellas = pygame.image.load("imagenes/estrellas.png")
    font = pygame.font.Font("BOOKOS.TTF",25)
    texto = font.render("Ronda Final",0,(0,0,0))
    
    botonS = pygame.Rect(920,542,130,50) #objeto-boton para cuando el usuario quiera salir del juego
    botonV = pygame.Rect(920,488,130,50) #obtejo-boton para volver a la pantalla inicial
    botonF = pygame.Rect(975,262,44,70) #flecha para cuando el usuario desea pasar a otra tabla 
    botonArriba2 = pygame.image.load("imagenes/boton2A.png") #imagen que se imprimira cuando el mouse este arriba de algun boton
    
    mensaje_salir = pygame.image.load("imagenes/salirT.png") #imagen que corresponde al texto del boton salir
    mensaje_volver = pygame.image.load("imagenes/volverT.png") #imagen que corresponde al texto del boton volver al inicio
    ibotonF1 = pygame.image.load("imagenes/flecha.png") #Imagen de boton flecha
    ibotonF1 = pygame.transform.scale(ibotonF1,(60,100))
    ibotonF2 = pygame.image.load("imagenes/flecha1.png")#imagen de boton flecha presionado
    ibotonF2 = pygame.transform.scale(ibotonF2,(60,100))
    ibotonF = ibotonF1
    
    #bucle principal de la pantalla de las tablas de posiciones
    while inicio:
        
        ventana.blit(fondo,(0,0))
        ventana.blit(estrellas,(50,50))

        mouse = pygame.mouse.get_pos() #obtiene el x e y del mouse

        for event in pygame.event.get():
            if event.type == QUIT: #cuando quiera cerrar la ventana
                pygame.quit()
                sys.exit()
                
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = event.pos #otra pos x e y del mouse para cuando quiera apretar el boton de salir/volver

                if botonS.collidepoint(mouse_pos): #para cerrar el juego cuando seleccione el boton correspondiente
                    pygame.quit() 
                    sys.exit()

                if botonV.collidepoint(mouse_pos):#vuelve al menu si se presiona
                    return "volver"
                
                if menu == True:#La flecha aparece solo si se accede desde el menu
                    if botonF.collidepoint(mouse_pos):#cambia de tabla si se presiona la flecha
                        if hoja == 2:
                            hoja = 0
                        else:
                            hoja = hoja+1

        #hoja cambia la tabla de los modo de juego abriendolo desde un archivo
        if hoja == 0:
            documento = "archivos/Puntajes.txt" #modo clasico
        if hoja == 1:
            documento ="archivos/PuntajesTiempo.txt" #modo experto
        if hoja == 2:
            documento ="archivos/PuntajesLuz.txt" #modo nocturno
                    
        #las siguientes lineas de codigo corresponden a la impresion de los botones con su respectiva imagen-texto
        pygame.draw.rect(ventana,(255,255,255),botonV)
        ventana.blit(mensaje_volver,(920,488))
        ventana.blit(texto,(980,598))
        pygame.draw.rect(ventana,(255,0,0),botonS)
        ventana.blit(mensaje_salir,(920,542))
        #Imprime la flecha si se accede desde el menu
        if menu == True:
            ventana.blit(ibotonF,(970,250))
    
        #las sig. lineas hacen referencia a la impresion de la imagen arriba de los botones para dar la impresion de seleccion de los mismos
        if botonS.collidepoint(mouse):
            ventana.blit(botonArriba2,(920,542))
        elif botonV.collidepoint(mouse):
            ventana.blit(botonArriba2,(920,488))
        elif botonF.collidepoint(mouse):
                ibotonF = ibotonF2
        else:
            ibotonF = ibotonF1
        scores = LeerPuntaje(documento)
        imprimir_puntaje(ventana,scores,0)

        pygame.display.update() #hace el update de la pantalla



        

                    

            
        

    
