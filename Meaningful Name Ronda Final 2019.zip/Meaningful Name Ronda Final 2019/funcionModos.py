#Llama a las funciones requeridas dependiendo de que se aprete en el menu
"""Equipo: Meaningful Name; Integrantes:
Asteasuain Martina, Garcia Romina y Zentrigen Rocio.
Colegio : Escuela Superior de Comercio "Prudencio Cornejo", Bahia Blanca"""

#..........................................................................
#Importacion de librerias
import pygame
from pygame.locals import *
import sys
import random
from pantallaInicio import ventanaInicial
from PuntajePantallas import imprimir_pantalla
from pantallaPosiciones import *
from pantallaModoJuegos import *
from nivel import nivel

#.................................................................................
#Funciones
#Funcion que imprime la pantalla para elejir el modo de juego
def elejir(pantalla):
    rta = pantallaModoDeJuego(pantalla)
    return rta

#funcion para ejecutar el nivel clasico
def nivel_clasico(pantalla,estado_sonido,progreso):
    #inicializacion de variables
    inicio_tablero=(300,150)
    puntaje = progreso[2]
    etapa = progreso[1] #Etapa guarda los niveles que se pasaron
    evento = [5,0,0,0,0] #datos que devuelve el nivel [resultado,movimientos,tiempo,bateria]
    accion = False #devuelve la pantalla del puntaje
    
    #Pregunta si se desea continuar con el progreso o empezar de 0
    if etapa > 0:
        etapa = pantalla_continuar(pantalla,etapa)
    #Hace el nivel 1    
    while etapa < 1:
        evento = nivel(1,5,7000,1,pantalla,inicio_tablero,estado_sonido)
        estado_sonido = evento[4]
        #Si se gana el nivel, pasa al sgte y se guarda el puntaje
        if evento[0] == True:
            puntaje = evento[3]/(evento[2]/1000)
            etapa = etapa + 1
            break
        #Si se apreta la tecla de volver inicio, sale de la funcion
        if evento[0] == "v":
            return [estado_sonido,etapa,puntaje]
        #Si se pierde imprime la pantalla y reinicia
        accion = imprimir_pantalla(1,pantalla,evento,5,0)
        
    #Hace el nivel 2
    while  etapa < 2:
        evento = nivel(5,5,7000,2,pantalla,inicio_tablero,estado_sonido)
        estado_sonido = evento[4]
        #Si se gana el nivel pasa al sgte y se guarda el puntaje
        if evento[0] == True:
            puntaje = puntaje + evento[3]/(evento[2]/1000)
            etapa = etapa + 1
            break
        #Si se vuelve al inicio de sale de la funcion
        if evento[0] == "v":
            return [estado_sonido,etapa,puntaje]
        #Si se pierde imprime la pantalla y reinicia
        accion = imprimir_pantalla(1,pantalla,evento,5,0)

    #Hace el nivel 3
    while  etapa < 3:
        evento = nivel(6,5,7000,3,pantalla,inicio_tablero,estado_sonido)
        estado_sonido = evento[4]
        #Si se gana se pasa a imprimir la pantalla de ganar y se guarda el puntaje
        if evento[0] == True:
            puntaje = puntaje + evento[3]/(evento[2]/1000)
            break
        #Si se vuelve a inicio se sale de la funcion
        if evento[0] == "v":
            return [estado_sonido,etapa,puntaje]
        #Si se pierde imprime la pantalla y reinicia
        accion = imprimir_pantalla(1,pantalla,evento,5,0)

    #Se suman los puntajes y se pasan a la funcion de imprimir pantalla
    evento.append(puntaje)
    #Se imprime la pantalla de ganar y actualiza la tabla de puntuaciones
    accion = imprimir_pantalla(1,pantalla,evento,5,0)
    return [estado_sonido,0,0]

#funcion para ejecutar el nivel experto
def nivel_experto(pantalla,progreso,estado_sonido):
    #Inicializacion de variables
    inicio_tablero=(300,150) 
    evento = [5,0,0,0] #datos que devuelve el nivel [resultado,movimientos,tiempo,bateria]
    accion = False  #devuelve la pantalla del puntaje
    bateria = progreso[1]
    gano = progreso[0] #niveles ganados, si saliste del juego sin perder, se guarda tu progreso

    #Pregunta si se deseaa continuar con el progreso o empezar de 0
    if gano != 0:
        gano = pantalla_continuar(pantalla,gano-1) + 1
    if gano == 0:
        bateria = 7000
        while evento[0] == 5: #se repite si se apreta r

            #primero ejecuta el tercer nivel del clasico
            evento = nivel(4,5,bateria,gano,pantalla,inicio_tablero,estado_sonido)
            estado_sonido = evento[4]

            if evento[0] == False and evento[3]>=10:
                #Si perdes por inactividad reinicia(pero sin bateria termina el modo)
                accion = imprimir_pantalla(2,pantalla,evento,5,gano)
                evento[0] = 5
        bateria = evento[3] #se guarda cuanta bateria se gasto

        #despues se generan niveles aleatorios si se gano el nivel anterior
        if evento[0] == True:
            gano = 1 #si se pasa el nivel se incrementa la cantidad de niveles ganados

    while (evento[0]!= False) and (evento[0]!= "v"):
        resultado = 5
        #Mientras el nivel devuelva 5 (resultado) se va a reiniciar el nivel
        while resultado == 5: 

            evento = nivel(2,4,bateria,gano,pantalla,inicio_tablero,estado_sonido)
            estado_sonido = evento[4]

            #Si perdes por inactividad reinicia(pero sin bateria termina el modo)
            if evento[0] == False and evento[3]> 9:
                accion = imprimir_pantalla(2,pantalla,evento,5,gano)
                evento[0] = 5

            if evento[0] == "v": #si se presiona volver se va al menu
                bateria = evento[3]
                return [gano,bateria,estado_sonido]
            resultado= evento[0]
            
        if resultado == True:
            gano = gano + 1 #si se pasa el nivel se incrementa la cantidad de niveles ganados
        bateria = evento [3]
    #imprime la pantalla cuando no hay mas bateria
    accion = imprimir_pantalla(2,pantalla,evento,5,gano)
    return [0,7000,estado_sonido]

#Ejecuta el nivel nocturno
def nivel_nocturno(pantalla,estado_sonido,progreso):
    #inicializacion de variables
    inicio_tablero=(300,150)
    puntaje = progreso[2]
    etapa = progreso[1] #Etapa guarda los niveles que se pasaron
    evento = [5,0,0,0,0] #datos que devuelve el nivel [resultado,movimientos,tiempo,bateria]
    accion = False #devuelve la pantalla del puntaje
    
    #Pregunta si se desea continuar con el progreso o empezar de 0
    if etapa > 0:
        etapa = pantalla_continuar(pantalla,etapa)
    #Hace el nivel 1    
    while etapa < 1:
        evento = nivel(3,5,7000,1,pantalla,inicio_tablero,estado_sonido)
        estado_sonido = evento[4]
        #Si se gana el nivel, pasa al sgte y se guarda el puntaje
        if evento[0] == True:
            puntaje = evento[3]/(evento[2]/1000)
            etapa = etapa + 1
            break
        #Si se apreta la tecla de volver inicio, sale de la funcion
        if evento[0] == "v":
            return [estado_sonido,etapa,puntaje]
        #Si se pierde imprime la pantalla y reinicia
        accion = imprimir_pantalla(3,pantalla,evento,5,0)
        
    #Hace el nivel 2
    while  etapa < 2:
        evento = nivel(7,5,7000,2,pantalla,inicio_tablero,estado_sonido)
        estado_sonido = evento[4]
        #Si se gana el nivel pasa al sgte y se guarda el puntaje
        if evento[0] == True:
            puntaje = puntaje + evento[3]/(evento[2]/1000)
            etapa = etapa + 1
            break
        #Si se vuelve al inicio de sale de la funcion
        if evento[0] == "v":
            return [estado_sonido,etapa,puntaje]
        #Si se pierde imprime la pantalla y reinicia
        accion = imprimir_pantalla(3,pantalla,evento,5,0)

    #Hace el nivel 3
    while  etapa < 3:
        evento = nivel(8,5,7000,3,pantalla,inicio_tablero,estado_sonido)
        estado_sonido = evento[4]
        #Si se gana se pasa a imprimir la pantalla de ganar y se guarda el puntaje
        if evento[0] == True:
            puntaje = puntaje + evento[3]/(evento[2]/1000)
            break
        #Si se vuelve a inicio se sale de la funcion
        if evento[0] == "v":
            return [estado_sonido,etapa,puntaje]
        #Si se pierde imprime la pantalla y reinicia
        accion = imprimir_pantalla(3,pantalla,evento,5,0)

    #Se suman los puntajes y se pasan a la funcion de imprimir pantalla
    evento.append(puntaje)
    #Se imprime la pantalla de ganar y actualiza la tabla de puntuaciones
    accion = imprimir_pantalla(3,pantalla,evento,5,0)
    return [estado_sonido,0,0]


#Pantalla que pregunta si se desea continuar el modo experto o empezar de cero
def pantalla_continuar(pantalla,nivel):
    #Inicializacion de fuentes e imagenes
    fondo = pygame.image.load("imagenes/monitorC.jpg")
    font = pygame.font.Font("BOOKOS.TTF", 50)
    font2 = pygame.font.Font("BOOKOS.TTF", 25)
    texto_nivel = font.render(str(nivel+1),0,(255,255,255)) #Imprime el nivel por el que ibas
    botonS = pygame.Rect(297,432,130,50) #objeto-boton para cuando el usuario quiera continuar
    botonN = pygame.Rect(724,432,130,50) #obtejo-boton para cuando el usuario quiera reiniciar
    mensaje_si = pygame.image.load("imagenes/siT.png") #imagen que corresponde al texto del boton si
    mensaje_no = pygame.image.load("imagenes/noT.png") #imagen que corresponde al texto del boton no
    botonArriba2 = pygame.image.load("imagenes/boton2A.png") #imagen que se imprimira cuando el mouse este arriba de algun boton
    texto = font2.render(("Ronda Final"),0,(0,0,0))#Imprime Ronda Final
    
    while True:
        mouse = pygame.mouse.get_pos()#Guarda la posicion del mouse
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            #Si se clickea el mouse detecta su posicion        
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = event.pos 

                if botonS.collidepoint(mouse_pos): #Continua por el nivel que se habia dejado
                    return nivel

                if botonN.collidepoint(mouse_pos): #Empieza el modo experto desde el principio
                    return -1

        #Imprime todas las imagenes
        pantalla.blit(fondo,(0,0))
        pantalla.blit(texto_nivel,(800,285))
        pygame.draw.rect(pantalla,(255,0,0),botonN)
        pygame.draw.rect(pantalla,(0,255,0),botonS)
        pantalla.blit(mensaje_si,(297,432))
        pantalla.blit(mensaje_no,(724,432))
        pantalla.blit(texto,(980,598))
        
        #Si el mouse pasa sobre un boton cambia de color
        if botonS.collidepoint(mouse):
            pantalla.blit(botonArriba2,(297,432))
        elif botonN.collidepoint(mouse):
            pantalla.blit(botonArriba2,(724,432))
        pygame.display.flip()

#Imprime las tablas de puntajes de los modos
def tablas_puntaje(pantalla):
    tablaPosiciones(pantalla,0,True)

#Ejecuta las instrucciones
def tutorial(pantalla):
    #Definicion de variables y objetos
    botonS = pygame.Rect(600,542,130,50) #objeto-boton para cuando el usuario quiera salir del juego
    botonV = pygame.Rect(420,542,130,50) #obtejo-boton para volver a la pantalla inicial
    mensaje_salir = pygame.image.load("imagenes/salirT.png") #imagen que corresponde al texto del boton salir
    mensaje_volver = pygame.image.load("imagenes/volverT.png") #imagen que corresponde al texto del boton volver al inicio
    botonArriba2 = pygame.image.load("imagenes/boton2A.png") #imagen que se imprimira cuando el mouse este arriba de algun boton
    fondo_tuto = pygame.image.load("imagenes/pantallaInstruc.jpg")
    imagen1_tutorial = pygame.image.load("imagenes/instruc2.jpg")#Carga la imagen de fondo
    imagen2_tutorial = pygame.image.load("imagenes/instruc1.jpg")#Carga la 2da imagen de fondo
    flecha = pygame.image.load("imagenes/flecha.png") #Carga la flecha para imprimir las diferentes imagenes
    flecha = pygame.transform.scale(flecha,(60,100))
    flecha_arriba = pygame.image.load("imagenes/flecha1.png") #Imagen de la flecha cuando el cursor este arriba
    flecha_arriba = pygame.transform.scale(flecha_arriba,(60,100))
    font = pygame.font.Font("BOOKOS.TTF",25)
    texto = font.render(("Ronda Final"),0,(0,0,0))#Texto de Ronda Final
    cursor = pygame.image.load("imagenes/flechas.png") #imagen de demostracion para ver la info de los virus
    pos_cursor = [(920,175),(920,304),(920,424),(920,550)] #Lista con las posiciones en las que puede aparecer la flecha
    poscX = 0
    poscY = 0
    contador = 0
    #Genera los rectangulos arriba de la imagen de los virus para que aparezcan sus definiciones
    ransomware = pygame.Rect(940,67,134,110)
    virus = pygame.Rect(940,205,134,100)
    incognito = pygame.Rect(940,317,134,120)
    troyano = pygame.Rect(940,448,134,138)
    
    #Genera el rect para la flecha encargada de imprimir las pantallas
    b_flecha = pygame.Rect(850,470,70,90)

    #Variable que se encarga de cambiar la pantalla de instrucciones
    hoja1 = 0
    
    #Importa las imagenes de los textos informativos
    iransomware = pygame.image.load("imagenes/textoransomware.png")
    ivirus = pygame.image.load("imagenes/textovirus.png")
    itroyano = pygame.image.load("imagenes/textotroyano.png")
    iincognito = pygame.image.load("imagenes/textoincognito.png")
    
    pygame.display.flip()
    
    while True:
        pantalla.blit(fondo_tuto,(0,0))
        contador = contador + 1
        mouse = pygame.mouse.get_pos()#Guarda la posicion del mouse
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            #Si se clickea el mouse detecta su posicion        
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = event.pos 

                if botonS.collidepoint(mouse_pos): #cierra el juego cuando seleccionas el boton de salir
                    pygame.quit()
                    sys.exit()

                if botonV.collidepoint(mouse_pos): #vuelve al menu si se presiona el boton volver
                    return "volver"
                if b_flecha.collidepoint(mouse_pos): #se usa para cambiar la pantalla de instrucciones
                    if hoja1 == 1:
                        hoja1 = 0
                    else:
                        hoja1 = hoja1+1
                        
        #estos dos if corresponden a la impresion segun numero de hoja
        if hoja1 == 0:
            pantalla.blit(imagen1_tutorial,(221,40))
        if hoja1 == 1:
            pantalla.blit(imagen2_tutorial,(221,40))

        #Imprime las imagenes, rectangulos y botones
        pantalla.blit(flecha,(850,470))
        pygame.draw.rect(pantalla,(255,255,255),botonV)
        pantalla.blit(mensaje_volver,(420,542))
        pygame.draw.rect(pantalla,(255,0,0),botonS)
        pantalla.blit(mensaje_salir,(600,542))
        pantalla.blit(texto,(980,598))
        #Cada un tiempo empieza la animacion del cursor sobre los virus
        if contador % 180 == 0:
            lugar = random.choice(pos_cursor)
            poscX = lugar[0]
            poscY = lugar[1]
        #Si se inicio la animacion la imagen se va imprimiendo en diferentes puntos para simular animacion
        if poscX> 0 and poscX < 1010:
            poscX = poscX + 2
            poscY = poscY - 1
            pantalla.blit(cursor,(poscX,poscY))
        else:
            poscX = -1
        #Si el mouse pasa sobre un boton cambia de color
        if botonS.collidepoint(mouse):
            pantalla.blit(botonArriba2,(600,542))
        elif botonV.collidepoint(mouse):
            pantalla.blit(botonArriba2,(420,542))
        #Si el mouse pasa sobre un virus muestra el texto informativo
        elif ransomware.collidepoint(mouse):
            pantalla.blit(iransomware,(470,20))
        elif virus.collidepoint(mouse):
            pantalla.blit(ivirus,(470,160))
        elif incognito.collidepoint(mouse):
            pantalla.blit(iincognito,(470,280))
        elif troyano.collidepoint(mouse):
            pantalla.blit(itroyano,(470,400))
        elif b_flecha.collidepoint(mouse):
            pantalla.blit(flecha_arriba,(850,470))

        pygame.display.flip()
                    
            

    
