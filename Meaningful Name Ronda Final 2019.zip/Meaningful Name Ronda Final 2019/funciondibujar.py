# -*- coding: cp1252 -*-
#Funciones que imprimen en la pantalla todos los objetos
"""Equipo: Meaningful Name; Integrantes:
Asteasuain Martina, Garcia Romina y Zentrigen Rocio.
Colegio : Escuela Superior de Comercio "Prudencio Cornejo", Bahia Blanca"""

#.........................................................................
#Definicion de librerias e importacion de modulos
import pygame
from pygame import *
from terminarNivel import *
from TablaPuntaje import *
import random
pygame.init()


#.........................................................................
#Funcion que llama a todas las funciones e imprime todo en la pantalla
def imprimir_todo(scores,tablero,alto,pantalla,fondo,isegura,lsegura,player,virus,pixel,esquina,ipared,lpared,pmov,tiempo,font,font2,nivel,con_niveles):
    
    imprimir_fondo(fondo,pantalla)
    dibujar_tablero(tablero,alto,lpared,esquina,pixel,[],pantalla)
    imprimir_pared(ipared,pixel,esquina,pantalla,lpared)
    imprimir_segura(isegura,lsegura,pixel,esquina,pantalla)
    imprimir_jugador(player,pixel,esquina,pantalla)
    imprimir_amenaza(virus,pixel,esquina,pantalla)
    if nivel == 3 or nivel == 7 or nivel == 8: #Solo imprime en el modo nocturno la pantalla negra
        imprimir_luz(pantalla,player,pixel,esquina)
        imprimir_amigo(player,pantalla,(958,588))
    dibujar_bateria((esquina[0]+((tablero+1)*pixel),esquina[1]+(pixel)),player.bateria,pantalla,font)
    imprimir_movimientos(player.contador,font,pmov,pantalla)
    imprimir_timer(tiempo,font,(pmov[0]+62,pmov[1]+35),pantalla)
    imprimir_rondafinal(font2,(pmov[0]+20,pmov[1]-70),pantalla,player)
    imprimir_segundos_tablet(player,font,(pmov[0]+370,pmov[1]+60),pantalla)
    if nivel != 4: #Imprime el nivel actual en cada modo
        dibujar_contador_niveles(con_niveles,font,(512,500),pantalla)
    imprimir_boton(pantalla)
    #Si no quedan movimientos posibles aparece un recordatorio de las teclas X y R
    if virus.en_esquina(lpared) and not(victoria(virus,lsegura)):
        imprimir_teclas(pantalla,(esquina[0]-235,esquina[1]+170))
    imprimir_puntaje(pantalla,scores,nivel)
            

#Imprime el fondo de la pantalla        
def imprimir_fondo(fondo,pantalla):
    pantalla.blit(fondo,(0,0))
    
#Imprime la imagen de Ronda final en el modo nocturno
def imprimir_amigo(jugador,pantalla,pos):
    pantalla.blit(jugador.amigo_imagen,pos)

#Imprime la pantalla negra con un circulo transparente en el modo nocturno
def imprimir_luz(pantalla,player,pixel,inicio):
    centro = (player.luz_imagen.get_size()[0]/2,player.luz_imagen.get_size()[1]/2)
    pos_jug = (player.posicion[0]*pixel+inicio[0],player.posicion[1]*pixel+inicio[1])
    pantalla.blit(player.luz_imagen,(pos_jug[0]-centro[0]+pixel/2,pos_jug[1]-centro[1]+pixel/2))

#imprime la/s area/s protegida/s
def imprimir_segura(zona_ima,zona_pos,pixel,esquina,pantalla):
    for pos in zona_pos:
        posi = (pos[0]*pixel+esquina[0],pos[1]*pixel+esquina[1])
        pantalla.blit(zona_ima,posi)

#imprime al jugador (Super tablet)
def imprimir_jugador(jugador,pixel,esquina,pantalla):
    posicion = (jugador.posicion[0]*pixel+esquina[0],jugador.posicion[1]*pixel+esquina[1])
    pantalla.blit(jugador.imagen,posicion)

#imprime la/s amenaza/s
def imprimir_amenaza(amenaza,pixel,esquina,pantalla):
    for casilla in amenaza.posicion:
        imagen= amenaza.tipo_virus[casilla]
        posicion = (casilla[0]*pixel+esquina[0],casilla[1]*pixel+esquina[1])
        pantalla.blit(imagen,posicion)

#imprime la/s pared/es
def imprimir_pared(pared,pixel,esquina,pantalla,lista):
    for posicion in lista:
        pantalla.blit(pared,(posicion[0]*pixel+esquina[0],posicion[1]*pixel+esquina[1]))
        
#Imprime los movimientos que hizo super tablet   
def imprimir_movimientos(movs,font,pos,pantalla):
    movimientos = font.render(("Movimientos: "+str(movs)),0,(0,0,0),(128,241,251))
    pantalla.blit(movimientos,pos)

#Imprime la cantidad de niveles ganados en el modo experto
def imprimir_rondafinal(font,pos,pantalla,jugador):
    texto = font.render(("Ronda Final"),0,(0,0,0),jugador.color_final_actual)
    pantalla.blit(texto,(980,598))
    
#Imprime la cantidad de niveles ganados en el modo experto
def dibujar_contador_niveles(niv,font,pos,pantalla):
    niveles = font.render(("Nivel: "+str(niv)),0,(0,0,0),(128,241,251))
    pantalla.blit(niveles,pos)

#Imprime el tiempo restante
def imprimir_timer(tiempo,font,pos,pantalla):
    counter = font.render(tiempo,0,(0,0,0),(128,241,251))
    pantalla.blit(counter,pos)
    
#Imprime cuantos segundos Super Tablet puede estar inactiva
def imprimir_segundos_tablet(tablet,font,pos,pantalla):
    reloj = pygame.image.load("imagenes/reloj.png")#carga una imagen de un reloj 
    if tablet.tiempo_quieto/1000 > 1:
        falta = font.render("Pens� r�pido: "+str(17-(tablet.tiempo_quieto/1000)),0,(0,0,0),(128,241,251))
        pantalla.blit(falta,pos) #imprime el mensaje
        pantalla.blit(reloj,(pos[0]+70,pos[1]-70))#imprime el reloj

#imprime una explicacion de la funcion de las teclas X y R
def imprimir_teclas(pantalla,pos):
    imagen = pygame.image.load("imagenes/recordatorio.png")
    imagen = pygame.transform.scale(imagen,(350,415))
    pantalla.blit(imagen,pos)

#Imprime el boton de opciones que pausa el juego
def imprimir_boton(pantalla):
    botonP = pygame.Rect(868,460,130,50)#Boton Pausa
    mensaje_pausa = pygame.image.load("imagenes/opcionesT.png")
    #imprime el boton y su texto
    pygame.draw.rect(pantalla,(255,255,255),botonP)
    pantalla.blit(mensaje_pausa,(868,460))

#Imprime las casillas del tablero    
def dibujar_tablero(cantcasillas,cantalto,posiciones_wall,pos_inicio_tablero,pxcasillas,detalles_nivel,pantalla):   #dibuja un tablero con casillas del tamano ingresado, de los dos colores intercalados si es que en esa posicion no hay pared y esta permitido por el nivel
    
    color1 = pygame.image.load("imagenes/casilla.jpg")#carga la imagen de la casilla
    color1 = pygame.transform.scale(color1,(pxcasillas,pxcasillas))
       
    #genera el fondo del tablero imprimiendo todas las casillas
    for columnas in range(0,cantalto):
        for filas in range(0,cantcasillas):
            pantalla.blit(color1,(pxcasillas*filas+pos_inicio_tablero[0],pxcasillas*columnas+pos_inicio_tablero[1]))
            

#funcion que imprime la parte de color con animacion dentro de la bateria
def dibujar_bateria(pos,numbateria,pantalla,font):
    #Carga la imagen de la bateria
    bateria_imagen = pygame.image.load("imagenes/bateria.png")
    bateria_size = bateria_imagen.get_size()
    #Si lo que queda de bateria es negativo que siga siendo 0
    if numbateria < 0:
        numbateria = 0
    cantbateria=int(numbateria/350) #decidimos dividir la imagen en secciones de 350 cada una, siendo 20 en total
    posy=pos[1]+15
    
    if (numbateria < 700): #si la bateria es menor a la ultima seccion no se imprime por debajo de la imagen
        posy = posy + bateria_size[1]-15
    else:
        posy=posy+((20-cantbateria)*(bateria_size[1]/20)) #si todavia hay bateria se asigna un color
    if(cantbateria<=20 and cantbateria>=11):
        color=(135,250,176) #color verde
    elif(cantbateria<=10 and cantbateria>=4):
        color=(250,243,135) #Color amarillo
    else:
        color=(254,84,70) #Color rojo
    
    texto_bateria= font.render(str(numbateria)+"mA",0,(0,0,0),color)
    #se dibuja la bateria y el rectangulo con el color definido anteriormente del alto proporcionado 
    pygame.draw.rect(pantalla,color,((pos[0]+1,posy-1),(bateria_size[0]-1,bateria_size[1]-(posy-pos[1]))))
    #Se imprime la cantida de amper
    pantalla.blit(texto_bateria,(pos[0]-10,pos[1]+bateria_size[1]+10))
    #se carga e imprime el contorno de la bateria
    pantalla.blit(bateria_imagen,pos)
   

