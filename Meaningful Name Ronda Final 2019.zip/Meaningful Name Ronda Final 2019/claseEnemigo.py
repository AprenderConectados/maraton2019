#Clase de las amenazas
"""Equipo: Meaningful Name; Integrantes:
Asteasuain Martina, Garcia Romina y Zentrigen Rocio.
Colegio : Escuela Superior de Comercio "Prudencio Cornejo", Bahia Blanca"""

#.........................................................................
#Declaracion de librerias
import pygame
from pygame import *
import random
import time

#.........................................................................
#Clase enemigo da las cualidades que poseen los objetos amenaza
class enemigo (pygame.sprite.Sprite):

    #Inicializa una amenaza
    def __init__(self,tam_casilla,total): 
        pygame.sprite.Sprite.__init__(self)
        #Carga las imagenes 
        self.imagen1 = pygame.image.load("imagenes/troyano.png")
        self.imagen2 = pygame.image.load("imagenes/incognito.png")
        self.imagen3 = pygame.image.load("imagenes/virus.png")
        self.imagen4 = pygame.image.load("imagenes/ransomware.png")
        self.imagen_todas = [self.imagen1,self.imagen2,self.imagen3,self.imagen4]
        #Escala las imagenes
        for ima in range(0,len(self.imagen_todas)):
            self.imagen_todas[ima] = pygame.transform.scale(self.imagen_todas[ima],(tam_casilla,tam_casilla))
        #Lista que contiene todas las imagenes
        self.imagen = [self.imagen_todas[0],self.imagen_todas[1],self.imagen_todas[2],self.imagen_todas[3]]
        #Declara variables propias de amenaza
        self.posicion = [] #Lista que contendra todas las posiciones de amenazas
        self.derrotados = 0 #Cantidad de amenazas que estan en areas seguras
        self.max_derrotar = total #Cantidad de amenazas a derrotar
        self.tipo_virus = dict() #diccionario que guarda una imagen para cada posicion de las amenazas
        # Se genera el orden en que aparecen los tipos de virus en el nivel 
        self.orden = []
        for foto in range(0,total): 
            self.orden.append(random.choice(self.imagen))
       

    #Se fija cuantas amenazas estan en una zona segura
    def destruido(self,zona_segura,pantalla,pixeles,inicio):
        self.derrotados = 0
        for virus in self.posicion:
            if virus in zona_segura:
                self.derrotados += 1
            
                
                

    #Cuando todos los virus se encuentran en areas seguras se realiza la animacion
    def todos_derrotados(self,zona_segura,pantalla,pixeles,inicio):
        #Llama a la animacion para cada virus
        for tacho in zona_segura:
            tipo = self.tipo_virus[tacho]
            nro = self.imagen.index(tipo)
            #llama a la funcion que hace la animacion de desintegrarse
            self.desintegrarse(nro+1,pantalla,pixeles,(tacho[0]*pixeles+inicio[0],tacho[1]*pixeles+inicio[1]))
            self.posicion.remove(tacho)
            

    #Se fija si todos los virus en pantalla se pueden mover o no
    def en_esquina(self,paredes):
        esquina = True
        for virus in self.posicion:
            #Si el elemento de la lista es un 0 significa que el virus se puede mover en esa direccion
            #Si el elemento es 1 significa que hay un obstaculo
            vacio = [0,0,0,0]
            libre = 4
            if ((virus[0]+1,virus[1]) in paredes) or ((virus[0]+1,virus[1]) in self.posicion):
                vacio[0] = 1
                libre = libre - 1
            if ((virus[0]-1,virus[1]) in paredes) or ((virus[0]-1,virus[1]) in self.posicion):
                vacio[1] = 1
                libre = libre - 1
            if ((virus[0],virus[1]+1) in paredes) or ((virus[0],virus[1]+1) in self.posicion):
                vacio[2] = 1
                libre = libre - 1
            if ((virus[0],virus[1]-1) in paredes) or ((virus[0],virus[1]-1) in self.posicion):
                vacio[3] = 1
                libre = libre -1
            #Si rodeando el virus hay 2 lugares libres y si estan en la misma direccion, se puede mover, sino no
            if libre == 2:
                if (vacio[0]==0 and vacio[1]==0) or (vacio[2]==0 and vacio[3]==0):
                    esquina = False
            #Si hay mas de 2 obstaculos rodeando a un virus no se puede mover
            if libre > 2:
                esquina=False
        return esquina

    #Hace la animacion del virus desintegrandose
    def desintegrarse(self,tipo,pantalla,px,pos):
        #Carga las imagenes dependiendo del tipo de virus
        if tipo == 1:
            imagen1 = pygame.image.load("imagenes/troyanoMedioExplota.png")
            imagen2 = pygame.image.load("imagenes/troyanoExplota.png") 
        elif tipo == 2:
            imagen1 = pygame.image.load("imagenes/incognitoMedioExplota.png")
            imagen2 = pygame.image.load("imagenes/incognitoExplota.png")
        elif tipo == 3:
            imagen1 = pygame.image.load("imagenes/virusMedioExplota.png")
            imagen2 = pygame.image.load("imagenes/virusExplota.png")
        elif tipo == 4:
            imagen1 = pygame.image.load("imagenes/ransomwareMedioExplota.png")
            imagen2 = pygame.image.load("imagenes/ransomwareExplota.png")
        else:
            return False
        imagen1 = pygame.transform.scale(imagen1,(px,px))
        imagen2 = pygame.transform.scale(imagen2,(px,px))
        pantalla.blit(imagen1,pos) #imprime la imagen del virus medio explotando
        pygame.display.update()
        time.sleep(0.1)
        pantalla.blit(imagen2,pos) #imprime la imagen del virus explotado
        pygame.display.update()
        time.sleep(0.1)
