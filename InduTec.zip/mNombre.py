import pygame, pygame.font, pygame.event, pygame.draw, string
from pygame.locals import *

def TeclaPresionada():
  while 1:
      evento = pygame.event.poll()
      if evento.type == KEYDOWN:
        return evento.key
      else:
        pass

def CajaDeTexto(screen, mensaje):
  # imprime el mensaje dentro de la caja
  letra = pygame.font.Font(None,30)
  pygame.draw.rect(screen, (0,0,255),
                   ((screen.get_width() / 2) - 120,
                    (screen.get_height() / 2) - 10,
                    250,20), 0)
  pygame.draw.rect(screen, (255,255,255),
                   ((screen.get_width() / 2) - 122,
                    (screen.get_height() / 2) - 12,
                    254,24), 1)
  if len(mensaje) != 0:
      screen.blit(letra.render(mensaje, 1, (255,255,255)),
                 ((screen.get_width() / 2) - 120, (screen.get_height() / 2) - 10))
        
  pygame.display.flip()

def Pregunta(screen, pregunta):
  # Arma la pregunta y controla las teclas presionadas
  pygame.font.init()
  current_string = []
  CajaDeTexto(screen, pregunta + ": " + string.join(current_string,""))
  while 1:
    tecla = TeclaPresionada()
    if tecla == K_BACKSPACE:
      current_string = current_string[0:-1]
    elif tecla == K_RETURN:
      break
    elif tecla == K_MINUS:
      current_string.append("_")
    elif tecla <= 127:
      current_string.append(chr(tecla))
    CajaDeTexto(screen, pregunta + ": " + string.join(current_string,""))
  return string.join(current_string,"")

def main():
  #colorNegro =(0,0,0)
  colorNaranja=(255,134,62)
  screen = pygame.display.set_mode((320,240))
  ancho=90000
  alto=90000
  x=0
  y=3
  pygame.draw.rect(screen,colorNaranja,(x,y,ancho,alto))
  pygame.display.set_caption("Escribe tu nombre")
  print Pregunta(screen, "Nombre ") + " was entered"

if __name__ == '__main__': main()
