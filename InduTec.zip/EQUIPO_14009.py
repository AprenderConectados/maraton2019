
#!/usr/bin/env python
#-*- coding: utf-8 -*-
#Inicio Ronda 2 - 2019
# Equipo InduTec 14009 - Juego de la primera ronda modificado para la segunda ronda
import pygame
import random
import time

import mNombre  # M�dulo creado para ingresar por teclado el nombre del jugador
import mBuscaJugador # Modulo creado para buscar el puntaje anterior del jugador

#Inicializamos la librer�a Pygame y dem�s variables
pygame.init()
pygame.font.init()
pygame.mixer.init()

# Pide el nombre del jugador
nombreJugador=''
if nombreJugador=='':
    pantalla=pygame.display.set_mode((600,400))
    colorNaranjaClaro=(255,134,62)
    ancho=900
    alto=900
    x=0
    y=3
    pygame.draw.rect(pantalla,colorNaranjaClaro,(x,y,ancho,alto))
    pygame.display.set_caption("Escribe tu nombre")
    nombreJugador= str(mNombre.Pregunta(pantalla, 'Nombre '))
    nombreJugador=nombreJugador.upper()

# Crea tipograf�as
tipografiaConsejos = pygame.font.SysFont('Comic Sans MS', 28)
tipografiaGanaste = pygame.font.SysFont('Comic Sans MS', 32)
tipografia = pygame.font.SysFont('Comic Sans MS', 18)
tipografiaModoJuego=pygame.font.SysFont('Comic Sans MS', 26)
colorVerde,colorAzul,colorBlanco,colorNegro, colorNaranja, colorRojo= (11,102,35),(0,0,255),(255,255,255),(0,0,0),(255,128,0),(255,0,0)
listaColores  = [colorNaranja, colorAzul, colorVerde, colorBlanco]
# Prepara el tama�o de la pantalla y t�tulo
pantalla= pygame.display.set_mode((1366,700))
pygame.display.set_caption("Maraton 2019 - Ronda final")


# Declara variables globales y las inicializa
global nivelCompletado,NumeroDeMovimientos,cantVirusSobreTomas,definirNivel, time
global imgAmenaza, imgAmenaza2, imgAmenaza3, tiempoDeInicio, comienza, fin, cantVirus
global zonaDeTransporte
# Declara variables globales de la segunda ronda
global cantidadDeEnergia,movErroneos,movNormal,movEmpuja,cantidadDeEnergia,etapa, ultimoMov, puntaje, dibujaCuriosidades
global movAnt,puntosAnt,lugarVirusX,lugarVirusY,lugarJugadorX,lugarJugadorY,numeroDeVirus, consejos, dibujaCuriosidades
global nuevoLugarJugadorX,nuevoLugarJugadorY,nuevoLugarVirusX,nuevoLugarVirusY,imgAmenaza4,imgAmenaza5, etapa
global zonaProtegidaUsada1, zonaProtegidaUsada2, zonaProtegidaUsada3, zonaProtegidaUsada4, zonaProtegidaUsada5, zonaProtegidaCompleta
global puntajeFacil, puntajeDificil, reiniciar, tipoReinicio, jugadorDatosGuardados, etapaEspecial, puntajeEspecial
#Declara variables globales de la consigna sorpresa
global colorCartel, colorCartelAnt

# Se inicializan las variables
imgAmenaza=0
NumeroDeMovimientos=0
time=0
comienza=False
tiempoDeInicio=0
cantVirusSobreTomas=0
# Variable que se usa para saber la cantidad de virus que deben aparecer en pantalla
cantVirus=1
Nivel=1
fin=False
colorVerde,colorAzul,colorBlanco,colorNegro, colorNaranja, colorRojo, colorFucsia= (11,102,35),(0,0,255),(255,255,255),(0,0,0),(255,128,0),(255,0,0),(255,0,128)
cantidadDeCasillasPorLado=8 
cantPixelesPorLadoCasilla=72
salirJuego = False
lstZonasProtegidas=[]
imgAmenaza=0
imgAmenaza2=0
imgAmenaza3=0
zonaDeTransporte =[[0 for x in range (cantidadDeCasillasPorLado+1)] for y in range (cantidadDeCasillasPorLado+1)]

# Se inicializan las variables de la segunda ronda
etapa=1
puntaje=0
cantidadDeEnergia=7000
movAnt=0
movErroneos=0
movNormal=0
movEmpuja=0
ultimoMov=''
tipoReinicio=''
zonaProtegidaUsada1=0
zonaProtegidaUsada2=0
zonaProtegidaUsada3=0
zonaProtegidaUsada4=0
zonaProtegidaUsada5=0
dibujaCuriosidades=False
consejos=False
reiniciar=False
puntajeFacil=0
puntajeDificil=0
etapaEspecial=False
puntajeEspecial=0

#Carga las im�genes
imgSuperTablet=pygame.image.load("Super Tablet Ronda2.png")
imgPared=pygame.image.load("pared de zona de juego.png")
listaAmenazas  = ["Virus 1.png","Virus 2.png","Virus 3.png","Virus 4.png","Virus 5.png"]
imgAreaProtegida=pygame.image.load("zona segura.png")
zonaProtegidaCompleta=pygame.image.load("zona segura completa.png")
#imgObstaculo=pygame.image.load("obstaculo.png")



#Carga la m�sica
pygame.mixer.music.load("musica de fondo.mp3")
#Carga de sonido para el movimiento de Super Tablet
sonidoSuperTablet=pygame.mixer.Sound('Sonido Super Tablet.wav')

#Escala las im�genes al tama�o correcto
imgSuperTablet=pygame.transform.scale(imgSuperTablet, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
imgPared=pygame.transform.scale(imgPared, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
imgAreaProtegida=pygame.transform.scale(imgAreaProtegida, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
zonaProtegidaCompleta=pygame.transform.scale(zonaProtegidaCompleta,(cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla))
#imgObstaculo=pygame.transform.scale(imgObstaculo, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))

# Funci�n que permite al finalizar el programa saber como cuidar la computadora 
    
def dibujarCuriosidades():
    ancho=90000
    alto=90000
    x=0
    y=3
    pygame.draw.rect(pantalla,colorVerde,(x,y,ancho,alto))

    textoCuriosidades = tipografiaConsejos.render('Llamamos Virus a un programa que afecta una computadora.', False, colorBlanco)
    pantalla.blit(textoCuriosidades,(x+40,y+160,ancho,alto))
    textoCuriosidades = tipografiaConsejos.render("La mayor�a solo son molestos y hacen saltar carteles y publicidad." ,False, colorBlanco)
    pantalla.blit(textoCuriosidades,(x+40,y+200,ancho,alto))
    textoCuriosidades = tipografiaConsejos.render("Sin embargo, los m�s peligrosos atacan y remplazan programas." ,False, colorBlanco)
    pantalla.blit(textoCuriosidades,(x+40,y+240,ancho,alto))
    textoPrecauciones = tipografiaConsejos.render("Consejos para cuidar tu PC (La compu):" , False, colorBlanco)
    pantalla.blit(textoPrecauciones,(x+40,y+280,ancho,alto))
    textoPrecauciones = tipografiaConsejos.render('Para evitar los virus es conveniente navegar en sitios del w.w.w. (World Wide Web) con', False, colorBlanco)
    pantalla.blit(textoPrecauciones,(x+40,y+320,ancho,alto))
    textoPrecauciones = tipografiaConsejos.render("el simbolo de seguridad (Candadito color verde), o navegando en sitios con el dominio" , False, colorBlanco)
    pantalla.blit(textoPrecauciones,(x+40,y+360,ancho,alto))
    textoPrecauciones = tipografiaConsejos.render(".edu (Educativo), o .gob.ar (Gobierno argentino)." , False, colorBlanco)
    pantalla.blit(textoPrecauciones,(x+40,y+400,ancho,alto))
    textoPrecauciones = tipografiaConsejos.render("No comer, ni beber encima de la computadora. Las bebidas y migas de galletitas pueden estropearla." , False, colorBlanco)
    pantalla.blit(textoPrecauciones,(x+40,y+440))
    textoPrecauciones = tipografiaConsejos.render("Borrar los archivos que no se usan y Almacenar los que se necesitan en carpetas.", False, colorBlanco)
    pantalla.blit(textoPrecauciones,(x+40,y+480))
    pygame.display.update()
    imgTablet=pygame.image.load("Super Tablet Ronda2.png")
    imgTablet=pygame.transform.scale(imgTablet, (90,90))
    pantalla.blit(imgTablet,(x+1000,y+140,ancho,alto))
    pygame.display.update()
    textoPrecauciones = tipografiaConsejos.render(" Por favor presiona la barra espaciadora", False, colorNegro)
    pantalla.blit(textoPrecauciones,(x+100,y+550))
    pygame.display.update()


#Esta funci�n hace que el nombre del jugador aparezca en la pantalla
def bienvenidoJugador():
    global jugadorDatosGuardados
     
    x=900
    y=55
    ancho=430
    alto=52
    if jugadorDatosGuardados!='':
        # acomodar el cartel para que diga nombre y puntos
        textoBienvenida = tipografia.render(jugadorDatosGuardados, False, colorBlanco)
    else:
        textoBienvenida = tipografia.render(nombreJugador, False, colorBlanco)

    textoBienvenidaTitulo = tipografia.render('Jugador, puntaje',False, colorBlanco)
    pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
    pantalla.blit(textoBienvenidaTitulo,(x+5,y,ancho,alto))
    pantalla.blit(textoBienvenida,(x+5,y+28,ancho,alto))
    
    
    
    pygame.display.update()

#inicializa las variables de la carga de bater�a
def inicializaVarBateria():
    global cantidadDeEnergia,movErroneos,movNormal,movEmpuja
    cantidadDeEnergia=7000
    movErroneos=int(cantidadDeEnergia/200)
    movNormal=int(cantidadDeEnergia/10)
    movEmpuja=int(cantidadDeEnergia/15)

inicializaVarBateria()
    
#Funci�n que permite deshacer el �ltimo movimiento, solamente
def deshacer():
    global movAnt,puntosAnt,lugarVirusX,lugarVirusY,lugarJugadorX,lugarJugadorY,NumeroDeMovimientos,numeroDeVirus
    global movNormal,movEmpuja,MovErroneos,cantidadDeEnergia
    global nuevoLugarJugadorX,nuevoLugarJugadorY,nuevoLugarVirusX,nuevoLugarVirusY
    global colorCartel, colorCartelAnt

    #Puede deshacer si el �ltimo movimiento no fue llevar a un virus a un lugar seguro ni realizar un movimiento err�neo
    if ultimoMov!='SobreTomas' and ultimoMov!='Erroneo':

        NumeroDeMovimientos-=1
        
        borrarElemento(nuevoLugarJugadorX,nuevoLugarJugadorY)              
        posicionarElemento('jugador',lugarJugadorX, lugarJugadorY)

        x=850
        y=570
        ancho=220
        alto=40
# Devuelve el color que pose�a el cartel previamente
        textoRondaFinal = tipografiaConsejos.render('RONDA FINAL', False, colorRojo)
        pygame.draw.rect(pantalla,colorCartelAnt,(x,y,ancho,alto))
        pantalla.blit(textoRondaFinal,(x+5,y,ancho,alto))
        
        # Controla cu�l fue el �ltimo movimiento para saber cu�nta energ�a y movimientos devolver
        if ultimoMov=='Normal':
            
            movNormal+=1
            cantidadDeEnergia=cantidadDeEnergia+10
        elif ultimoMov=='Empuja':
            movEmpuja+=1
            cantidadDeEnergia+=15
            borrarElemento(nuevoLugarVirusX,nuevoLugarVirusY)
            # Usa la variable n�mero de virus para saber cu�l fue el �ltimo virus que movi�
            if numeroDeVirus=='virus1':
                posicionarElemento('virus1',lugarVirusX,lugarVirusY)
            elif numeroDeVirus=='virus2':
                posicionarElemento('virus2',lugarVirusX,lugarVirusY)
            elif numeroDeVirus=='virus3':
                posicionarElemento('virus3',lugarVirusX,lugarVirusY)
            elif numeroDeVirus=='virus4':
                posicionarElemento('virus4',lugarVirusX,lugarVirusY)
            elif numeroDeVirus=='virus5':
                posicionarElemento('virus5',lugarVirusX,lugarVirusY)


        dibujarZonaDeTransporte()
        x=1110
        y=220
        ancho=225
        alto=46
        textoNumDeMov = tipografia.render('Nro de Movimientos:   '+str(NumeroDeMovimientos), False, colorBlanco)
        pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
        pantalla.blit(textoNumDeMov,(x+5,y,ancho,alto))
        pygame.display.update()
    


# Esta funci�n incrementa el n�mero de movimientos 
def movimiento():
    global NumeroDeMovimientos, Final, colorCartel, colorCartelAnt
    
    NumeroDeMovimientos+=1
    # Emite un sonido cada vez que la Super Tablet se mueve
    sonidoSuperTablet.play()
    x=1110
    y=220
    ancho=225
    alto=40
    textoNumDeMov = tipografia.render('Nro de Movimientos:   '+str(NumeroDeMovimientos), False, colorBlanco)
    pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
    pantalla.blit(textoNumDeMov,(x+5,y,ancho,alto))
# Le damos un color al azar de una Lista para que sea el color del cartel "Ronda Final"
    x=850
    y=570
    ancho=220
    alto=40
    if NumeroDeMovimientos==1:
       colorCartelAnt=colorVerde
    else:
        colorCartelAnt=colorCartel
    
    colorCartel=random.choice(listaColores)
    
    textoRondaFinal = tipografiaConsejos.render('RONDA FINAL', False, colorRojo)
    pygame.draw.rect(pantalla,colorCartel,(x,y,ancho,alto))
    pantalla.blit(textoRondaFinal,(x+5,y,ancho,alto))

    
         
    
# Coloca el fondo de Pantalla y lo escala al tama�o correcto
def dibujarFondo():
    fondo = pygame.image.load("fondo del juego.png")
    fondo=pygame.transform.scale(fondo, (1366,700))
    pantalla.blit(fondo, (0, 0))
    pygame.display.update()

# Borra el elemento cuando lo movemos de su posici�n original o para crear una nueva zona de transporte
def borrarElemento(x,y):
    zonaDeTransporte[x][y]=0

# Crea la cuadr�cula (�rea de juego), de la 1ra etapa
def crearZonaDeTransporte1():
    global etapa, imgAmenaza, imgAmenaza2, imgAmenaza3, imgAmenaza4, imgAmenaza5
     
    # Carga una imagen de virus aleatoria
    imgAmenaza=pygame.image.load(str(random.choice(listaAmenazas)))
    imgAmenaza=pygame.transform.scale(imgAmenaza, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    
    zonaDeTransporte = [[0 for x in range (cantidadDeCasillasPorLado+1)] for y in range (cantidadDeCasillasPorLado+1)]

    for x in range(cantidadDeCasillasPorLado+1):
        for y in range(cantidadDeCasillasPorLado+1):
            borrarElemento(y,x)

    for i in range(1,cantidadDeCasillasPorLado+1):
        zonaDeTransporte[i][1] = 'pared'  
        zonaDeTransporte[i][cantidadDeCasillasPorLado] = 'pared'   
        zonaDeTransporte[1][i] = 'pared'  
        zonaDeTransporte[cantidadDeCasillasPorLado][i] = 'pared'
        

    # Asigna el espacio para mover a la Tablet
    zonaDeTransporte[3][4] = 'jugador'
        
    # Prepara el lugar donde debe aparecer el primer virus
    x=random.randint(3,6)
    y=random.randint(3,6)
    mismolugar=True
    while mismolugar==True:        # Controla que no caiga en un casillero ocupado
        if zonaDeTransporte[x][y]=='jugador': #or zonaDeTransporte[x][y]=='obstaculo'
            x=random.randint(3,6)
            y=random.randint(3,6)
        else:
            mismolugar=False
    zonaDeTransporte[x][y] = 'virus1'

    # Arma las 4 zonas protegidas
    lstZonasProtegidas.append((2,2))
    lstZonasProtegidas.append((7,2))
    lstZonasProtegidas.append((2,7))
    lstZonasProtegidas.append((7,7))
    #zonaDeTransporte[4][4] = 'obstaculo'   
    dibujarFondo()
 
    return zonaDeTransporte

def crearZonaDeTransporte2():
        global etapa, imgAmenaza, imgAmenaza2, imgAmenaza3, imgAmenaza4, imgAmenaza5

        for x in range(cantidadDeCasillasPorLado+1):
            for y in range(cantidadDeCasillasPorLado+1):
                borrarElemento(y,x)

        # Carga las im�genes de virus de forma aleatoria
        imgAmenaza=pygame.image.load(str(random.choice(listaAmenazas)))
        imgAmenaza=pygame.transform.scale(imgAmenaza, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
        imgAmenaza2=pygame.image.load(str(random.choice(listaAmenazas)))
        imgAmenaza2=pygame.transform.scale(imgAmenaza2, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
        imgAmenaza3=pygame.image.load(str(random.choice(listaAmenazas)))
        imgAmenaza3=pygame.transform.scale(imgAmenaza3, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
        imgAmenaza4=pygame.image.load(str(random.choice(listaAmenazas)))
        imgAmenaza4=pygame.transform.scale(imgAmenaza4, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
        imgAmenaza5=pygame.image.load(str(random.choice(listaAmenazas)))
        imgAmenaza5=pygame.transform.scale(imgAmenaza5, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))

        zonaDeTransporte[1][3] = 'pared'
        zonaDeTransporte[2][3] = 'pared'
        zonaDeTransporte[3][3] = 'pared'
        zonaDeTransporte[4][3] = 'pared'
        zonaDeTransporte[5][3] = 'pared'
        zonaDeTransporte[6][3] = 'pared'
        zonaDeTransporte[7][3] = 'pared'
        zonaDeTransporte[8][3] = 'pared'

        zonaDeTransporte[1][7] = 'pared'
        zonaDeTransporte[2][7] = 'pared'
        zonaDeTransporte[3][7] = 'pared'
        zonaDeTransporte[4][7] = 'pared'
        zonaDeTransporte[5][7] = 'pared'
        zonaDeTransporte[6][7] = 'pared'
        zonaDeTransporte[7][7] = 'pared'
        zonaDeTransporte[8][7] = 'pared'
        zonaDeTransporte[1][4] = 'pared'
        zonaDeTransporte[1][5] = 'pared'
        zonaDeTransporte[1][6] = 'pared'
        zonaDeTransporte[8][4] = 'pared'
        zonaDeTransporte[8][5] = 'pared'
        zonaDeTransporte[8][6] = 'pared'

        zonaDeTransporte[2][5] = 'jugador'

        zonaDeTransporte[3][5] = 'virus1'      
        zonaDeTransporte[4][5] = 'virus2'    
        zonaDeTransporte[5][5] = 'virus3'    
        zonaDeTransporte[6][5] = 'virus4' 
        zonaDeTransporte[5][6] = 'virus5'
        lstZonasProtegidas.append((2,4))
        lstZonasProtegidas.append((2,6))
        lstZonasProtegidas.append((7,4))
        lstZonasProtegidas.append((7,6))
        lstZonasProtegidas.append((4,6))
        
        dibujarFondo()
 
        return zonaDeTransporte

#Ac� crea la zona de transporte especial(etapa especial)solicitada en la ultima ronda
def crearZonaDeTransporte3():
    global etapa, imgAmenaza, imgAmenaza2, imgAmenaza3, imgAmenaza4, imgAmenaza5,etapaEspecial
    global NumeroDeMovimientos,time,comienza,tiempoDeInicio,cantVirusSobreTomas,Nivel, etapa
    global tipoReinicio,nivelCompletado,cantVirus
    global zonaProtegidaUsada1, zonaProtegidaUsada2, zonaProtegidaUsada3, zonaProtegidaUsada4, zonaProtegidaUsada5

    etapaEspecial=True
        
         
    NumeroDeMovimientos=0
    time=0
    comienza=False
    tiempoDeInicio=0
    cantVirusSobreTomas=0
    cantVirus=1
    nivelCompletado=False
    Nivel=1
    comienza=False
    inicializaVarBateria()
    zonaProtegidaUsada1=False
    zonaProtegidaUsada2=False
    zonaProtegidaUsada3=False
    zonaProtegidaUsada4=False
    zonaProtegidaUsada5=False
     
    # Carga una imagen de virus aleatoria
    imgAmenaza=pygame.image.load(str(random.choice(listaAmenazas)))
    imgAmenaza=pygame.transform.scale(imgAmenaza, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    imgAmenaza2=pygame.image.load(str(random.choice(listaAmenazas)))
    imgAmenaza2=pygame.transform.scale(imgAmenaza2, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    imgAmenaza3=pygame.image.load(str(random.choice(listaAmenazas)))
    imgAmenaza3=pygame.transform.scale(imgAmenaza3, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    imgAmenaza4=pygame.image.load(str(random.choice(listaAmenazas)))
    imgAmenaza4=pygame.transform.scale(imgAmenaza4, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    imgAmenaza5=pygame.image.load(str(random.choice(listaAmenazas)))
    imgAmenaza5=pygame.transform.scale(imgAmenaza5, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    
    zonaDeTransporte = [[0 for x in range (cantidadDeCasillasPorLado+1)] for y in range (cantidadDeCasillasPorLado+1)]

    for x in range(cantidadDeCasillasPorLado+1):
        for y in range(cantidadDeCasillasPorLado+1):
            borrarElemento(y,x)

    for i in range(1,cantidadDeCasillasPorLado+1):
        zonaDeTransporte[i][1] = 'pared'  
        zonaDeTransporte[i][cantidadDeCasillasPorLado] = 'pared'   
        zonaDeTransporte[1][i] = 'pared'  
        zonaDeTransporte[cantidadDeCasillasPorLado][i] = 'pared'
    zonaDeTransporte[7][4] = 'pared'
    zonaDeTransporte[6][4] = 'pared'
    zonaDeTransporte[5][4] = 'pared'
    zonaDeTransporte[5][3] = 'pared'
    zonaDeTransporte[7][6] = 'pared'
    zonaDeTransporte[6][6] = 'pared'
    zonaDeTransporte[5][6] = 'pared'
    zonaDeTransporte[2][5] = 'pared'
    zonaDeTransporte[2][4] = 'pared'


        
    # Carga las im�genes de virus de forma aleatoria
    imgAmenaza=pygame.image.load(str(random.choice(listaAmenazas)))
    imgAmenaza=pygame.transform.scale(imgAmenaza, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    imgAmenaza2=pygame.image.load(str(random.choice(listaAmenazas)))
    imgAmenaza2=pygame.transform.scale(imgAmenaza2, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    imgAmenaza3=pygame.image.load(str(random.choice(listaAmenazas)))
    imgAmenaza3=pygame.transform.scale(imgAmenaza3, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    imgAmenaza4=pygame.image.load(str(random.choice(listaAmenazas)))
    imgAmenaza4=pygame.transform.scale(imgAmenaza4, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    imgAmenaza5=pygame.image.load(str(random.choice(listaAmenazas)))
    imgAmenaza5=pygame.transform.scale(imgAmenaza5, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    zonaDeTransporte[3][5] = 'virus1'      
    zonaDeTransporte[4][3] = 'virus2'    
    zonaDeTransporte[5][5] = 'virus3'    
    zonaDeTransporte[5][7] = 'virus4' 
    zonaDeTransporte[3][7] = 'virus5'



    # Asigna el espacio para mover a la Tablet
    zonaDeTransporte[4][4] = 'jugador'
        

    # Arma las 5 zonas protegidas
    lstZonasProtegidas.append((2,2))
    lstZonasProtegidas.append((7,2))
    lstZonasProtegidas.append((7,5))
    lstZonasProtegidas.append((7,7))
    lstZonasProtegidas.append((2,7))
 
      
    dibujarFondo()
 
    return zonaDeTransporte    
    
    

zonaDeTransporte=crearZonaDeTransporte1()

#Funci�n para reiniciar al nivel dif�cil,solamente
def subeModo():
        global NumeroDeMovimientos,time,comienza,tiempoDeInicio,cantVirusSobreTomas,Nivel, etapa
        global tipoReinicio,nivelCompletado,cantVirus    
        global etapa, imgAmenaza, imgAmenaza2, imgAmenaza3, imgAmenaza4, imgAmenaza5
        global zonaProtegidaUsada1, zonaProtegidaUsada2, zonaProtegidaUsada3, zonaProtegidaUsada4, zonaProtegidaUsada5
         
        NumeroDeMovimientos=0
        time=0
        comienza=False
        tiempoDeInicio=0
        cantVirusSobreTomas=0
        cantVirus=1
        nivelCompletado=False
        Nivel=1
        comienza=False
        inicializaVarBateria()
        zonaProtegidaUsada1=False
        zonaProtegidaUsada2=False
        zonaProtegidaUsada3=False
        zonaProtegidaUsada4=False
        zonaProtegidaUsada5=False
        lstZonasProtegidas.remove((2,2))
        lstZonasProtegidas.remove((7,2))
        lstZonasProtegidas.remove((2,7))
        lstZonasProtegidas.remove((7,7))
        # Cartel de Reinicio de juego
        x=40
        y=40
        ancho=450
        alto=46
        
        etapa=2        
        textoReinicio = tipografiaModoJuego.render('Se inicia el MODO DIF�CIL', False, colorBlanco)
        pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
        pantalla.blit(textoReinicio,(x+5,y,ancho,alto))
        x=1110
        y=220
        ancho=225
        alto=46        
        textoNumDeMov = tipografia.render('Nro de Movimientos:   '+str(NumeroDeMovimientos), False, colorBlanco)
        pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
        pantalla.blit(textoNumDeMov,(x+5,y,ancho,alto))
        pygame.display.update()

        
# Crea un espacio que desintegra los virus al llegar a las zonas protegidas, marca de la lista el �tem usado
def hayZonaProtegidaEn(x,y):
    punto=(x,y)
    return lstZonasProtegidas.__contains__(punto)

# Indica el lugar donde deben aparecer jugador y virus
def posicionarElemento(elemento,x,y): 
    zonaDeTransporte[x][y]=elemento
    

        
#Dibuja la zona de transporte, fondo 
def dibujarZonaDeTransporte():
        global imgAmenaza, imgAmenaza2, imgAmenaza3,imgAmenaza4,imgAmenaza5, etapa, obtaculo, etapaEspecial

        cnt = 0
        for i in range(1,cantidadDeCasillasPorLado+1):
            for j in range(1,cantidadDeCasillasPorLado+1):
                if etapa==1:
                    # Dibuja el fondo de la zona de transporte del modo F�CIL
                    if cnt % 2 == 0:
                        if time<=115:
                            pygame.draw.rect(pantalla, colorVerde,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                        # Cambia los colores para los �ltimos 5 segundos
                        if (time==116 or time==118 or time>=120): 
                            pygame.draw.rect(pantalla, colorRojo,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                        if time==117 or time==119:
                            pygame.draw.rect(pantalla, colorNegro,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                    
                    else:
                        if time<=115:
                            pygame.draw.rect(pantalla, colorVerde,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                        if (time==116 or time==118 or time>=120 ):
                            pygame.draw.rect(pantalla, colorRojo,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                        if (time==117 or time==119):
                            pygame.draw.rect(pantalla, colorNegro,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                else:
                    if etapaEspecial==False:
                        # Dibuja el fondo de la zona de transporte del modo DIF�CIL
                        if j>=2 and j<=7 and i>=4 and i<=7:
                            if cnt % 2 == 0:
                                if time<=115:
                                    pygame.draw.rect(pantalla, colorFucsia,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                                # Cambia los colores para los �ltimos 5 segundos
                                if (time==116 or time==118 or time>=120): 
                                    pygame.draw.rect(pantalla, colorRojo,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                                if time==117 or time==119:
                                    pygame.draw.rect(pantalla, colorNegro,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])

                            else:
                                if time<=115:
                                    pygame.draw.rect(pantalla, colorFucsia,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                                if (time==116 or time==118 or time>=120 ):
                                    pygame.draw.rect(pantalla, colorRojo,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                                if (time==117 or time==119):
                                    pygame.draw.rect(pantalla, colorNegro,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                    else:
                    # Dibuja el fondo de la zona de transporte del modo ESPECIAL
                        if cnt % 2 == 0:
                            if time<=115:
                                pygame.draw.rect(pantalla, colorNaranjaClaro,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                                #pygame.draw.rect(pantalla, colorRojo,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                            # Cambia los colores para los �ltimos 5 segundos
                            if (time==116 or time==118 or time>=120): 
                                pygame.draw.rect(pantalla, colorRojo,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                            if time==117 or time==119:
                                pygame.draw.rect(pantalla, colorNegro,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                        
                        else:
                            if time<=115:
                                pygame.draw.rect(pantalla, colorNaranjaClaro,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                            if (time==116 or time==118 or time>=120 ):
                                pygame.draw.rect(pantalla, colorRojo,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
                            if (time==117 or time==119):
                                pygame.draw.rect(pantalla, colorNegro,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])

                if (hayZonaProtegidaEn(j,i)==True):
                    if etapaEspecial==False:
                        # Si la zona protegida ya fue usada le carga la misma imagen pero con tilde (no puede dejar m�s de un virus en dicha zona)
                        if (j==2 and i==4 and zonaProtegidaUsada1==True) or (j==2 and i==6 and zonaProtegidaUsada2==True) or (j==7 and i==4 and zonaProtegidaUsada3==True) or (j==7 and i==6 and zonaProtegidaUsada4==True) or  (j==4 and i==6 and zonaProtegidaUsada5==True):
                            pantalla.blit(zonaProtegidaCompleta, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
                        else:
                            # Si la zona protegida no est� usada le carga la imagen com�n
                            pantalla.blit(imgAreaProtegida, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
                    else:
                        # Si la zona protegida ya fue usada le carga la misma imagen pero con tilde (no puede dejar m�s de un virus en dicha zona)
                        if (j==2 and i==2 and zonaProtegidaUsada1==True) or (j==7 and i==2 and zonaProtegidaUsada2==True) or (j==7 and i==5 and zonaProtegidaUsada3==True) or (j==7 and i==7 and zonaProtegidaUsada4==True) or  (j==2 and i==7 and zonaProtegidaUsada5==True):
                            pantalla.blit(zonaProtegidaCompleta, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
                        else:
                            # Si la zona protegida no est� usada le carga la imagen com�n
                            pantalla.blit(imgAreaProtegida, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
                            
                if (zonaDeTransporte[j][i]=='jugador'):
                   pantalla.blit(imgSuperTablet, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i)) 
                if (zonaDeTransporte[j][i]=='pared'):   
                   pantalla.blit(imgPared, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
                if (zonaDeTransporte[j][i]=='virus1'):
                    pantalla.blit(imgAmenaza,(cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
                if (zonaDeTransporte[j][i]=='virus2'):        
                    pantalla.blit(imgAmenaza2, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
                if (zonaDeTransporte[j][i]=='virus3'):
                    pantalla.blit(imgAmenaza3, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
                if (zonaDeTransporte[j][i]=='virus4'):
                    pantalla.blit(imgAmenaza4, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
                if (zonaDeTransporte[j][i]=='virus5'):
                    pantalla.blit(imgAmenaza5, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
                 
                    
                cnt +=1
            cnt-=1
        if etapa==1 or etapaEspecial==True:
            # Crea el borde blanco de la zona de transporte
            pygame.draw.rect(pantalla,colorBlanco,[cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla,cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla,cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla],1)       
            pygame.display.update()
        else:
            # Crea el borde blanco de la zona de transporte
            pygame.draw.rect(pantalla,colorBlanco,[72,216,cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla,5*cantPixelesPorLadoCasilla],1)       
            pygame.display.update()
                
        pygame.display.update()

#Esta funci�n informa el nivel de juego (1, 2 o 3 virus en pantalla), del modo f�cil (1ra ronda)
def nivel():
    textodefinirNivel = tipografia.render('Nivel', False, colorBlanco)
    
    ancho=125
    alto=46
    x=1110
    y=100
    pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
    pantalla.blit(textodefinirNivel,(x+40,y,ancho,alto))
    textodefinirNivel = tipografia.render(str(Nivel), False, colorBlanco)
    pantalla.blit(textodefinirNivel,(x+50,y+18,ancho,alto))
    pygame.display.update()
    
  
# Creamos el texto con las reglas    
def dibujarReglas():
    global etapa, NumeroDeMovimientos

    x=1110
    y=220
    ancho=225
    alto=40
         
    textoNumDeMov = tipografia.render('Nro de Movimientos:   '+str(NumeroDeMovimientos), False, colorBlanco)
         
    pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
    pantalla.blit(textoNumDeMov,(x+5,y,ancho,alto))
    pygame.display.update()
    if etapa==1:
        # Reglas del modo f�cil
        textoReglas = tipografia.render('Mover a Super Tablet con las flechas del teclado para que lleve los virus a las zonas protegidas,', False, colorBlanco)
        ancho=825
        alto=50
        x=520
        y=3
        pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
        pantalla.blit(textoReglas,(x+5,y,ancho,alto))
        textoReglas = tipografia.render('s�lo tendr�s 120 segundos para eliminar a los 20 virus antes de que se apoderen de tu computadora ', False, colorBlanco)
        pantalla.blit(textoReglas,(x+5,y+25,ancho,alto))
        pygame.display.update()
        # Llama a la funci�n que muestra el nivel
        nivel()
    elif etapa==2:
        # Reglas del modo dificl        
        ancho=825
        alto=50
        x=520
        y=3
        pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
        textoReglas = tipografia.render('Mover a Super Tablet con las flechas del teclado para que lleve los virus a las zonas protegidas,', False, colorBlanco)
        pantalla.blit(textoReglas,(x+5,y,ancho,alto))
        textoReglas = tipografia.render('antes de que la bater�a y el tiempo se agoten. Cada zona segura puede recibir un solo virus ', False, colorBlanco)
        pantalla.blit(textoReglas,(x+5,y+25,ancho,alto))
        pygame.display.update()

    #Carteles con movimientos permitidos y descarga bater�a
   
    x=670
    y=150
    ancho=400
    alto=400

    

    if comienza == False:
        #Este cartel va a estar presente hasta que se presione la primera tecla
        
        pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
        textoNumDeMov = tipografia.render('Carga completa de Super Tablet: 7000 mA.', False, colorBlanco)         
        pantalla.blit(textoNumDeMov,(x+5,y+5,ancho,alto))
        y=200
        textoNumDeMov = tipografia.render('La carga se consume de la siguiente manera:', False, colorBlanco)         
        pantalla.blit(textoNumDeMov,(x+5,y+5,ancho,alto))
        textoNumDeMov = tipografia.render('Al moverse: 10 mA - Al empujar 1 virus: 15 mA', False, colorBlanco)         
        pantalla.blit(textoNumDeMov,(x+5,y+45,ancho,alto))
        textoNumDeMov = tipografia.render('Si intenta realizar movimientos no permitidos:', False, colorBlanco)         
        pantalla.blit(textoNumDeMov,(x+5,y+85,ancho,alto))
        textoNumDeMov = tipografia.render('2 virus juntos o virus y pared, 200 mA', False, colorBlanco)         
        pantalla.blit(textoNumDeMov,(x+5,y+125,ancho,alto))
        textoNumDeMov = tipografia.render('La tecla X deshace solo el �ltimo movimiento', False, colorBlanco)         
        pantalla.blit(textoNumDeMov,(x+5,y+165,ancho,alto))
        textoNumDeMov = tipografia.render('La tecla R reinicia el modo (F�cil o Dif�cil)', False, colorBlanco)         
        pantalla.blit(textoNumDeMov,(x+5,y+205,ancho,alto))
        textoNumDeMov = tipografia.render('Se reinicia con 15 segundos de inactividad', False, colorBlanco)         
        pantalla.blit(textoNumDeMov,(x+5,y+245,ancho,alto))
        textoNumDeMov = tipografia.render('Presiona una tecla de movimiento para comenzar', False, colorBlanco)         
        pantalla.blit(textoNumDeMov,(x+5,y+290,ancho,alto))

    else:
        #Este cartel muestra de forma continua los cinco mejores puntajes obtenidos en el juego
        pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
        textoMejoresPuntajes = tipografia.render('MEJORES PUNTAJES: ', False, colorBlanco)
        pantalla.blit(textoMejoresPuntajes,(x+95,y+45,ancho,alto))
        y=250
        for j in range(5):
            textoMejoresPuntajes=tipografia.render(str(mejoresPuntajes[j]), False, colorBlanco)
            pantalla.blit(textoMejoresPuntajes,(x+20,y,ancho,alto))
            y=y+30
         
    pygame.display.update()

    
        

# Crea el cartel de felicitaci�n o Juego en curso y modo de juego
def dibujarFelicitacion():
    global nivelCompletado, fin, etapa, cantidadDeEnergia, dibujaCuriosidades
    global nuevoPuntaje, jugadorDatosGuardados   # se usa para guardar el puntaje al finalizar el juego
    global puntajeFacil, puntajeDificil, tipoReinicio, jugadorDatosGuardados, puntajeEspecial
    
    x=50
    y=3
    ancho=440
    alto=46

    if (nivelCompletado==True):
        if  tipoReinicio=='MODODIFICIL':
            # Si ingresa a este if es porque supero el modo f�cil y pasa al siguiente modo

            textoFelicitacion = tipografiaModoJuego.render('Ganaste, pasas al MODO DIF�CIL', False, colorBlanco)
            
            #crea una nueva versi�n del juego la cu�l posee mas dificultad 
            etapa=2
            nivelCompletado=False
            pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
            pantalla.blit(textoFelicitacion,(x+5,y,ancho,alto))
            pygame.display.update()

        else:
            if etapaEspecial == True:
                # Si ingresa por else es porque supero el modo dif�cil y gana el juego
                # Sumas los puntajes obtenidos en los dos modos
                nuevoPuntaje=puntajeFacil+puntajeDificil+puntajeEspecial

                # Abre el archivo para guardar el nuevo dato (Jugador y puntaje)
                
                if jugadorDatosGuardados!='':
                    lineaNueva=mBuscaJugador.mActualizaPuntaje(nombreJugador,nuevoPuntaje, jugadorDatosGuardados, "Jugador y puntaje.txt")
                else:
                    f = open("Jugador y puntaje.txt","a")
                    lineaNueva=nombreJugador+', '+str(nuevoPuntaje)
                    f.write("\n"+lineaNueva)
                    f.close()
                
                # Llama al m�dulo que ordena los mejores puntajes y los muestra
                mejoresPuntajes=mBuscaJugador.mOrdenaTxt("Jugador y puntaje.txt",",")
               
                x=300
                y=200
                ancho=600
                alto=800
                
                textoFelicitacion = tipografiaGanaste.render('GANASTE EL JUEGO  '+ str(nombreJugador), False, colorBlanco)
                fin=True
                pygame.draw.rect(pantalla,colorRojo,(x,y,ancho,alto))
                pantalla.blit(textoFelicitacion,(x+50,y+20,ancho,alto))
                textoFelicitacion = tipografiaModoJuego.render('     TU NUEVO PUNTAJE ES '+ str(nuevoPuntaje), False, colorBlanco)
                pantalla.blit(textoFelicitacion,(x+50,y+50,ancho,alto))
                nivelCompletado=False
                textoMejoresPuntajes = tipografiaModoJuego.render('MEJORES PUNTAJES: ', False, colorBlanco)
                pantalla.blit(textoMejoresPuntajes,(x+50,y+80,ancho,alto))
                y=350
                for j in range(5):
                    textoMejoresPuntajes=tipografiaModoJuego.render(str(mejoresPuntajes[j]), False, colorBlanco)
                    pantalla.blit(textoMejoresPuntajes,(x+20,y,ancho,alto))
                    y=y+30
                pygame.display.update()
                pygame.time.delay(8000)
                # Carga la pantalla con consejos �tiles
                dibujaCuriosidades=True
                
    else:
        # El juego est� en curso, informa el modo del mismo (f�cil o dif�cil)
        if fin==False:
            if cantidadDeEnergia>10:
                if etapa==1:
                    textoFelicitacion = tipografiaModoJuego.render('Juego en curso - MODO F�CIL', False, colorBlanco)
                else:
                    textoFelicitacion = tipografiaModoJuego.render('Juego en curso - MODO DIF�CIL', False, colorBlanco)
                pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
                pantalla.blit(textoFelicitacion,(x+5,y,ancho,alto))
                pygame.display.update()
    
# Arma la pantalla completa
def dibujarTodo():
    #es lo mismo para las dos etapas
    dibujarFondo()
    dibujarZonaDeTransporte()
    dibujarReglas()
    # da el cartel de saludo
    bienvenidoJugador()
    pygame.display.update()


# llama al m�dulo que busca el nombre del jugador y sus puntos anteriores
jugadorDatosGuardados=str(mBuscaJugador.mBuscaJugador(nombreJugador))
dibujarTodo()

# LLama al m�dulo que ordena los mejores puntajes y los muestra
mejoresPuntajes=mBuscaJugador.mOrdenaTxt("Jugador y puntaje.txt",",")


#Crea una operaci�n que indica si el nivel fue solucionado y si el virus entra en la zona segura
def estaSolucionado():
    global nivelCompletado, cantVirusSobreTomas, etapa, tipoReinicio, cantVirus,  etapaEspecial
    global imgAmenaza, imgAmenaza2, imgAmenaza3, ultimoMov,imgAmenaza4,imgAmenaza5, zonaProtegidaCompleta
    global zonaProtegidaUsada1, zonaProtegidaUsada2, zonaProtegidaUsada3, zonaProtegidaUsada4, zonaProtegidaUsada5
    global puntajeFacil, puntajeDificil, cantidadDeEnergia, time, nivelCompletado, puntajeEspecial


    if etapa==1:
        for punto in lstZonasProtegidas:
            x=punto[0]
            y=punto[1]
            if zonaDeTransporte[x][y]=='virus1':
                cantVirusSobreTomas=cantVirusSobreTomas+1
                ultimoMov='SobreTomas'

                
               #Llama a la funci�n que borra el virus
                borrarElemento(x,y)
                x=1110
                y=180
                ancho=180
                alto=46
        
                txtcantVirusSobreTomas = tipografia.render('Virus eliminados:   '+str(cantVirusSobreTomas), False, colorBlanco)
        
                pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
                pantalla.blit(txtcantVirusSobreTomas,(x+5,y,ancho,alto))
                pygame.display.update()
                
                #Luego de que el virus sea borrado, se a�ade otro virus
                imgAmenaza=pygame.image.load(random.choice(listaAmenazas))
                imgAmenaza=pygame.transform.scale(imgAmenaza,(cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla))
                x=random.randint(3,6)
                y=random.randint(3,6)
                mismolugar=True
                while mismolugar==True:
                    if zonaDeTransporte[x][y]=='jugador' or zonaDeTransporte[x][y]=='virus2' or zonaDeTransporte[x][y]=='virus3': #or zonaDeTransporte[x][y]=='obstaculo':
                        x=random.randint(3,6)
                        y=random.randint(3,6)
                    else:
                        mismolugar=False
                # Le "decimos" al programa que, con un random, elija la ubicaci�n de los virus y definimos la cantidad de virus desintegrados para terminar el juego
                posicionarElemento("virus1",x,y)
                pantalla.blit(imgAmenaza,(cantPixelesPorLadoCasilla*x,cantPixelesPorLadoCasilla*y))
               
            if zonaDeTransporte[x][y]=='virus2':
                cantVirusSobreTomas=cantVirusSobreTomas+1
                ultimoMov='SobreTomas'
                
               #Llama a la funci�n que borra el virus
                borrarElemento(x,y)
                x=1110
                y=180
                ancho=180
                alto=46
        
                txtcantVirusSobreTomas = tipografia.render('Virus eliminados:   '+str(cantVirusSobreTomas), False, colorBlanco)
        
                pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
                pantalla.blit(txtcantVirusSobreTomas,(x+5,y,ancho,alto))
                pygame.display.update()
                
                #Luego de que el virus sea borrado, se a�ade otro virus
                imgAmenaza2=pygame.image.load(random.choice(listaAmenazas))
                imgAmenaza2=pygame.transform.scale(imgAmenaza2,(cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla))
                x=random.randint(3,6)
                y=random.randint(3,6)
                mismolugar=True
                while mismolugar==True:
                    # Controla que no caiga en un casillero ocupado 
                    if zonaDeTransporte[x][y]=='jugador'  or zonaDeTransporte[x][y]=='virus1' or zonaDeTransporte[x][y]=='virus3': #or zonaDeTransporte[x][y]=='obstaculo': 
                        x=random.randint(3,6)
                        y=random.randint(3,6)
                   
                        
                    else:
                        mismolugar=False
                    # Le "decimos" al programa que, con un random, elija la ubicaci�n de los virus 
                posicionarElemento("virus2",x,y)
                pantalla.blit(imgAmenaza2,(cantPixelesPorLadoCasilla*x,cantPixelesPorLadoCasilla*y))
                 #if (zonaDeTransporte[x][y]=='obstaculo'):   
                        #pantalla.blit(imgObstaculo, (cantPixelesPorLadoCasilla*x,cantPixelesPorLadoCasilla*y))

            if zonaDeTransporte[x][y]=='virus3':
                cantVirusSobreTomas=cantVirusSobreTomas+1
                ultimoMov='SobreTomas'
                
               #Llama a la funci�n que borra el virus
                borrarElemento(x,y)
                x=1110
                y=180
                ancho=180
                alto=46
        
                txtcantVirusSobreTomas = tipografia.render('Virus eliminados:   '+str(cantVirusSobreTomas), False, colorBlanco)
        
                pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
                pantalla.blit(txtcantVirusSobreTomas,(x+5,y,ancho,alto))
                pygame.display.update()
                
                #Luego de que el virus sea borrado, se a�ade otro virus
                imgAmenaza3=pygame.image.load(random.choice(listaAmenazas))
                imgAmenaza3=pygame.transform.scale(imgAmenaza3,(cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla))
                x=random.randint(3,6)
                y=random.randint(3,6)
                mismolugar=True
                while mismolugar==True:
                    if zonaDeTransporte[x][y]=='jugador'  or zonaDeTransporte[x][y]=='virus2' or zonaDeTransporte[x][y]=='virus1': #or zonaDeTransporte[x][y]=='obstaculo':
                        x=random.randint(3,6)
                        y=random.randint(3,6)
                    else:
                        mismolugar=False
                posicionarElemento("virus3",x,y)
                pantalla.blit(imgAmenaza3,(cantPixelesPorLadoCasilla*x,cantPixelesPorLadoCasilla*y))

    else:
        #print etapaEspecial
        aseguraVirus=False
        # Para la segunda ronda, cambiamos la forma de buscar
        # Recorre el vector de zonaDeTransporte y donde coinciden los lugares i y j con las zonas protegidas compara
        if etapaEspecial==False:
            for i in range(1,cantidadDeCasillasPorLado+1):
                for j in range(1,cantidadDeCasillasPorLado+1):
                    # Zonas protegidas 2,4  2,6  7,4   7,6  y  4,6
                    if (j==2 and i==4) or (j==2 and i==6) or (j==7 and i==4) or (j==7 and i==6) or (j==4 and i==6):
                        if (j==2 and i==4 and zonaProtegidaUsada1==False) or (j==2 and i==6 and zonaProtegidaUsada2==False) or (j==7 and i==4 and zonaProtegidaUsada3==False) or (j==7 and i==6 and zonaProtegidaUsada4==False)  or (j==4 and i==6 and zonaProtegidaUsada5==False): 
                            if zonaDeTransporte[j][i]=='virus1' or zonaDeTransporte[j][i]=='virus2' or zonaDeTransporte[j][i]=='virus3'  or zonaDeTransporte[j][i]=='virus4' or zonaDeTransporte[j][i]=='virus5':
                                #Si la zona protegida ya se us� no se puede tirar el virus ah�                        
                                if j==2 and i==4 and zonaProtegidaUsada1==False:
                                    zonaProtegidaUsada1=True
                                    aseguraVirus=True
                                if j==2 and i==6 and zonaProtegidaUsada2==False:
                                    zonaProtegidaUsada2=True
                                    aseguraVirus=True
                                if j==7 and i==4 and zonaProtegidaUsada3==False:
                                    aseguraVirus=True
                                    zonaProtegidaUsada3=True
                                if j==7 and i==6 and zonaProtegidaUsada4==False:
                                    zonaProtegidaUsada4=True
                                    aseguraVirus=True
                                if j==4 and i==6 and zonaProtegidaUsada5==False:
                                    zonaProtegidaUsada5=True
                                    aseguraVirus=True
                                if aseguraVirus==True:
                                    cantVirusSobreTomas=cantVirusSobreTomas+1
                                    ultimoMov='SobreTomas'
                                   #Llama a la funci�n que borra el virus
                                    borrarElemento(j,i)
                                    x=1110
                                    y=180
                                    ancho=180
                                    alto=46
                            
                                    txtcantVirusSobreTomas = tipografia.render('Virus eliminados:   '+str(cantVirusSobreTomas), False, colorBlanco)
                            
                                    pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
                                    pantalla.blit(txtcantVirusSobreTomas,(x+5,y,ancho,alto))
                                    pygame.display.update()

        else:
#           # Pertenece a la etapa especial
            for i in range(1,cantidadDeCasillasPorLado+1):
                for j in range(1,cantidadDeCasillasPorLado+1):
                    # Zonas protegidas 2,2 7,2 7,5 7,7 y 2,7
                    if (j==2 and i==2) or (j==7 and i==2) or (j==7 and i==5) or (j==7 and i==7) or (j==2 and i==7):
 #                       if (j==2 and i==2 and zonaProtegidaUsada1==False) or (j==7 and i==2 and zonaProtegidaUsada2==False) or (j==7 and i==5 and zonaProtegidaUsada3==False) or (j==7 and i==7 and zonaProtegidaUsada4==False)  or (j==2 and i==7 and zonaProtegidaUsada5==False): 
                        if zonaDeTransporte[j][i]=='virus1' or zonaDeTransporte[j][i]=='virus2' or zonaDeTransporte[j][i]=='virus3'  or zonaDeTransporte[j][i]=='virus4' or zonaDeTransporte[j][i]=='virus5':
                            #Si la zona protegida ya se us� no se puede tirar el virus ah�                        
                            if j==2 and i==2 and zonaProtegidaUsada1==False:
                                zonaProtegidaUsada1=True
                                aseguraVirus=True
                            if j==7 and i==2 and zonaProtegidaUsada2==False:
                                zonaProtegidaUsada2=True
                                aseguraVirus=True
                            if j==7 and i==5 and zonaProtegidaUsada3==False:
                                aseguraVirus=True
                                zonaProtegidaUsada3=True
                            if j==7 and i==7 and zonaProtegidaUsada4==False:
                                zonaProtegidaUsada4=True
                                aseguraVirus=True
                            if j==2 and i==7 and zonaProtegidaUsada5==False:
                                zonaProtegidaUsada5=True
                                aseguraVirus=True
                            if aseguraVirus==True:
                                cantVirusSobreTomas=cantVirusSobreTomas+1
                                ultimoMov='SobreTomas'
                                   #Llama a la funci�n que borra el virus
                                borrarElemento(j,i)
                                x=1110
                                y=180
                                ancho=180
                                alto=46
                            
                                txtcantVirusSobreTomas = tipografia.render('Virus eliminados:   '+str(cantVirusSobreTomas), False, colorBlanco)
                            
                                pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
                                pantalla.blit(txtcantVirusSobreTomas,(x+5,y,ancho,alto))
                                pygame.display.update()

            

    if etapa==1:
        #si los puntos son mayores a 20 el nivel fue completado 
        if (cantVirusSobreTomas>=20):
            nivelCompletado=True
            # Realiz� el nivel f�cil, pasa al dif�cil (2ra ronda)
            tipoReinicio='MODODIFICIL'
            puntajeFacil=cantidadDeEnergia/time
           # subeModo()

           # dibujarTodo()
           # dibujarZonaDeTransporte()

        else:
            nivelCompletado=False
    else:
        if etapaEspecial==False: 
            if (cantVirusSobreTomas==5):
                nivelCompletado=True
                #Realiz� el nivel dif�cil, pasa a la etapa Especial (Ronda Final)
                tipoReinicio='MODOESPECIAL'
                puntajeDificil=cantidadDeEnergia/time

            else:
                nivelCompletado=False
        else:
            if (cantVirusSobreTomas==5):
                nivelCompletado=True
                #Complet� la etapa Especial, Termin� el juuego 
                puntajeEspecial=cantidadDeEnergia/time
                tipoReinicio='GANO'
        
    dibujarFelicitacion()
    dibujarReglas()


# Genera los movimientos de jugador y virus
def irALaDerecha():
    global tiempoDeInicio, comienza, cantidadDeEnergia, movErroneos, movEmpuja, movNormal,numeroDeVirus
    global movAnt,puntosAnt,lugarVirusX,lugarVirusY,lugarJugadorX,lugarJugadorY,NumeroDeMovimientos, ultimoMov
    global nuevoLugarJugadorX,nuevoLugarJugadorY,nuevoLugarVirusX,nuevoLugarVirusY
    global movNormal, movEmpuja, MovErroneos
    
    # Controla que el juego no haya terminado
    if fin==False:
        
        if comienza==False:
            # Ya presion� la primera tecla para jugar, comienza el tiempo
            comienza=True
            inicializaVarBateria()
            # Guarda el tiempo que transcurri� desde que se inicializ� pygame hasta que empez� a jugar
            tiempoDeInicio=pygame.time.get_ticks()

             
        for i in range(1,cantidadDeCasillasPorLado):
            for j in range(1,cantidadDeCasillasPorLado):

                if (zonaDeTransporte[j][i]=='jugador'):
                    # Mueve si el siguiente lugar est� vac�o
                    if (zonaDeTransporte[j+1][i]==0) :
                        posicionarElemento('jugador',j+1,i)
                        # Controla si a�n tiene energ�a la bater�a para realizar el movimiento y si hay movimientos disponibles
                        if cantidadDeEnergia<10 or movNormal==0:
                            break
                        else:
                            cantidadDeEnergia-=10
                            movNormal-=1
                        #guarda los lugares por si elije deshacer
                        lugarJugadorX=j
                        lugarJugadorY=i
                        nuevoLugarJugadorX=j+1
                        nuevoLugarJugadorY=i
                        ultimoMov='Normal'
                        borrarElemento(j,i)
                        movimiento()
                        break
                    # Si el siguiente lugar tiene virus, analiza cu�l es para poder cambiarle la ubicaci�n
                    if(zonaDeTransporte[j+1][i]=='virus1' or zonaDeTransporte[j+1][i]=='virus2' or zonaDeTransporte[j+1][i]=='virus3')or zonaDeTransporte[j+1][i]=='virus4' or zonaDeTransporte[j+1][i]=='virus5' :
                        numeroDeVirus=zonaDeTransporte[j+1][i]
                        # Controla  2 lugares m�s adelante
                        if (zonaDeTransporte[j+2][i]!=0):
                            # Si 2 lugares m�s adelante est�n ocupados, son movimientos err�neos que no se pueden realizar pero igual gastan energ�a
                            # Controla si a�n tiene energ�a la bater�a para realizar el movimiento y si hay movimientos disponibles
                            if movErroneos==0 or cantidadDeEnergia<200:
                                # Movimiento no permitido ACOMODAR
                                break
                            else:
                                cantidadDeEnergia-=200
                                movErroneos-=1
                                ultimoMov='Erroneo'
                        else:
                            # Si 2 lugares m�s adelante est�n vac�os, puede empujar el virus
                            # Controla si tiene energ�a la bater�a para realizar el movimiento y si tiene movimientos disponibles
                            if cantidadDeEnergia<15 or movEmpuja ==0:
                                break
                            else:
                                 cantidadDeEnergia-=15
                                 movEmpuja-=1
                                 ultimoMov='Empuja'
                        lugarJugadorX=j
                        lugarJugadorY=i
                        nuevoLugarJugadorX=j+1
                        nuevoLugarJugadorY=i
                        lugarVirusX=j+1
                        lugarVirusY=i
                        nuevoLugarVirusX=j+2
                        nuevoLugarVirusY=i

                        # Si es virus1
                        if (zonaDeTransporte[j+1][i]=='virus1'):
                            # Si 2 lugares m�s adelante, el lugar est� vaci� puede cambiar la ubicaci�n de jugador y virus
                            if (zonaDeTransporte[j+2][i]==0):
                                borrarElemento(j,i)
                                posicionarElemento('virus1',j+2,i)
                                posicionarElemento('jugador',j+1,i)
                                movimiento()
                                break
                        # Si es virus2    
                        if (zonaDeTransporte[j+1][i]=='virus2'):
                            if (zonaDeTransporte[j+2][i]==0):
                                borrarElemento(j,i)
                                posicionarElemento('virus2',j+2,i)
                                posicionarElemento('jugador',j+1,i)
                                movimiento()
                                break
                        # Si es virus3
                        if (zonaDeTransporte[j+1][i]=='virus3'):
                            if (zonaDeTransporte[j+2][i]==0):
                                borrarElemento(j,i)
                                posicionarElemento('virus3',j+2,i)
                                posicionarElemento('jugador',j+1,i)
                                movimiento()
                                break
                        # Si es virus4
                        if (zonaDeTransporte[j+1][i]=='virus4'):
                            if (zonaDeTransporte[j+2][i]==0):
                                borrarElemento(j,i)
                                posicionarElemento('virus4',j+2,i)
                                posicionarElemento('jugador',j+1,i)
                                movimiento()
                                break
                        # Si es virus5
                        if (zonaDeTransporte[j+1][i]=='virus5'):
                            if (zonaDeTransporte[j+2][i]==0):
                                borrarElemento(j,i)
                                posicionarElemento('virus5',j+2,i)
                                posicionarElemento('jugador',j+1,i)
                                movimiento()
                                break
                            
                       

                        
def irALaIzquierda():
    global tiempoDeInicio, comienza, cantidadDeEnergia, movErroneos, movEmpuja, movNormal,numeroDeVirus
    global movAnt,puntosAnt,lugarVirusX,lugarVirusY,lugarJugadorX,lugarJugadorY,NumeroDeMovimientos, ultimoMov
    global nuevoLugarJugadorX,nuevoLugarJugadorY,nuevoLugarVirusX,nuevoLugarVirusY

    if fin==False:
        if comienza==False:
            comienza=True
            inicializaVarBateria()
            tiempoDeInicio=pygame.time.get_ticks()
        for i in range(1,cantidadDeCasillasPorLado):
            for j in range(1,cantidadDeCasillasPorLado):
                if (zonaDeTransporte[j][i]=='jugador'):
                    if (zonaDeTransporte[j-1][i]==0) :
                        posicionarElemento('jugador',j-1,i)
                        borrarElemento(j,i)
                        if cantidadDeEnergia<10 or movNormal==0:
                            break
                        else:
                            cantidadDeEnergia-=10
                            movNormal-=1
                            
                        lugarJugadorX=j
                        lugarJugadorY=i
                        nuevoLugarJugadorX=j-1
                        nuevoLugarJugadorY=i
                        ultimoMov='Normal'
                            
                        movimiento()
                        break
                    if(zonaDeTransporte[j-1][i]=='virus1' or zonaDeTransporte[j-1][i]=='virus2' or zonaDeTransporte[j-1][i]=='virus3'or zonaDeTransporte[j-1][i]=='virus4' or zonaDeTransporte[j-1][i]=='virus5'):
                        numeroDeVirus=zonaDeTransporte[j-1][i]

                        if (zonaDeTransporte[j-2][i]!=0):
                           if movErroneos==0 or cantidadDeEnergia<200:
                                break
                           else:
                               
                                cantidadDeEnergia=cantidadDeEnergia-200
                                movErroneos-=1
                                ultimoMov='Erroneo'
                        
                        else:
                           if cantidadDeEnergia<15 or movEmpuja ==0:
                                break
                           else:
                                cantidadDeEnergia-=15
                                movEmpuja-=1
                                ultimoMov='Empuja'
                       
                        lugarJugadorX=j
                        lugarJugadorY=i
                        nuevoLugarJugadorX=j-1
                        nuevoLugarJugadorY=i
                        lugarVirusX=j-1
                        lugarVirusY=i
                        nuevoLugarVirusX=j-2
                        nuevoLugarVirusY=i
                            
                        if (zonaDeTransporte[j-1][i]=='virus1'):
                           if (zonaDeTransporte[j-2][i]==0):
                                borrarElemento(j,i)
                                posicionarElemento('virus1',j-2,i)
                                posicionarElemento('jugador',j-1,i)
                                movimiento()
                           
                                break
                        if (zonaDeTransporte[j-1][i]=='virus2'):
                            if (zonaDeTransporte[j-2][i]==0):
                                borrarElemento(j,i)
                                posicionarElemento('virus2',j-2,i)
                                posicionarElemento('jugador',j-1,i)
                                movimiento()
                                break   
                        if (zonaDeTransporte[j-1][i]=='virus3'):
                                if (zonaDeTransporte[j-2][i]==0):
                                    borrarElemento(j,i)
                                    posicionarElemento('virus3',j-2,i)
                                    posicionarElemento('jugador',j-1,i)
                                    movimiento()
                                    break
                        if (zonaDeTransporte[j-1][i]=='virus4'):
                                if (zonaDeTransporte[j-2][i]==0):
                                    borrarElemento(j,i)
                                    posicionarElemento('virus4',j-2,i)
                                    posicionarElemento('jugador',j-1,i)
                                    movimiento()
                                    break
                        if (zonaDeTransporte[j-1][i]=='virus5'):
                                if (zonaDeTransporte[j-2][i]==0):
                                    borrarElemento(j,i)
                                    posicionarElemento('virus5',j-2,i)
                                    posicionarElemento('jugador',j-1,i)
                                    movimiento()
                                    break
                               

def irArriba():
    global tiempoDeInicio, comienza, cantidadDeEnergia, movErroneos, movEmpuja, movNormal,numeroDeVirus
    global movAnt,puntosAnt,lugarVirusX,lugarVirusY,lugarJugadorX,lugarJugadorY,NumeroDeMovimientos, ultimoMov
    global nuevoLugarJugadorX,nuevoLugarJugadorY,nuevoLugarVirusX,nuevoLugarVirusY
    global movNormal, movEmpuja, MovErroneos

    if fin==False:
        if comienza==False:
            comienza=True
            inicializaVarBateria()
            tiempoDeInicio=pygame.time.get_ticks()
        for i in range(1,cantidadDeCasillasPorLado):
            for j in range(1,cantidadDeCasillasPorLado):
                if (zonaDeTransporte[i][j]=='jugador'):
                    if (zonaDeTransporte[i][j-1]==0):
                        posicionarElemento('jugador',i,j-1)
                        borrarElemento(i,j)
                        
                        
                        if cantidadDeEnergia<10 or movNormal==0:
                            break
                        else:
                            cantidadDeEnergia-=10
                            movNormal-=1
                            ultimoMov='Normal'

                        lugarJugadorX=i
                        lugarJugadorY=j
                        nuevoLugarJugadorX=i
                        nuevoLugarJugadorY=j-1  
              
                        movimiento()
                        break
                    if(zonaDeTransporte[i][j-1]=='virus1' or zonaDeTransporte[i][j-1]=='virus2' or zonaDeTransporte[i][j-1]=='virus3' or zonaDeTransporte[i][j-1]=='virus4' or zonaDeTransporte[i][j-1]=='virus5'):
                        numeroDeVirus=zonaDeTransporte[i][j-1]
                        if (zonaDeTransporte[i][j-2]!=0):
                           if movErroneos==0 or cantidadDeEnergia<200:
                                break
                           else:
                                cantidadDeEnergia-=200
                                movErroneos-=1
                                ultimoMov='Erroneo'
                        else:
                           if cantidadDeEnergia<15 or movEmpuja ==0:
                                break
                           else:
                                 cantidadDeEnergia-=15
                                 movEmpuja-=1
                                 ultimoMov='Empuja'
                        lugarJugadorX=i
                        lugarJugadorY=j
                        nuevoLugarJugadorX=i
                        nuevoLugarJugadorY=j-1
                        lugarVirusX=i
                        lugarVirusY=j-1
                        nuevoLugarVirusX=i
                        nuevoLugarVirusY=j-2
                        if (zonaDeTransporte[i][j-1]=='virus1'):
                           if (zonaDeTransporte[i][j-2]==0):                               
                                borrarElemento(i,j)
                                posicionarElemento('virus1',i,j-2)
                                posicionarElemento('jugador',i,j-1)
                                movimiento()
                                break
                        if (zonaDeTransporte[i][j-1]=='virus2'):
                           if (zonaDeTransporte[i][j-2]==0):
                                borrarElemento(i,j)
                                posicionarElemento('virus2',i,j-2)
                                posicionarElemento('jugador',i,j-1)
                                movimiento()
                                break
                        if (zonaDeTransporte[i][j-1]=='virus3'):
                           if (zonaDeTransporte[i][j-2]==0):
                                borrarElemento(i,j)
                                posicionarElemento('virus3',i,j-2)
                                posicionarElemento('jugador',i,j-1)
                                movimiento()
                                break
                        if (zonaDeTransporte[i][j-1]=='virus4'):
                           if (zonaDeTransporte[i][j-2]==0):
                                borrarElemento(i,j)
                                posicionarElemento('virus4',i,j-2)
                                posicionarElemento('jugador',i,j-1)
                                movimiento()
                                break
                        if (zonaDeTransporte[i][j-1]=='virus5'):
                           if (zonaDeTransporte[i][j-2]==0):
                                borrarElemento(i,j)
                                posicionarElemento('virus5',i,j-2)
                                posicionarElemento('jugador',i,j-1)
                                movimiento()
                                break


                            
def irAbajo():
    global tiempoDeInicio, comienza, cantidadDeEnergia, movErroneos, movEmpuja, movNormal,numeroDeVirus
    global movAnt,puntosAnt,lugarVirusX,lugarVirusY,lugarJugadorX,lugarJugadorY,NumeroDeMovimientos, ultimoMov
    global nuevoLugarJugadorX,nuevoLugarJugadorY,nuevoLugarVirusX,nuevoLugarVirusY
    global movNormal, movEmpuja, MovErroneos

    if fin==False:
        if comienza==False:
            comienza=True
            inicializaVarBateria()
            tiempoDeInicio=pygame.time.get_ticks()
        for i in range(1,cantidadDeCasillasPorLado):
            for j in range(1,cantidadDeCasillasPorLado):
                if (zonaDeTransporte[i][j]=='jugador'):
                    if (zonaDeTransporte[i][j+1]==0):
                        posicionarElemento('jugador',i,j+1)
                        borrarElemento(i,j)
                        if cantidadDeEnergia<10 or movNormal==0:
                            break
                        else:
                            cantidadDeEnergia-=10
                            movNormal-=1
                            ultimoMov='Normal'
                        lugarJugadorX=i
                        lugarJugadorY=j
                        nuevoLugarJugadorX=i
                        nuevoLugarJugadorY=j+1
                         
                        movimiento()
                       
                        break

                    if(zonaDeTransporte[i][j+1]=='virus1' or zonaDeTransporte[i][j+1]=='virus2' or zonaDeTransporte[i][j+1]=='virus3' or zonaDeTransporte[i][j+1]=='virus4' or zonaDeTransporte[i][j+1]=='virus5'  ):
                        numeroDeVirus=zonaDeTransporte[i][j+1]
                        if (zonaDeTransporte[i][j+2]!=0):
                            if movErroneos==0 or cantidadDeEnergia<200:
                                break
                            else:
                                cantidadDeEnergia-=200
                                movErroneos-=1
                                ultimoMov='Erroneo'
                        else:
                            if cantidadDeEnergia<15 or movEmpuja ==0:
                                break
                            else:
                                 cantidadDeEnergia-=15
                                 movEmpuja-=1
                                 ultimoMov='Empuja'

                        lugarJugadorX=i
                        lugarJugadorY=j
                        nuevoLugarJugadorX=i
                        nuevoLugarJugadorY=j+1
                        lugarVirusX=i
                        lugarVirusY=j+1
                        nuevoLugarVirusX=i
                        nuevoLugarVirusY=j+2        
                        if (zonaDeTransporte[i][j+1]=='virus1'):
                            if (zonaDeTransporte[i][j+2]==0):
                                borrarElemento(i,j)
                                posicionarElemento('virus1',i,j+2)
                                posicionarElemento('jugador',i,j+1)
                                movimiento()
                                break
                                
                        if (zonaDeTransporte[i][j+1]=='virus2'):
                            if (zonaDeTransporte[i][j+2]==0):
                                borrarElemento(i,j)
                                posicionarElemento('virus2',i,j+2)
                                posicionarElemento('jugador',i,j+1)
                                movimiento()
                                break
                        if (zonaDeTransporte[i][j+1]=='virus3'):
                            if (zonaDeTransporte[i][j+2]==0):
                                borrarElemento(i,j)
                                posicionarElemento('virus3',i,j+2)
                                posicionarElemento('jugador',i,j+1)
                                movimiento()
                                break
                           
                        if (zonaDeTransporte[i][j+1]=='virus4'):
                            if (zonaDeTransporte[i][j+2]==0):
                                borrarElemento(i,j)
                                posicionarElemento('virus4',i,j+2)
                                posicionarElemento('jugador',i,j+1)
                                movimiento()
                                break
                        if (zonaDeTransporte[i][j+1]=='virus5'):
                            if (zonaDeTransporte[i][j+2]==0):
                                borrarElemento(i,j)
                                posicionarElemento('virus5',i,j+2)
                                posicionarElemento('jugador',i,j+1)
                                movimiento()
                                break
     
            
#Reproduce la m�sica durante todo el juego
pygame.mixer.music.play(-1,0.0)

#Crea el bucle principal del juego
while not salirJuego:

    # Controla que no haya ganado el juego, se usa para que aparezca el cartel con consejos al final el juego
    if dibujaCuriosidades==False:
        reinciar=False
        if comienza==True:
             # A la variable tiempo le asigna el tiempo transcurrido _
             # menos el tiempo que pas� antes de comenzar con el juego
             time=pygame.time.get_ticks()-tiempoDeInicio
             time=time/1000
             tiempoEntreMov=time-ultimoSegundo
             if tiempoEntreMov>15:
                 tipoReinicio='REINICIO'
                 reiniciar=True
                 
             # Cartel de tiempo transcurrido desde que se inici� el juego
             x=1110
             y=140
             ancho=225
             alto=46
             # Controla si no pas� el tiempo l�mite (120 segundos)
             if time<121:
                textTime = tipografia.render('Tiempo transcurrido:   '+str(time), False, colorBlanco)
                pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
                pantalla.blit(textTime,(x+5,y,ancho,alto))
                pygame.display.update()
                 

             # Cartel de bater�a restante y movimientos restantes
             x=1110
             y=260
             ancho=225
             alto=46
             textBateria = tipografia.render('Bater�a restante:   '+str(cantidadDeEnergia), False, colorBlanco)
             pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
             pantalla.blit(textBateria,(x+5,y,ancho,alto))
             pygame.display.update()
             x=1080
             y=300
             ancho=265
             alto=110
             pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
             textBateria = tipografia.render('Movimientos Restantes   ', False, colorBlanco)
             pantalla.blit(textBateria,(x+5,y+6,ancho,alto))
             textBateria = tipografia.render(' Normales Empujando Err�neos', False, colorBlanco)
             pantalla.blit(textBateria,(x+5,y+40,ancho,alto))
             textBateria = tipografia.render(str(movNormal)+'               '+str(movEmpuja)+'              '+str(movErroneos), False, colorBlanco)
             pantalla.blit(textBateria,(x+10,y+80,ancho,alto))
             pygame.display.update()
             
             if etapa==1:
                # A los 40 segundos del juego crea un nuevo virus y lo guarda como virus2
                if time==40 and cantVirus==1:
                        cantVirus=2
                        n=random.randint(3,6)
                        j=random.randint(3,6)
                        mismolugar=True
                        Nivel=2
                        nivel()
                        
                        imgAmenaza2=pygame.image.load(random.choice(listaAmenazas))
                        imgAmenaza2=pygame.transform.scale(imgAmenaza2,(cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla))
                        while mismolugar==True:
                            if zonaDeTransporte[n][j]=='jugador'  or zonaDeTransporte[n][j]=='virus1' or zonaDeTransporte[n][j]=='virus3':
                                n=random.randint(3,6)
                                j=random.randint(3,6)
                            
                            else :
                                mismolugar=False

                        posicionarElemento('virus2',n,j)
                        
                        pantalla.blit(imgAmenaza2,(cantPixelesPorLadoCasilla*n,cantPixelesPorLadoCasilla*j))

                # A los 80 segundos del juego crea un nuevo virus y lo guarda como virus3
                if time==80 and cantVirus==2:
                        cantVirus=3
                        n=random.randint(3,6)
                        j=random.randint(3,6)
                        mismolugar=True
                        Nivel=3
                        nivel()
                        imgAmenaza3=pygame.image.load(random.choice(listaAmenazas))
                        imgAmenaza3=pygame.transform.scale(imgAmenaza3,(cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla))
                        while mismolugar==True:
                            if zonaDeTransporte[n][j]=='jugador' or zonaDeTransporte[n][j]=='virus1' or zonaDeTransporte[n][j]=='virus2':
                                n=random.randint(3,6)
                                j=random.randint(3,6)
                            
                            else :
                                mismolugar=False

                        posicionarElemento('virus3',n,j)
                        
                        pantalla.blit(imgAmenaza3,(cantPixelesPorLadoCasilla*n,cantPixelesPorLadoCasilla*j))
                        
             # Si se cumpli� el tiempo (120 segundos) y no se juntaron la cantidad de virus necesarios el juego se reinicia
             if cantVirusSobreTomas<20 and time >120:
                x=40
                y=3
                ancho=450
                alto=46
                txtcantVirusSobreTomas = tipografiaModoJuego.render('Tu computadora ha sido infectada', False, colorBlanco)
                tipoReinicio='SinTiempo'
                reiniciar=True
                pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
                pantalla.blit(txtcantVirusSobreTomas,(x+5,y,ancho,alto))
                pygame.display.update()
                pygame.time.delay(2000)
             # Controla si la tablet a�n tiene energ�a
             if cantidadDeEnergia<10:
                    # Se qued� sin bater�a, se reinicia el Nivel
                    # Se coloca la variable comienza en False para que al realizar el_
                    # primer movimiento inicialicen todas las dem�s variables
                tipoReinicio='SinBateria'
                reiniciar=True
             
        for event in pygame.event.get():
             if event.type == pygame.QUIT:
                pygame.display.quit()
                pygame.quit()
                salirJuego = True
             if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                     irALaDerecha()
                     ultimoSegundo=time
                elif event.key == pygame.K_LEFT:
                    irALaIzquierda()
                    ultimoSegundo=time
                elif event.key == pygame.K_UP:
                    irArriba()
                    ultimoSegundo=time
                elif event.key == pygame.K_DOWN:
                    irAbajo()
                    ultimoSegundo=time
                elif event.key == pygame.K_x:
                    if comienza==True:
                        deshacer()
                elif event.key== pygame.K_r:
                    tipoReinicio='REINICIO'
                    reiniciar=True

        # Si entro por reiniciar es porque, se qued� sin bater�a, sin tiempo o porque presion� la tecla R
        if reiniciar==True:
            reiniciar=False    # Variable que controla que lo haga una sola vez
            # Se reinician las variables
            NumeroDeMovimientos=0
            time=0
            comienza=False
            tiempoDeInicio=0
            cantVirusSobreTomas=0
            cantVirus=1
            nivelCompletado=False
            Nivel=1
            comienza=False
            inicializaVarBateria()
            zonaProtegidaUsada1=False
            zonaProtegidaUsada2=False
            zonaProtegidaUsada3=False
            zonaProtegidaUsada4=False
            zonaProtegidaUsada5=False
            # Cartel de Reinicio de juego
            x=40
            y=40
            ancho=450
            alto=46
            
            if tipoReinicio=='SinBateria':
                etapaEspecial=False
                textoReinicio = tipografiaModoJuego.render('Sin bater�a. Se reinicia el juego', False, colorBlanco)
                if etapa==2:
                    # Se borran las zonas protegidas, para que no se dupliquen, antes de volver a crear la zona de juego
                    lstZonasProtegidas.remove((2,4))
                    lstZonasProtegidas.remove((2,6))
                    lstZonasProtegidas.remove((7,4))
                    lstZonasProtegidas.remove((7,6))
                    lstZonasProtegidas.remove((4,6))
                    etapa=1
                else:
                    # Se borran las zonas protegidas, para que no se dupliquen, antes de volver a crear la zona de juego
                    lstZonasProtegidas.remove((2,2))
                    lstZonasProtegidas.remove((7,2))
                    lstZonasProtegidas.remove((2,7))
                    lstZonasProtegidas.remove((7,7))
                zonaDeTransporte=crearZonaDeTransporte1()
                dibujarTodo()
                pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
                pantalla.blit(textoReinicio,(x+5,y,ancho,alto))
                
            elif tipoReinicio=='SinTiempo':
                etapaEspecial=False
                textoReinicio = tipografiaModoJuego.render('Sin tiempo. Se reinicia el juego', False, colorBlanco)
                if etapa==2:
                    # Se borran las zonas protegidas, para que no se dupliquen, antes de volver a crear la zona de juego
                    lstZonasProtegidas.remove((2,4))
                    lstZonasProtegidas.remove((2,6))
                    lstZonasProtegidas.remove((7,4))
                    lstZonasProtegidas.remove((7,6))
                    lstZonasProtegidas.remove((4,6))
                    etapa=1

                else:
                    # Se borran las zonas protegidas, para que no se dupliquen, antes de volver a crear la zona de juego
                    lstZonasProtegidas.remove((2,2))
                    lstZonasProtegidas.remove((7,2))
                    lstZonasProtegidas.remove((2,7))
                    lstZonasProtegidas.remove((7,7))
                zonaDeTransporte=crearZonaDeTransporte1()
                dibujarTodo()
                pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
                pantalla.blit(textoReinicio,(x+5,y,ancho,alto))
                pygame.display.update()

            elif tipoReinicio=='REINICIO' and etapa==1:
                # Antes de reiniciar se borran las zonas protegidas, para que no se dupliquen
                lstZonasProtegidas.remove((2,2))
                lstZonasProtegidas.remove((7,2))
                lstZonasProtegidas.remove((2,7))
                lstZonasProtegidas.remove((7,7))
                textoReinicio = tipografiaModoJuego.render('Se reinicia el Modo F�cil', False, colorBlanco)
                zonaDeTransporte=crearZonaDeTransporte1()
                dibujarTodo()
                pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
                pantalla.blit(textoReinicio,(x+5,y,ancho,alto))
                
            elif tipoReinicio=='REINICIO' and etapa==2 and etapaEspecial==False:
                # Antes de reiniciar se borran las zonas protegidas, para que no se dupliquen
                lstZonasProtegidas.remove((2,4))
                lstZonasProtegidas.remove((2,6))
                lstZonasProtegidas.remove((7,4))
                lstZonasProtegidas.remove((7,6))
                lstZonasProtegidas.remove((4,6))
                zonaDeTransporte=crearZonaDeTransporte2()
                dibujarTodo()
                textoReinicio = tipografiaModoJuego.render('Se reinicia el Modo Dif�cil', False, colorBlanco)
                pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
                pantalla.blit(textoReinicio,(x+5,y,ancho,alto))
            elif tipoReinicio=='REINICIO' and etapaEspecial==True:
                # Antes de reiniciar se borran las zonas protegidas, para que no se dupliquen
                lstZonasProtegidas.remove((2,2))
                lstZonasProtegidas.remove((7,2))
                lstZonasProtegidas.remove((7,5))
                lstZonasProtegidas.remove((7,7))
                lstZonasProtegidas.remove((2,7))
                zonaDeTransporte=crearZonaDeTransporte3()
                dibujarTodo()
                textoReinicio = tipografiaModoJuego.render('Se reinicia el Modo Especial', False, colorBlanco)
                pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
                pantalla.blit(textoReinicio,(x+5,y,ancho,alto))

            x=1110
            y=220
            ancho=225
            alto=46        
            textoNumDeMov = tipografia.render('Nro de Movimientos:   '+str(NumeroDeMovimientos), False, colorBlanco)
            
            pygame.draw.rect(pantalla,colorAzul,(x,y,ancho,alto))
            pantalla.blit(textoNumDeMov,(x+5,y,ancho,alto))
            pygame.display.update()


        dibujarZonaDeTransporte()
        estaSolucionado()
        #si los puntos son mayores a 20 el nivel fue completado 
        if (cantVirusSobreTomas>=20) and (tipoReinicio == 'MODODIFICIL'):
            tipoReinicio=''   # A esta variable la vac�o para que no siga entrando al if
            # Llama a funci�n que coloca las variables en 0
            subeModo()
            zonaDeTransporte=crearZonaDeTransporte2()
            dibujarTodo()
            dibujarZonaDeTransporte()
        if (cantVirusSobreTomas>=5) and (tipoReinicio == 'MODOESPECIAL'):
            tipoReinicio=''
            NumeroDeMovimientos=0
            time=0
            comienza=False
            tiempoDeInicio=0
            cantVirusSobreTomas=0
            cantVirus=1
            nivelCompletado=False
            Nivel=1
            comienza=False
            inicializaVarBateria()
            zonaProtegidaUsada1=False
            zonaProtegidaUsada2=False
            zonaProtegidaUsada3=False
            zonaProtegidaUsada4=False
            zonaProtegidaUsada5=False
            # Debe borrar las zonas protegidas del modo dificil
            lstZonasProtegidas.remove((2,4))
            lstZonasProtegidas.remove((2,6))
            lstZonasProtegidas.remove((7,4))
            lstZonasProtegidas.remove((7,6))
            lstZonasProtegidas.remove((4,6))
    
            zonaDeTransporte=crearZonaDeTransporte3()   #Llama a la funci�n para crear la nueva etapa (etapa especial) 
            dibujarTodo()
            dibujarZonaDeTransporte()
     
        
    else:
        if consejos==False:
            consejos=True
            dibujarCuriosidades()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.display.quit()
                pygame.quit()
                salirJuego = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:          # Presion� la tecla espacio, cierra el juego
                    ancho=90000
                    alto=90000
                    x=0
                    y=3
                pygame.draw.rect(pantalla,colorVerde,(x,y,ancho,alto))
                # Ponemos textos e im�genes como creditos
                textoCuriosidades = tipografiaConsejos.render('Juego creado por:', False, colorBlanco)
                pantalla.blit(textoCuriosidades,(x+40,y+160,ancho,alto))
                textoCuriosidades = tipografiaConsejos.render("Angel Cruz, Camilo Zalazar, Lautaro Cordoba" ,False, colorBlanco)
                pantalla.blit(textoCuriosidades,(x+40,y+200,ancho,alto))
                textoCuriosidades = tipografiaConsejos.render("Ayuda proporcionada por:" ,False, colorBlanco)
                pantalla.blit(textoCuriosidades,(x+40,y+240,ancho,alto))
                textoCuriosidades = tipografiaConsejos.render("Juliana Carrano" ,False, colorBlanco)
                pantalla.blit(textoCuriosidades,(x+40,y+280,ancho,alto))
                textoCuriosidades = tipografiaConsejos.render("BIEN HECHO TU PC ESTA A SALVO!!!" ,False, colorNegro)
                pantalla.blit(textoCuriosidades,(x+40,y+320,ancho,alto))
                textoCuriosidades = tipografiaConsejos.render("Presiona la tecla escape para salir" ,False, colorNegro)
                pantalla.blit(textoCuriosidades,(x+40,y+380,ancho,alto))
                textoCuriosidades = tipografiaConsejos.render("Equipo InduTec" ,False, colorNegro)
                pantalla.blit(textoCuriosidades,(x+900,y+540,ancho,alto))
                imgTablet=pygame.image.load("angel camilo y lauti.jpg")
                imgTablet=pygame.transform.scale(imgTablet, (600,400))
                pantalla.blit(imgTablet,(x+700,y+140,ancho,alto))
                
                pygame.display.update()
                if event.key == pygame.K_ESCAPE:
                    pygame.display.quit()
                    pygame.quit()
                    salirJuego = True
    
quit()
