
#-*- coding: utf-8 -*-
import csv    # este módulo permite abrir textos separados por parámetros

def mOrdenaTxt(archivo, separador):
    column = []
    # abro el txt como un archivo con separaciones, en nuestro caso son las ","
    with open(archivo,"r") as csvfile:
        # establezco que se separe con la ","
        reader = csv.reader(csvfile,delimiter=separador)
        for row in reader:
            # guardo primero el nro y despues el nombre, para ordenarlo por nro
            column.append((int(row[1]),str(row[0])))
    # invierto el orden para que sea descendente     
    column.sort(reverse = True)
    return column
 

def mBuscaJugador(jugador):

    # abrimos el archivo solo de lectura
    f = open("Jugador y puntaje.txt","r")
    # Creamos una lista con cada una de sus lineas
    lineas = f.readlines()
    jugador=jugador+ ','
    lineaAnterior=''

    for linea in lineas:

        busca=linea
        x=busca.rfind(jugador)
        if x!=-1:
            #lineaAnterior= linea
            lineaAnterior=str(linea)
            
            pass

    # cerramos el archivo
    f.close()
    return lineaAnterior

def mActualizaPuntaje(jugador, puntaje, lineaAnterior, archivo):
    # abrimos el archivo solo de lectura
    f = open(archivo,"r")
     
    # Creamos una lista con cada una de sus lineas
    lineas = f.readlines()
    f.close()
    
    # abrimos el archivo pero vacio
    f = open(archivo,"w")

    lineaNueva=jugador+ ', '+str(puntaje)
    print lineaNueva
    print lineaAnterior
     
    # recorremos todas las lineas
    for linea in lineas:
     
        # miramos si el contenido de la linea es diferente a la linea a eliminar
        # añadimos al final \n que es el salto de linea
        if linea!=lineaAnterior:
     
            # Si no es la linea que queremos eliminar, guardamos la linea en el archivo
            f.write(linea)
        else:
            f.write(lineaNueva+"\n")
     
    # cerramos el archivo
    f.close()
    return lineaNueva
