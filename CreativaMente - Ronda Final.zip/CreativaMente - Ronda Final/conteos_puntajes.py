#!/usr/bin/env python
#-*- coding: ISO-8859-1 -*-

#Importamos las librer�as necesarias
import pygame
import time

puntajeTotal = 0

#Creamos una funci�n que vuelve el puntaje a cero
def reiniciarPuntaje():
    global puntajeTotal
    puntajeTotal = 0
    return puntajeTotal
    
#Creamos un contador de tiempo transcurrido
def contadorDeTiempo(tiempoInicial, comenzarTiempo):
    if comenzarTiempo == True:
        tiempoActual = time.time()
        tiempoTranscurrido= int(tiempoActual-tiempoInicial)
    else:
        tiempoTranscurrido = 0

    return tiempoTranscurrido

#Calculamos el puntaje total por nivel
def calcularPuntajeNormal(cantidadDeEnergia, tiempoTranscurrido, pedido):
    global puntajeTotal
    if tiempoTranscurrido == 0:
        tiempoTranscurrido = 1
    puntajeNivel = int(cantidadDeEnergia/tiempoTranscurrido)

    if pedido == "nivel":
        return puntajeNivel
    else:
        puntajeTotal = puntajeTotal + puntajeNivel
        return puntajeTotal

def calcularPuntajeContrarreloj():
    global puntajeTotal
    puntajeTotal = puntajeTotal + 10
    return puntajeTotal

#Guardamos el puntaje total en un archivo de texto
def guardarPuntuacion(nombreJugador, nivel):
    global jugador,puntos

    if nivel == 'Contrarreloj':
        Archivo="PuntuacionesContrarreloj.txt"
    else:
        Archivo="PuntuacionesNormal.txt"
        
    Puntuaciones= "%s, %s" % (nombreJugador,puntajeTotal) + '\n'
    
    EditorDeArchivo = open (Archivo,'a')
    EditorDeArchivo.write(Puntuaciones)
    EditorDeArchivo.close()

    jugador = []
    puntos = []
    leer_datos(Archivo)

    ordenarPuntajes(Archivo)

#Leemos el archivo y colocamos los datos en distintos campos (ayuda a ordenar)
def leer_datos(nombrearchivo):
    global jugador, puntos
    archivo = open(nombrearchivo,'r')
    registros = archivo.read().split('\n')
    for linea in registros:
        campos=linea.split(', ')
        if campos<>['']:
            jugador.append(campos[0])
            puntos.append(campos[1])
    archivo.close()

#Ordenamos los puntajes en los archivos, de mayor a menor puntaje
def ordenarPuntajes(Archivo):
    global jugador,puntos
    n=len(puntos)
    for i in range (n-1):
        for j in range (i+1,n):
            if (int(puntos[i])<int(puntos[j])) or (int(puntos[i])==int(puntos[j])):
                puntos[i],puntos[j]=puntos[j],puntos[i]
                jugador[i],jugador[j]=jugador[j],jugador[i]
    archivo = open(Archivo, 'w')
    for i in range (n):
        archivo.write("%s, %s" % (jugador[i],puntos[i]) + "\n")
