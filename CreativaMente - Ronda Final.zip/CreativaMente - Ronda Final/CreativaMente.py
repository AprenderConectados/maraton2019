#!/usr/bin/env python
#-*- coding: ISO-8859-1 -*-

"""Inicio Ronda Final - Maraton Nacional de Programaci�n y Rob�tica 2019
EQUIPO "CreativaMente"
Integrantes: BENEGAS CATALINA - NICOLINO RODRIGO - TORRES SANTIAGO
IPEM 299 Dr. Spirid�n E. Naumchik - Almafuerte - C�rdoba

El juego consiste en ayudar a la Nave Binaria piloteada por S�per Tablet a resolver 5 desaf�os
para proteger su computadora de posibles amenazas digitales llev�ndolas a zonas seguras.
Adem�s cuenta con un modo contrarreloj en el que se pone a prueba la rapidez del jugador"""


#Las siguientes librer�as deben estar instaladas junto a Python 2.7.13 para que el c�digo se ejecute.
import os
import pygame
import random
import time

#Llamamos a los m�dulos necesarios para la ejecuci�n del programa.
from detectarSistema import * #M�dulo que detecta el sistema en el cual se ejecuta el juego.
from cargarMultimedia import *#M�dulo que carga im�genes y sonido.
from conteos_puntajes import *#M�dulo que maneja contadores y puntajes.
from pedirNombre import * #M�dulo que genera la ventana para registrar el nombre del jugador.
from menu import * #M�dulo que visualiza el men� principal.

#Inicializamos la librer�a Pygame.
pygame.init()
pygame.mixer.init()
pygame.font.init() 

#Ponemos el nombre a la ventana principal.
pygame.display.set_caption("CreativaMente - MARATON NACIONAL DE PROGRAMACION - Ronda Final")

#Centramos la primer pantalla, y tomamos su alto y su ancho.
os.environ["SDL_VIDEO_CENTERED"] = "1" 

pantalla = pygame.display.set_mode((855,480),pygame.NOFRAME)
anchopantalla = pantalla.get_width()
altopantalla = pantalla.get_height()

#Inicializamos el resto de las variables.
tipografiaChica = pygame.font.SysFont('Comic Sans MS', 18)
tipografiaMediana=pygame.font.SysFont('Comic Sans MS', 26)
tipografiaGrande=pygame.font.SysFont('Comic Sans MS', 32)

colorVerdeClaro,colorVerdeOsc= (32,232,51),(30,114,37)
colorCelesteClaro,colorCelesteOsc= (37,217,230),(32,170,179)
colorAzulClaro,colorAzulOsc= (0,130,255),(0,0,255)
colorBlanco,colorNegro= (255,255,255),(0,0,0)
colorNaranjaClaro,colorNaranjaOsc= (237,135,34),(246,116,44)
colorRojo=(255,0,0)
colorVioleta=(220, 55, 237)
colorCeleste=(81, 209,246)
colorAmarillo=(255,255,0)
colorVerdeBrillante=(57,255,20)

coloresCartel=[colorRojo,colorVioleta,colorCeleste,colorNaranjaClaro,colorAmarillo,colorVerdeBrillante,colorAzulClaro]

cantidadDeCasillasPorLado=8
cantPixelesPorLadoCasilla=72
salirJuego = False
instrucciones = False
info = False
Presentador=True
nivelCompletado = False
perdiste = False
finJuego = False
jugando = False

volumen = True
haSonado = False

contadoresIniciados=False
tiempoInicial = 0
tiempoOcioso = 0
tiempoContrarreloj = 40

colorActual = random.choice(coloresCartel)
colorAnterior = colorActual

cantidadDePasos = 0
cantidadDeEnergia = 7000
EnergiaInicial = 7000
comenzarTiempo = False
puntajeObtenido=False
permiteDeshacer=False

tecla_r = False

guardado = False

nivel = -1
JugadorPosicionado = False

#Redimensionamos algunas de las im�genes del m�dulo cargarMultimedia.
imgPared=pygame.transform.scale(imgPared, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
imgAreaProtegida=pygame.transform.scale(imgAreaProtegida, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
reloj = pygame.transform.scale(reloj, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))


#Creamos el mapa del nivel que corresponda y algunas funciones para los elementos que se encuentran dentro de la zona de transporte
def crearZonaDeTransporte():
    global lstZonasProtegidas, imgAmenaza, imgNaveBinaria, JugadorPosicionado, JugadorPosterior

    if nivel == 1:
        imgAmenaza = pygame.image.load(listaAmenazas[0])
    else:
        imgAmenaza=pygame.image.load(str(random.choice(listaAmenazas)))
        
    imgAmenaza=pygame.transform.scale(imgAmenaza, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
    if JugadorPosicionado == False:
        imgNaveBinaria=ImgJugador("Imagenes/navebinariaDer.png")

    lstZonasProtegidas=[]
    
    zonaDeTransporte = [[0 for x in range(cantidadDeCasillasPorLado+1)] for y in range(cantidadDeCasillasPorLado+1)] 
    
    if nivel == 1 or nivel == 2 or nivel == 4 or nivel == 'Contrarreloj':
        for i in range(1,cantidadDeCasillasPorLado+1):
            zonaDeTransporte[i][1] = 'pared'  
            zonaDeTransporte[i][cantidadDeCasillasPorLado] = 'pared'   
            zonaDeTransporte[1][i] = 'pared'  
            zonaDeTransporte[cantidadDeCasillasPorLado][i] = 'pared'   
            
        if nivel == 1:
            zonaDeTransporte[3][4] = 'jugador'
            zonaDeTransporte[5][4] = 'virus'

            lstZonasProtegidas.append((7,4))
            
        if nivel == 2:
            zonaDeTransporte[2][4] = 'jugador'

            zonaDeTransporte[4][3] = 'virus'
            zonaDeTransporte[5][3] = 'virus'
            zonaDeTransporte[4][6] = 'virus'
            zonaDeTransporte[5][6] = 'virus'

            lstZonasProtegidas.append((2,2))
            lstZonasProtegidas.append((2,7))
            lstZonasProtegidas.append((7,2))
            lstZonasProtegidas.append((7,7))

        if nivel == 4:
            for i in range(4,6):
                zonaDeTransporte[i][3] = 'pared'
                zonaDeTransporte[i][2] = 'pared'
                zonaDeTransporte[i][5] = 'pared'
                zonaDeTransporte[i][7] = 'pared'			
	    
            zonaDeTransporte[2][7] = 'jugador'
	    
            zonaDeTransporte[3][4] = 'virus'      
            zonaDeTransporte[5][6] = 'virus'      
            zonaDeTransporte[3][6] = 'virus'      
            zonaDeTransporte[6][4] = 'virus'      
                        
            lstZonasProtegidas.append((3,7))
            lstZonasProtegidas.append((4,6))
            lstZonasProtegidas.append((6,2))
            lstZonasProtegidas.append((7,7))

        if nivel == 'Contrarreloj':
            PosVirus = [3,4,5,6]
            ZonasPosibles = []
    
            for i in range(2,cantidadDeCasillasPorLado-2):
                ZonasPosibles.append((i,2))
                ZonasPosibles.append((i,cantidadDeCasillasPorLado-1))
                ZonasPosibles.append((2,i))   
                ZonasPosibles.append((cantidadDeCasillasPorLado-1,i))
            
            xVirus = (int(random.choice(PosVirus)))
            yVirus = (int(random.choice(PosVirus)))
            ZonasPosibles = (random.choice(ZonasPosibles))

            if JugadorPosicionado == False:
                zonaDeTransporte[5][7] = 'jugador'
                JugadorPosterior = [5,7]
                JugadorPosicionado=True
            else:
                while (xVirus == JugadorPosterior[0]) and (yVirus == JugadorPosterior[1]):
                    xVirus = (int(random.choice(PosVirus)))
                    yVirus = (int(random.choice(PosVirus)))

            zonaDeTransporte[xVirus][yVirus] = 'virus'
            lstZonasProtegidas.append(ZonasPosibles)
            
    else:
        if nivel == 3:
            for i in range (1,cantidadDeCasillasPorLado+1):
                zonaDeTransporte[i][3] = 'pared'
                zonaDeTransporte[i][7] = 'pared'

            for i in range (4,7):
                zonaDeTransporte[1][i] = 'pared'
                zonaDeTransporte[8][i] = 'pared'

            zonaDeTransporte[2][5] = 'jugador'

            zonaDeTransporte[3][5] = 'virus'      
            zonaDeTransporte[4][5] = 'virus'    
            zonaDeTransporte[5][5] = 'virus'    
            zonaDeTransporte[6][5] = 'virus' 
            zonaDeTransporte[5][6] = 'virus'  

            lstZonasProtegidas.append((2,4))
            lstZonasProtegidas.append((2,6))
            lstZonasProtegidas.append((7,4))
            lstZonasProtegidas.append((7,6))
            lstZonasProtegidas.append((4,6))

        if nivel == 5:
            for i in range (3,6):
                zonaDeTransporte[i][8] = 'pared'      
                zonaDeTransporte[8][i] = 'pared'
        
            zonaDeTransporte[2][7] = 'pared'      
            zonaDeTransporte[3][7] = 'pared'    
            zonaDeTransporte[6][7] = 'pared'    
            zonaDeTransporte[7][6] = 'pared'
            zonaDeTransporte[7][3] = 'pared'
            zonaDeTransporte[7][2] = 'pared'
            zonaDeTransporte[4][4] = 'pared'
            zonaDeTransporte[2][2] = 'pared'
            zonaDeTransporte[3][2] = 'pared' 
            zonaDeTransporte[7][7] = 'pared'

            for i in range (3,7):
                zonaDeTransporte[i][1] = 'pared'      

            for i in range (2,7):
                zonaDeTransporte[1][i] = 'pared'

            zonaDeTransporte[4][5] = 'pared'  

            zonaDeTransporte[5][7] = 'jugador'

            zonaDeTransporte[3][3] = 'virus'      
            zonaDeTransporte[5][6] = 'virus'    
            zonaDeTransporte[5][5] = 'virus'    

            lstZonasProtegidas.append((2,6))
            lstZonasProtegidas.append((7,5))
            lstZonasProtegidas.append((5,3))

    return zonaDeTransporte


def hayZonaProtegidaEn(x,y):
    punto=(x,y)
    return lstZonasProtegidas.__contains__(punto)

def posicionarElemento(elemento,x,y):
    zonaDeTransporte[x][y]=elemento

def borrarElemento(x,y):
    zonaDeTransporte[x][y]=0


#Generamos la imagen del jugador
def ImgJugador(imagen):
    imgNaveBinaria=pygame.image.load(imagen)
    imgNaveBinaria=pygame.transform.scale(imgNaveBinaria, (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))

    return imgNaveBinaria

        
#Generamos una funci�n que dibuja un fondo seg�n el valor que le asignemos.
def dibujarFondo(imagen):
    fondo = pygame.image.load(imagen)
    fondo = pygame.transform.scale(fondo, (anchopantalla, altopantalla))
    pantalla.blit(fondo, (0, 0))

#Le asignamos una imagen a dibujarFondo para que la muestre en la pantalla inicial.
def dibujarPantallaInicial():
    dibujarFondo("Imagenes/fondoinicial.png")
    pygame.display.update()

#Dibuja la zona del juego seg�n lo indica la variable zonaDeTransporte.
def dibujarZonaDeTransporte():
    cnt = 0
    for i in range(1,cantidadDeCasillasPorLado+1):
        for j in range(1,cantidadDeCasillasPorLado+1):
            if cnt % 2 == 0:
                pygame.draw.rect(pantalla, colorNegro,[cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])
            else:
                pygame.draw.rect(pantalla, colorNegro, [cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i,cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla])        

            if (hayZonaProtegidaEn(j,i)==True):
                pantalla.blit(imgAreaProtegida, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
            if (zonaDeTransporte[j][i]=='virus'):
                pantalla.blit(imgAmenaza, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))
            
            if (zonaDeTransporte[j][i]=='jugador'):
               pantalla.blit(imgNaveBinaria, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i)) 
            if (zonaDeTransporte[j][i]=='pared'):          
               pantalla.blit(imgPared, (cantPixelesPorLadoCasilla*j,cantPixelesPorLadoCasilla*i))

            cnt +=1
        cnt-=1

    pygame.draw.rect(pantalla,colorBlanco,[cantPixelesPorLadoCasilla,cantPixelesPorLadoCasilla,cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla,cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla],1)       
    pygame.display.update()

#Mostramos en pantalla el logo de la Ronda Final de CreativaMente.
def dibujarLogo(x,y,ancho,alto):
    global Logo
    Logo = pygame.transform.scale(LogoCM,(ancho,alto))
    pantalla.blit(Logo, (x,y))        
    pygame.display.update()

#Dibujamos el cartel de la Ronda Final, que cambia de color seg�n si el jugador se mueve o no.
def dibujarCartelRonda(seMovio):
    global colorActual
    ancho=184
    alto=40
    x=1067
    y=693

    if seMovio == True:
        colorActual = random.choice(coloresCartel)
        while colorActual == colorAnterior:
            colorActual = random.choice(coloresCartel)
    
    pygame.draw.rect(pantalla,colorActual,(x,y,ancho,alto))
    textoRonda = tipografiaGrande.render('Ronda Final', False, colorNegro)
    pantalla.blit(textoRonda,(x+7,y,ancho,alto))

#Mostramos en pantalla el contador de pasos de la Nave Binaria
def dibujarContadorDePasos(pasos):
    global cantidadDePasos
    cantidadDePasos=cantidadDePasos+pasos
    ancho=365
    alto=40
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=cantPixelesPorLadoCasilla*8
    pygame.draw.rect(pantalla,colorBlanco,(x,y,ancho,alto))
    textoPasos = tipografiaMediana.render('Cantidad de movimientos: ' + str(cantidadDePasos), False, colorNegro)
    pantalla.blit(textoPasos,(x+5,y,ancho,alto))
    pygame.display.update()


#Mostramos en pantalla el contador de energ�a de la Nave Binaria siempre y cuando el nivel no sea contrarreloj.
def dibujarContadorDeElectricidad(decremento):
    global cantidadDeEnergia, BateriaAntes
    if nivel != 'Contrarreloj':
        cantidadDeEnergia=cantidadDeEnergia-decremento
        if cantidadDeEnergia<1:
            cantidadDeEnergia=0   
        imgBateria=pygame.transform.scale(obtenerBateria(cantidadDeEnergia), (cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla))
        ancho=150
        alto=40
        x=500
        y=30
        pygame.draw.rect(pantalla,colorBlanco,(x,y,ancho,alto))
        textoEnergia = tipografiaMediana.render(str(cantidadDeEnergia) + 'mAh', False, colorNegro)
        pantalla.blit(textoEnergia,(x+10,y,ancho,alto))
        pantalla.blit(imgBateria,(x-(cantPixelesPorLadoCasilla+5),13))

        pygame.display.update()


#Mostramos en pantalla el contador de tiempo, que aumenta en todos los niveles, salvo en el modo contrarreloj que disminuye desde 40 segundos.
def dibujarContadorDeTiempo():
    global perdiste, nivelCompletado, comenzarTiempo, tiempoOciosoTranscurrido, tiempoTranscurrido
    if perdiste == False:
        tiempoTranscurrido=contadorDeTiempo(tiempoInicial, comenzarTiempo)
    
        ancho=200
        alto=40
        x=cantPixelesPorLadoCasilla
        y=30

        if nivel == 'Contrarreloj':
            tiempoTranscurrido=tiempoContrarreloj-tiempoTranscurrido
        else:
            tiempoOciosoTranscurrido=contadorDeTiempo(tiempoOcioso, comenzarTiempo)#El tiempoOcioso es el intervalo de tiempo entre un movimiento de la nave y otro.

        pygame.draw.rect(pantalla,colorBlanco,(x,y,ancho,alto))
        textoTiempo = tipografiaMediana.render('Tiempo: %s' % tiempoTranscurrido, False, colorNegro)
        pantalla.blit(textoTiempo,(x+5,y,ancho,alto))
        pantalla.blit(reloj, (0,0))
        pygame.display.update()

#Mostramos en pantalla el n�mero de nivel que se est� jugando.
def dibujarContadorNivel():
    if nivel == 'Contrarreloj':
        ancho=250
    else:
        ancho=150
    alto=40
    x=75+(cantidadDeCasillasPorLado*cantPixelesPorLadoCasilla)
    y=cantPixelesPorLadoCasilla*7
    pygame.draw.rect(pantalla,colorBlanco,(x,y,ancho,alto))
    textoNivel = tipografiaMediana.render('Nivel: %s' % nivel, False, colorNegro)
    pantalla.blit(textoNivel,(x+5,y,ancho,alto))
    pygame.display.update()

#Mostramos en pantalla, en el nivel contrarreloj, el puntaje que va obteniendo el jugador.
def dibujarContadorDePuntaje():
    if nivel == 'Contrarreloj':
        ancho=200
        alto=40
        x=500
        y=30

        pygame.draw.rect(pantalla,colorBlanco,(x,y,ancho,alto))
        textoPuntaje = tipografiaMediana.render('Puntaje: ' + str(puntajeTotal), False, colorNegro)
        pantalla.blit(textoPuntaje,(x+10,y,ancho,alto))
        pygame.display.update()  
    
#Inicializamos o reiniciamos los contadores.
def iniciarContadores():
    global cantidadDePasos, cantidadDeEnergia, comenzarTiempo, Presentador, JugadorPosicionado, tecla_r
    cantidadDePasos = 0
    if perdiste == True or jugando == False:
        cantidadDeEnergia = 7000
        if jugando == False:
            JugadorPosicionado = False
    elif tecla_r == True:
        cantidadDeEnergia = EnergiaInicial
        tecla_r = False
    comenzarTiempo = False
    Presentador = True
    if perdiste == False and jugando == True:
        dibujarContadores()

#Mostramos en pantalla los distintos contadores.
def dibujarContadores():
    if instrucciones != True and perdiste == False:
        dibujarContadorDePasos(0)
        dibujarContadorDeElectricidad(0)
        dibujarContadorDePuntaje()
        mejoresPuntuaciones()
        dibujarContadorNivel()
    dibujarContadorDeTiempo()


#Mostramos en pantalla, seg�n el nivel, el presentador de la informaci�n adicional.
def dibujarPresentador():
    global info, Presentador
    px = cantPixelesPorLadoCasilla
    x = px*(cantidadDeCasillasPorLado+2)
    y = px*3

    if nivel == 'Contrarreloj':
        personaje='RoBot'
    else:
        personaje='OjoCam'
        
    if Presentador == False:
        imgPresentador = pygame.image.load("Imagenes/" + str(personaje) + "NC.png")
    else:
        imgInfoextra=obtenerInfoextra(nivel)
        sonidoPresentador = pygame.mixer.Sound("Musica/" + str(personaje) + ".ogg")
        if info == False:
            PresentadorClaro = "Imagenes/" + str(personaje) + ".png"
            PresentadorOscuro = "Imagenes/" + str(personaje) + "2.png"
        else:
            PresentadorClaro = "Imagenes/" + str(personaje) + "C.png"
            PresentadorOscuro = "Imagenes/" + str(personaje) + "C2.png"

        if x+px*4 > posmouse[0] > x and y+px*4 > posmouse[1] > y:
            imgPresentador = pygame.image.load(PresentadorOscuro)
            if clic[0] == 1:
                if info == False:
                    sonidoPresentador.play()
                    pantalla.blit(imgInfoextra, (5,5))
                    info = True
                else:
                    sonidoboton.play()
                    info = False
                    dibujarTodo()
        else:
            imgPresentador = pygame.image.load(PresentadorClaro)
                
    imgPresentador = pygame.transform.scale(imgPresentador,(px*4, px*4))
    pantalla.blit(imgPresentador, (x, y))
    pygame.display.update()


#Dibujamos la ventana correspondiente con el mensaje y el bot�n que se visualiza al finalizar de nivel.
def dibujarFelicitacion():
    global nivelCompletado, haSonado
    x=341
    y=192
    ancho=683
    alto=384
    
    if (nivelCompletado==True) and (finJuego == False):
        pygame.draw.rect(pantalla,colorVerdeOsc,(x+5,y+5,ancho+5,alto+5))
        pygame.draw.rect(pantalla,colorVerdeClaro,(x,y,ancho,alto))

        if nivel == 'Contrarreloj':
            textoFelicitacion1 = tipografiaMediana.render('�Ha terminado el tiempo', False, colorBlanco)
            textoFelicitacion2 = tipografiaMediana.render('y conseguiste %s puntos!' % puntajeTotal, False, colorBlanco)
        else:
            textoFelicitacion1 = tipografiaMediana.render('�Felicitaciones, has superado el nivel %s' % nivel, False, colorBlanco)
            textoFelicitacion2 = tipografiaMediana.render('y conseguiste %s puntos!' % puntajeNivel, False, colorBlanco)
            
        if (nivel==1):
            textoFelicitacion4 = tipografiaChica.render('una computadora es cualquier m�quina que recibe instrucciones', False, colorRojo)
            textoFelicitacion5 = tipografiaChica.render('y nos ayuda a resolver tareas?', False, colorRojo)
            textoFelicitacion6 = '"Una compu por dentro"'
        elif (nivel==2):
            textoFelicitacion4 = tipografiaChica.render('tenemos que descargar archivos, juegos y videos solo desde sitios', False, colorRojo)
            textoFelicitacion5 = tipografiaChica.render('confiables para no da�ar nuestra computadora?', False, colorRojo)
            textoFelicitacion6 = '"Consejos para cuidar la compu"' 
        elif (nivel==3):
            textoFelicitacion4 = tipografiaChica.render('Internet es una gran red de computadoras de todo el mundo conectadas', False, colorRojo)
            textoFelicitacion5 = tipografiaChica.render('entre s�, y que la WWW es la cantidad de sitios que se encuentran en ella?', False, colorRojo)
            textoFelicitacion6 = '"Un viaje por el ciberespacio"' 
        elif (nivel==4):
            textoFelicitacion4 = tipografiaChica.render('No todas las p�ginas de Internet son confiables, ni lo que dicen es siempre', False, colorRojo)
            textoFelicitacion5 = tipografiaChica.render('verdad, pero que existen algunos criterios que pueden ayudarnos?', False, colorRojo)
            textoFelicitacion6 = '"El misterio de Clementina"'
        elif (nivel == 5):
            textoFelicitacion4 = tipografiaChica.render('Al crear un juego con niveles, adem�s de las reglas, podemos programar', False, colorRojo)
            textoFelicitacion5 = tipografiaChica.render('los escenarios y personajes para que cambien al pasar de nivel?', False, colorRojo)
            textoFelicitacion6 = '"El club de programadores de videojuegos"'
        elif (nivel=='Contrarreloj'):
            textoFelicitacion4 = tipografiaChica.render('Un sensor es un dispositivo que puede detectar movimientos, ruidos, segundos', False, colorRojo)
            textoFelicitacion5 = tipografiaChica.render('y cualquier otro elemento para convertirlo en una se�al que la compu entienda?', False, colorRojo)
            textoFelicitacion6 = '"�Es tu digiturno!"'
            
        textoFelicitacion3 = tipografiaMediana.render('�Sab�as que...', False, colorRojo)
        textoFelicitacion6 = tipografiaChica.render ('Para saber m�s mir� Digiaventuras: ' + textoFelicitacion6, False, colorRojo) 

        pantalla.blit(textoFelicitacion1,(x+25,y+20,ancho,alto))
        pantalla.blit(textoFelicitacion2,(x+25,y+60,ancho,alto))  
  
        pantalla.blit(textoFelicitacion3,(x+25,y+115,ancho,alto))
        pantalla.blit(textoFelicitacion4,(x+25,y+150,ancho,alto))
        pantalla.blit(textoFelicitacion5,(x+25,y+175,ancho,alto))
        pantalla.blit(textoFelicitacion6,(x+25,y+215,ancho,alto))
        
        if haSonado == False:
            pygame.display.update()
            sonidoGanaste.play()
            haSonado = True
            pygame.time.delay(4000)

        if nivel == 5 or nivel == 'Contrarreloj':
            botonVario(x+x/1.6,y*2+y/2,225,66,'Siguiente')
        else:
            botonVario(x+x/1.6,y*2+y/2,225,66,'SiguienteNivel')


#Dibujamos la ventana de que se ha perdido el juego, notificando la causa.
def dibujarPerdiste(causa):
    global puntajeTotal, haSonado, SuperTablet, instrucciones
    x=341
    y=192
    
    ancho=683
    alto=384
    
    if (perdiste==True):             
        pygame.draw.rect(pantalla,colorNaranjaOsc,(x+5,y+5,ancho+5,alto+5))
        pygame.draw.rect(pantalla,colorNaranjaClaro,(x,y,ancho,alto))
   
        if causa == 'Tiempo':
            textoPerdiste1 = tipografiaGrande.render('�Has perdido demasiado tiempo!', False, colorBlanco)
        elif causa == 'Energia':
            textoPerdiste1 = tipografiaGrande.render('�Te quedaste sin energ�a!', False, colorBlanco)
            
        textoPerdiste2 = tipografiaMediana.render('Vas a tener que volver a intentarlo', False, colorBlanco)

        SuperTablet=pygame.transform.scale(SuperTablet, (ancho/4,ancho/4))

        pantalla.blit(textoPerdiste1,(x+25,y+25,ancho,alto))
        pantalla.blit(textoPerdiste2,(x+25,y+90,ancho,alto))
        pantalla.blit(SuperTablet, (x+30,y+150))

        if haSonado == False:
            pygame.mixer.music.stop()
            pygame.display.update()
            sonidoPerdiste.play()
            haSonado = True
            pygame.time.delay(2000)
                
        botonVario(582,488,225,66, 'ReiniciarJuego')
        puntajeTotal = reiniciarPuntaje()

        if instrucciones == True:
            instrucciones = False



#Dibujamos la pantalla final del juego con su respectivo puntaje. 
def dibujarPantallaFinal():
    global DigiChica, DigiChico, LogoCM
    dibujarFondo("Imagenes/fondofinal.png")
        
    x=170
    y=96                        
    ancho=1024
    alto=546
   
    pygame.draw.rect(pantalla,colorAzulOsc,(x+5,y+5,ancho+5,alto+5))
    pygame.draw.rect(pantalla,colorAzulClaro,(x,y,ancho,alto))

    txtFinal = tipografiaGrande.render('�DESAF�O RESUELTO!', False, colorBlanco)
    txtFinal2 = tipografiaGrande.render('�Somos los digih�roes de la Argentina!', False, colorBlanco)
    txtFinal3 = tipografiaMediana.render('Conseguiste %s puntos' % puntajeTotal, False, colorBlanco)
    txtFinal4 = tipografiaMediana.render('�Buen�simo!', False, colorBlanco)

    #Avisamos si se pueden guardar las puntuaciones o si ya han sido guardadas.
    if guardado == False:
       txtFinal5 = 'Presion� la tecla G para guardar tus puntuaciones'
    else:
       txtFinal5 = '�Puntuaciones guardadas!'

    txtFinal5 = tipografiaMediana.render(txtFinal5, False, colorBlanco)      
    txtFinal6 = tipografiaMediana.render('Presion� ESC para ir al men�', False, colorBlanco)

    pantalla.blit(txtFinal,(x+50,y+60,ancho,alto))
    pantalla.blit(txtFinal2,(x+50,y+130,ancho,alto))
    pantalla.blit(txtFinal3,(x+50,y+200,ancho,alto))
    pantalla.blit(txtFinal4,(x+50,y+250,ancho,alto))
    pantalla.blit(txtFinal5, (x+50,y+310,ancho,alto))
    pantalla.blit(txtFinal6, (x+50,y+390,ancho,alto))
        
    x=756
    y=415
    ancho=197
    alto=228
        
    DigiChica = pygame.transform.scale(DigiChica, (ancho,alto))
    DigiChico = pygame.transform.scale(DigiChico, (ancho,alto))
        
    pantalla.blit(DigiChico, (x-ancho,y))
    pantalla.blit(DigiChica, (x,y))

    dibujarLogo(978,456,200,200)
    mejoresPuntuaciones()
    pygame.display.update()
    

#Mostramos en pantalla los 5 mejores puntajes seg�n el modo de juego seleccionado.
def mejoresPuntuaciones():
    x=1043
    y=190                        
    ancho=232
    alto=195

    tipografiaTitulo=pygame.font.SysFont('Comic Sans MS', 20, bold=True,italic=False)
    tipografiaPuntos=pygame.font.SysFont('Calibri', 18, bold=True,italic=True)

    if nivel == 'Contrarreloj':
        Archivo="PuntuacionesContrarreloj.txt"
    else:
        Archivo="PuntuacionesNormal.txt"

    pygame.draw.rect(pantalla,colorNegro,(x-5,y-5,ancho+10,alto+10))
    pygame.draw.rect(pantalla,colorBlanco,(x,y,ancho,alto))

    txtPuntuaciones = tipografiaTitulo.render('Mejores puntuaciones', False, colorNegro)
    
    pantalla.blit(txtPuntuaciones,(x+10,y+5,ancho,alto))
       
    Archivo = open(Archivo, 'r')
    Lineas = Archivo.read().split('\n')
    Lineas.append(' ')

    y = y+50

    for linea in range(5):
        if Lineas[linea] != ' ':
            txtPuntuacion = tipografiaPuntos.render(Lineas[linea], False, colorNegro)
            pantalla.blit(txtPuntuacion,(x+10,y,ancho,alto))
        else:
            Lineas.append(' ')
        y = y+25
#Creamos una funci�n que dibuje todo lo que se ve en la pantalla del juego.
def dibujarTodo():
    if (nivel == 'Contrarreloj'):
        dibujarFondo("Imagenes/fondoContrarreloj.png")
    else:
        dibujarFondo("Imagenes/fondoNormal.png")
    dibujarZonaDeTransporte()
    dibujarContadores()
    dibujarLogo(1059,540,200,200)
    dibujarCartelRonda(False)
    pygame.display.update()


#Creamos una funci�n que indica si se complet� el nivel, o si finaliz� por alguna causa (fin del tiempo, tiempo ocioso, falta de bater�a).
def estadoDelNivel():
    global nivelCompletado, cantidadDeEnergia, perdiste, zonaDeTransporte
    cantVirusSobreZonaProtegida=0

    for punto in lstZonasProtegidas:
        x=punto[0]
        y=punto[1]
        if zonaDeTransporte[x][y]=='virus':
            cantVirusSobreZonaProtegida=cantVirusSobreZonaProtegida+1       

    if nivel != 'Contrarreloj':
        if (cantVirusSobreZonaProtegida==len(lstZonasProtegidas)):
            nivelCompletado=True
            pygame.mixer.music.stop()
            if puntajeObtenido == False:
                obtenerPuntaje()
            dibujarFelicitacion()     
        else:
            nivelCompletado=False
            if (cantidadDeEnergia==0):
                perdiste=True
                dibujarPerdiste('Energia')
            if (tiempoOciosoTranscurrido==15):
                perdiste = True
                dibujarPerdiste('Tiempo')
    else:
        if (cantVirusSobreZonaProtegida==len(lstZonasProtegidas)):
            sonidoGanarPuntos.play()
            obtenerPuntaje()
            zonaDeTransporte = crearZonaDeTransporte()
            posicionarElemento("jugador",JugadorPosterior[0],JugadorPosterior[1])
            dibujarZonaDeTransporte()
        if tiempoTranscurrido == 0:
                nivelCompletado=True
                pygame.mixer.music.stop()
                dibujarFelicitacion()

#Guardamos los puntajes obtenidos al pasar cada nivel y el puntaje total acumulado.
def obtenerPuntaje():
    global puntajeNivel, puntajeTotal, puntajeObtenido
    if nivel == 'Contrarreloj':
        puntajeTotal = calcularPuntajeContrarreloj()
        
    else:
        puntajeNivel = calcularPuntajeNormal(cantidadDeEnergia, tiempoTranscurrido, "nivel")
        puntajeTotal = calcularPuntajeNormal(cantidadDeEnergia, tiempoTranscurrido, "total")
    puntajeObtenido = True

#Reestablecemos las principales variables y volvemos a visualizar el men�.
def volverAlMenu():
    global nivel, nivelCompletado, finJuego, jugando, puntajeTotal, pantalla, anchopantalla, altopantalla
    nivel = 0
    jugando = False
    nivelCompletado = False
    finJuego = False
    iniciarContadores()
    puntajeTotal = reiniciarPuntaje()
    pantalla = pygame.display.set_mode((855,480),pygame.NOFRAME)
    anchopantalla = pantalla.get_width()
    altopantalla = pantalla.get_height()
    dibujarFondo("Imagenes/fondomenu.png")
    mostrarMenu(pantalla, PersonajesDelMenu)
    dibujarLogo(694,54,126,126)
    cargarMusica(nivel)
    pygame.mixer.music.play(-1)
    if volumen == False:
        pygame.mixer.music.pause()

#Visualizamos el bot�n sonido para pausar y reiniciar los sonidos.                
def botonmute(x,y,lado,colorFondo):
    global volumen

    if volumen == True:
        BotonActivo = pygame.transform.scale(BotonVolumenA, (lado, lado))
        BotonInactivo = pygame.transform.scale(BotonVolumenI, (lado, lado))
    else:
        BotonActivo = pygame.transform.scale(BotonNoVolumenA, (lado, lado))
        BotonInactivo = pygame.transform.scale(BotonNoVolumenI, (lado, lado))
    
    if x+lado > posmouse[0] > x and y+lado > posmouse[1] > y:
        pantalla.blit(BotonActivo, (x, y))
        if clic[0] == 1:
            sonidoboton.play()
            if volumen == True:
                pygame.draw.rect(pantalla,colorFondo,(x,y,lado,lado))
                pygame.mixer.music.pause()
                volumen = False
            else:
                pygame.mixer.music.unpause()
                volumen = True
    else:
        pantalla.blit(BotonInactivo, (x, y))


#Visualizamos las instrucciones seg�n el nivel en el que se muestran.
def botonInstr(x,y,ancho,alto):
    global instrucciones
    dibujarBoton = True

    imgInstrucciones = obtenerInstrucciones(nivel)
    
    if instrucciones == False:
        if nivel == 0:
            Boton = 'BotonInstruccionesMenu.png'
            BotonP = 'BotonInstruccionesMenuP.png'
        else:
            Boton = 'BotonInstrucciones.png'
            BotonP = 'BotonInstruccionesP.png'
    else:
        if nivel == 0:
            Boton = 'BotonCerrarMenu.png'
            BotonP = 'BotonCerrarMenuP.png'
        else:
            Boton = 'BotonCerrar.png'
            BotonP = 'BotonCerrarP.png'

    if Boton == 'BotonCerrarMenu.png':
        x=750
        y=11
        ancho,alto=30,30
            
    Boton = pygame.image.load("Imagenes/Botones/" + str(Boton))
    BotonP = pygame.image.load("Imagenes/Botones/" + str(BotonP))

    if x+ancho > posmouse[0] > x and y+alto > posmouse[1] > y:
        BotonInstrucciones = BotonP
        if clic[0] == 1:
            sonidoboton.play()
            if instrucciones == False:
                if nivel == 0:
                    pantalla.blit(imgInstrucciones,(75,0))
                else:
                    pantalla.blit(imgInstrucciones,(0,y))
                instrucciones = True
            else:
                instrucciones = False
                if nivel == 0:
                    dibujarFondo("Imagenes/fondomenu.png")
                    mostrarMenu(pantalla, PersonajesDelMenu, LogoCM)
                else:
                    dibujarTodo()
            dibujarBoton = False
    else:
        BotonInstrucciones = Boton

    BotonInstrucciones = pygame.transform.scale(BotonInstrucciones, (ancho, alto))
        
    if dibujarBoton == True:
        pantalla.blit(BotonInstrucciones,(x,y,ancho,alto))
    pygame.display.update()


#Creamos una funci�n para generar el resto de botones que se muestran en pantalla, seg�n el tipo de bot�n.
def botonVario(x,y,ancho,alto,tipo): 
    global dibujarBoton, nivel, pantalla, anchopantalla, altopantalla, zonaDeTransporte, puntajeObtenido, EnergiaInicial, cantidadDePasos, jugando, finJuego, perdiste, haSonado, salirJuego
    dibujarBoton = True

    BotonGral = pygame.image.load("Imagenes/Botones/Boton" + tipo + ".png")
    BotonGralP = pygame.image.load("Imagenes/Botones/Boton" + tipo + "P.png")

    if x+ancho > posmouse[0] > x and y+alto > posmouse[1] > y:
        Boton = pygame.transform.scale(BotonGralP, (ancho, alto))
        if clic[0] == 1:
            sonidoboton.play()
            if tipo == 'AJugar' or tipo == 'Siguiente':
                if tipo == 'AJugar': #El bot�n genera el men�.
                    nivel = nivel+1
                    manosALaCompu.play()
                    pygame.time.delay(2000)
                    dibujarFondo("Imagenes/fondomenu.png")
                    mostrarMenu(pantalla, PersonajesDelMenu)
                    dibujarLogo(694,54,126,126)
                    cargarMusica(nivel)
                    pygame.mixer.music.play(-1)
                elif tipo == 'Siguiente': #El bot�n genera la pantalla final del juego.
                    dibujarPantallaFinal()
                    final.play()
                    puntajeObtenido = False
                    finJuego = True
                    jugando = False
            elif tipo == 'Comenzar' or tipo == 'SiguienteNivel' or tipo == 'Contrarreloj':
                    if tipo == 'Comenzar' or tipo == 'SiguienteNivel':
                        nivel = nivel + 1
                    else:
                        nivel = 'Contrarreloj'
                    if tipo == 'Comenzar' or tipo == 'Contrarreloj': #Los botones inician el juego seg�n el modo seleccionado.
                        pantalla = pygame.display.set_mode((anchoFull,altoFull), pygame.NOFRAME)
                        anchopantalla = pantalla.get_width()
                        altopantalla = pantalla.get_height()
                        jugando = True
                    elif tipo == 'SiguienteNivel': #El bot�n pasa al siguiente nivel.
                        puntajeObtenido = False
                        EnergiaInicial = cantidadDeEnergia
                    cargarMusica(nivel)
                    pygame.mixer.music.play(-1)
                    if volumen == False:
                        pygame.mixer.music.pause()
                    zonaDeTransporte=crearZonaDeTransporte()
                    dibujarTodo()
                    iniciarContadores()
                    dibujarPresentador()
                    botonInstr(cantPixelesPorLadoCasilla*(cantidadDeCasillasPorLado+3.5),cantPixelesPorLadoCasilla,200,70)
            elif tipo == 'ReiniciarJuego': #El bot�n reinicia el juego en caso de que se haya perdido.
                iniciarContadores()
                perdiste = False
                pygame.mixer.music.play(-1)
                if volumen == False:
                    pygame.mixer.music.pause()
                nivel = 1
                zonaDeTransporte=crearZonaDeTransporte()
                dibujarTodo()
            elif tipo == 'SalirDelJuego': #El bot�n cierra el juego.
                salirJuego = True

            haSonado = False   
            dibujarBoton = False
    else:
        Boton = pygame.transform.scale(BotonGral, (ancho, alto))

    if dibujarBoton == True:
        pantalla.blit(Boton,(x,y))
    pygame.display.update()


#Guardamos la cantidad de energ�a y cantidad de pasos antes de realizar un movimiento.
def valoresAnteriores():
    global anteriorEnergia, anteriorPasos, colorAnterior
    anteriorEnergia = cantidadDeEnergia
    anteriorPasos = cantidadDePasos
    colorAnterior = colorActual


#Generamos la funci�n que permite deshacer un movimiento (utilizando los valores anteriores).
def deshacerMovimiento():
    global cantidadDeEnergia, cantidadDePasos, permiteDeshacer, colorActual
    if permiteDeshacer==True:
        cantidadDeEnergia=anteriorEnergia 
        cantidadDePasos=anteriorPasos
        colorActual=colorAnterior
        posicionarElemento("jugador",JugadorAnterior[0],JugadorAnterior[1])
        if hayVirus == False:
            borrarElemento(JugadorPosterior[0], JugadorPosterior[1])
        else:
            posicionarElemento("virus",VirusAnterior[0],VirusAnterior[1])
            borrarElemento(VirusPosterior[0], VirusPosterior[1])
        dibujarCartelRonda(False)
        permiteDeshacer=False


#Creamos nuevamente la zona de transporte e inicializamos los contadores para reiniciar el nivel, seg�n el modo de juego.
def reiniciarNivel():
    global zonaDeTransporte, tecla_r
    tecla_r = True
    zonaDeTransporte = crearZonaDeTransporte()
    if nivel == 'Contrarreloj':
        posicionarElemento("jugador",JugadorPosterior[0],JugadorPosterior[1])
    else:
        iniciarContadores()

 
#Creamos funciones para mover a la Nave Binaria en las cuatro direcciones, que pueda empujar los virus y que guarde su posici�n antes de cada movimiento.
def irALaDerecha():
    global imgNaveBinaria, JugadorAnterior, JugadorPosterior, VirusAnterior, VirusPosterior, hayVirus, permiteDeshacer
    for i in range(1,cantidadDeCasillasPorLado):
        for j in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                JugadorAnterior = [j,i]
                imgNaveBinaria=ImgJugador("Imagenes/navebinariaDer.png")
                if (zonaDeTransporte[j+1][i]==0):
                    JugadorPosterior = [j+1,i]
                    posicionarElemento('jugador',j+1,i)
                    borrarElemento(j,i)
                    hayVirus=False
                    dibujarContadorDePasos(1)
                    dibujarContadorDeElectricidad(10)
                    permiteDeshacer=True  
                    
                    if volumen == True:
                        movimiento.play()
                    break
                elif(zonaDeTransporte[j+1][i]=='virus') and not ((zonaDeTransporte[j+2][i]=='pared') or (zonaDeTransporte[j+2][i]=='virus')):
                    JugadorPosterior = [j+1,i]
                    posicionarElemento('virus',j+2,i)
                    posicionarElemento('jugador',j+1,i)
                    borrarElemento(j,i)

                    hayVirus=True
                    VirusAnterior=[j+1,i]
                    VirusPosterior=[j+2,i]
                    dibujarContadorDePasos(1)
                    dibujarContadorDeElectricidad(15)
                    permiteDeshacer=True
                    
                    if volumen == True:
                        movimiento.play()
                    break
                else:
                    dibujarContadorDeElectricidad(200)
                    if volumen == True:
                        movimientoError.play()
                    permiteDeshacer=False
                    break
                
def irALaIzquierda():
    global imgNaveBinaria, JugadorAnterior, JugadorPosterior, VirusAnterior, VirusPosterior, hayVirus, permiteDeshacer
    for i in range(1,cantidadDeCasillasPorLado):
        for j in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                JugadorAnterior = [j,i]
                imgNaveBinaria=ImgJugador("Imagenes/navebinariaIzq.png")
                if (zonaDeTransporte[j-1][i]==0):
                    JugadorPosterior = [j-1,i]
                    posicionarElemento('jugador',j-1,i)
                    borrarElemento(j,i)

                    hayVirus=False
                    dibujarContadorDePasos(1)
                    dibujarContadorDeElectricidad(10)
                    permiteDeshacer=True
                    
                    if volumen == True:
                        movimiento.play()
                    break
                elif(zonaDeTransporte[j-1][i]=='virus') and not ((zonaDeTransporte[j-2][i]=='pared') or (zonaDeTransporte[j-2][i]=='virus')):
                    JugadorPosterior = [j-1,i]
                    posicionarElemento('virus',j-2,i)
                    posicionarElemento('jugador',j-1,i)
                    borrarElemento(j,i)
                    
                    hayVirus=True
                    VirusAnterior=[j-1,i]
                    VirusPosterior=[j-2,i]
                    dibujarContadorDePasos(1)
                    dibujarContadorDeElectricidad(15)
                    permiteDeshacer=True
                    
                    if volumen == True:
                        movimiento.play()
                    break
                else:
                    dibujarContadorDeElectricidad(200)
                    if volumen == True:
                        movimientoError.play()
                    permiteDeshacer=False
                    break
                
def irAbajo():
    global JugadorAnterior, JugadorPosterior, VirusAnterior, VirusPosterior, hayVirus, permiteDeshacer
    for j in range(1,cantidadDeCasillasPorLado):
        for i in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                JugadorAnterior = [j,i]
                if (zonaDeTransporte[j][i+1]==0):
                    JugadorPosterior = [j,i+1]
                    posicionarElemento('jugador',j,i+1)
                    borrarElemento(j,i)
                    
                    hayVirus=False
                    dibujarContadorDePasos(1)
                    dibujarContadorDeElectricidad(10)
                    permiteDeshacer=True

                    if volumen == True:
                        movimiento.play()
                    break
                elif(zonaDeTransporte[j][i+1]=='virus') and not ((zonaDeTransporte[j][i+2]=='pared') or (zonaDeTransporte[j][i+2]=='virus')):
                    JugadorPosterior = [j,i+1]
                    posicionarElemento('virus',j,i+2)
                    posicionarElemento('jugador',j,i+1)
                    borrarElemento(j,i)

                    hayVirus=True
                    VirusAnterior=[j,i+1]
                    VirusPosterior=[j,i+2]
                    dibujarContadorDePasos(1)
                    dibujarContadorDeElectricidad(15)
                    permiteDeshacer=True
                    
                    if volumen == True:
                        movimiento.play()
                    break
                else:
                    dibujarContadorDeElectricidad(200)
                    if volumen == True:
                        movimientoError.play()
                    permiteDeshacer=False
                    break
                
def irArriba():
    global JugadorAnterior, JugadorPosterior, VirusAnterior, VirusPosterior, hayVirus, permiteDeshacer
    for j in range(1,cantidadDeCasillasPorLado):
        for i in range(1,cantidadDeCasillasPorLado):
            if (zonaDeTransporte[j][i]=='jugador'):
                JugadorAnterior = [j,i]
                if (zonaDeTransporte[j][i-1]==0):
                    JugadorPosterior = [j,i-1]
                    posicionarElemento('jugador',j,i-1)
                    borrarElemento(j,i)
                    
                    hayVirus=False
                    dibujarContadorDePasos(1)
                    dibujarContadorDeElectricidad(10)
                    permiteDeshacer=True

                    if volumen == True:
                        movimiento.play()
                    break
                elif(zonaDeTransporte[j][i-1]=='virus') and not ((zonaDeTransporte[j][i-2]=='pared') or (zonaDeTransporte[j][i-2]=='virus')):
                    JugadorPosterior = [j,i-1]
                    posicionarElemento('virus',j,i-2)
                    posicionarElemento('jugador',j,i-1)
                    borrarElemento(j,i)
                    
                    hayVirus=True
                    VirusAnterior=[j,i-1]
                    VirusPosterior=[j,i-2]
                    dibujarContadorDePasos(1)
                    dibujarContadorDeElectricidad(15)
                    permiteDeshacer=True
                    
                    if volumen == True:
                        movimiento.play()
                    break
                else:
                    dibujarContadorDeElectricidad(200)
                    if volumen == True:
                        movimientoError.play()
                    permiteDeshacer=False
                    break

 
imgNaveBinaria=ImgJugador("Imagenes/navebinariaDer.png") #Definimos la primera posici�n que tomar� el jugador.
zonaDeTransporte=crearZonaDeTransporte() #Guardamos dentro de "zonaDeTransporte" la disposici�n de los elementos del �rea de juego.


#Generamos la pantalla de presentaci�n del juego.
intro.play()
dibujarPantallaInicial()
pygame.time.delay(10000)


#Creamos el bucle principal del juego.
while not salirJuego:

    #Las siguientes funciones deben ejecutarse si se cumple la condici�n independientemente de lo que ocurra en pantalla.
    if comenzarTiempo == True and nivelCompletado==False:
        dibujarContadores()
    if jugando == True:     
        estadoDelNivel()
        
    for event in pygame.event.get():
        posmouse = pygame.mouse.get_pos()
        clic = pygame.mouse.get_pressed()
        if nivel == -1:
            botonVario(329,420,194,57, 'AJugar')
        elif nivel == 0:
            #Visualizamos los botones del men� principal.
            if instrucciones == False:
                botonVario(310,166,253,46, 'Comenzar')
                if dibujarBoton == True:
                    botonVario(310,226,253,46, 'Contrarreloj')
                if dibujarBoton == True:
                    botonmute(526,77,40,(28,27,35))
                    botonVario(310,346,253,46, 'SalirDelJuego')
            if dibujarBoton == True:
                botonInstr(310,286,253,46)
        else:
            if nivelCompletado == False and perdiste == False:
                if contadoresIniciados==False:
                    contadoresIniciados=True
                    iniciarContadores()
                if info == False:
                    botonInstr(cantPixelesPorLadoCasilla*(cantidadDeCasillasPorLado+3.5),cantPixelesPorLadoCasilla,200,70)
                if instrucciones == False:
                    dibujarPresentador()
                if instrucciones == False and info == False:
                    if nivel == 'Contrarreloj':
                        botonmute((cantPixelesPorLadoCasilla*(cantidadDeCasillasPorLado+2)),cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla,(230,153,255))
                    else:
                        botonmute((cantPixelesPorLadoCasilla*(cantidadDeCasillasPorLado+2)),cantPixelesPorLadoCasilla, cantPixelesPorLadoCasilla,(100,224,255))
                    if event.type == pygame.KEYDOWN:
                        #Apenas se presiona una tecla, el tiempo comienza a correr.
                        if comenzarTiempo == False:
                            comenzarTiempo = True
                            tiempoOcioso = time.time()
                            tiempoInicial = time.time()
                            Presentador=False
                            dibujarTodo()
                        if event.key == pygame.K_RIGHT:
                            tiempoOcioso = time.time()
                            valoresAnteriores()
                            dibujarCartelRonda(True)
                            irALaDerecha()
                        if event.key == pygame.K_LEFT:
                            tiempoOcioso = time.time()
                            valoresAnteriores()
                            dibujarCartelRonda(True)
                            irALaIzquierda()
                        if event.key == pygame.K_DOWN:
                            tiempoOcioso = time.time()
                            valoresAnteriores()
                            dibujarCartelRonda(True)
                            irAbajo()
                        if event.key == pygame.K_UP:
                            tiempoOcioso = time.time()
                            valoresAnteriores()
                            dibujarCartelRonda(True)
                            irArriba()
                        if event.key == pygame.K_r:
                            tiempoOcioso = time.time()
                            reiniciarNivel()
                            dibujarCartelRonda(True)
                        #Si el modo de juego es contrarreloj, la tecla 'x' no tendr� funcionalidad.
                        if nivel != 'Contrarreloj':
                            if event.key == pygame.K_x:
                                tiempoOcioso = time.time()
                                deshacerMovimiento()
                    dibujarZonaDeTransporte()
            
        if finJuego == True:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_g: #Al presionar la techa "g" se guarda el nombre del jugador y la puntuaci�n del juego.
                    if guardado == False:
                        nombreJugador=pedirNombreJ()
                        guardarPuntuacion(nombreJugador, nivel)
                        guardado = True
                        dibujarPantallaFinal()
                    else:
                        yaGuardado()
                        
        if event.type == pygame.QUIT:
                salirJuego = True     
        if event.type == pygame.KEYDOWN:
            if nivel != 0 and nivel != -1:
                if event.key == pygame.K_ESCAPE: #Al presionar la techa "escape" se vuelve a generar el men�.
                    volverAlMenu()
                    
        
pygame.quit()
quit()
