#!/usr/bin/env python
#-*- coding: ISO-8859-1 -*-

#Importamos la librer�a necesaria.
import pygame

#Redimensiona y muestra las im�genes que se ver�n en el men� (sin tener en cuenta los botones).
def mostrarMenu(pantalla, Personajes):
    alto = 236
    ancho = 216
    
    Luna = pygame.transform.scale(Personajes[0], (ancho,alto))
    Elio = pygame.transform.scale(Personajes[1], (ancho,alto))
    Api = pygame.transform.scale(Personajes[2], (ancho,alto))
    Trucha1 = pygame.transform.scale(Personajes[3], (ancho,alto))
    Trucha2 = pygame.transform.scale(Personajes[4], (ancho,alto))
    RayoBit = pygame.transform.scale(Personajes[5], (ancho,alto))
    
    titulo=pygame.image.load("Imagenes/Menu.png")

    pantalla.blit(RayoBit, (0,0))
    pantalla.blit(Luna, (670,181))
    pantalla.blit(Api, (556,309))
    pantalla.blit(Elio, (0,171))
    pantalla.blit(Trucha2, (64, 344))
    pantalla.blit(Trucha1,(0, 357))
    pantalla.blit(titulo,(354,100))
    pygame.display.update()

