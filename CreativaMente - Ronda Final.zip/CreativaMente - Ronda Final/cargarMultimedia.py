#!/usr/bin/env python
#-*- coding: ISO-8859-1 -*-

import pygame

#Inicializamos la librer�a Pygame y el mixer del sonido.
pygame.init()
pygame.mixer.init()

#Cargamos la m�sica.
intro = pygame.mixer.Sound("Musica/Intro.ogg")
manosALaCompu = pygame.mixer.Sound("Musica/manosalacompu.ogg")
movimiento = pygame.mixer.Sound("Musica/movimiento1.ogg")
movimientoError = pygame.mixer.Sound("Musica/movimiento2.ogg")
final = pygame.mixer.Sound("Musica/SomosDigiheroes.ogg")
sonidoPerdiste = pygame.mixer.Sound("Musica/perdiste.ogg")
sonidoGanaste = pygame.mixer.Sound("Musica/ganaste.ogg")
sonidoboton = pygame.mixer.Sound("Musica/boton.ogg")
sonidoGanarPuntos = pygame.mixer.Sound("Musica/ganarpuntos.ogg")

#Cargamos las im�genes.
imgPared=pygame.image.load("Imagenes/pared.png")
listaAmenazas  = ["Imagenes/amenaza1.png","Imagenes/amenaza2.png","Imagenes/amenaza3.png","Imagenes/amenaza4.png", "Imagenes/amenaza5.png"]
imgAreaProtegida=pygame.image.load("Imagenes/areaprotegida.png")

BotonVolumenA = pygame.image.load("Imagenes/volumenA.png")
BotonVolumenI = pygame.image.load("Imagenes/volumenI.png")

BotonNoVolumenA = pygame.image.load("Imagenes/novolumenA.png")
BotonNoVolumenI = pygame.image.load("Imagenes/novolumenI.png")

reloj = pygame.image.load("Imagenes/reloj.png")

Luna = pygame.image.load("Imagenes/Luna.png")
Elio = pygame.image.load("Imagenes/Elio.png")
Api = pygame.image.load("Imagenes/Api.png")
Trucha1 = pygame.image.load("Imagenes/Cibertrucha1.png")
Trucha2 = pygame.image.load("Imagenes/Cibertrucha2.png")
RayoBit = pygame.image.load("Imagenes/rayobit.png")

PersonajesDelMenu = [Luna, Elio, Api, Trucha1, Trucha2, RayoBit]

SuperTablet = pygame.image.load("Imagenes/supertablet.png")
DigiChica = pygame.image.load("Imagenes/digichica.png")
DigiChico = pygame.image.load("Imagenes/digichico.png")
LogoCM= pygame.image.load("Imagenes/LogoCM.png")

#Definimos una funci�n que carga la imagen de informaci�n extra seg�n el nivel de juego.
def obtenerInfoextra(Nivel):
    if Nivel == 1:
        imagen = "Imagenes/InfoextraVirus.png"
    elif Nivel == 2:
        imagen = "Imagenes/InfoextraTiposVirus.png"
    elif Nivel == 3:
        imagen = "Imagenes/InfoextraInternet.png"
    elif Nivel == 4:
        imagen = "Imagenes/InfoextraImagenes.png"
    elif Nivel == 5:
        imagen = "Imagenes/InfoextraVideojuegos.png"
    elif Nivel == 'Contrarreloj':
        imagen = "Imagenes/InfoextraReloj.png"
      
    imgInfoextra = pygame.image.load(imagen)

    return imgInfoextra

#Definimos una funci�n que obtiene la imagen de las instrucciones seg�n el nivel que se est� jugando.
def obtenerInstrucciones(nivel):
    if nivel == 0:
        imagen = "Imagenes/instruccionesGenerales.png"
    elif nivel != 'Contrarreloj':
        imagen = "Imagenes/instruccionesNormal.png"
    else:
        imagen = "Imagenes/instruccionesContrarreloj.png"

    imgInstrucciones = pygame.image.load(imagen)

    return imgInstrucciones

#Definimos una funci�n que carga la m�sica dependiendo el nivel.
def cargarMusica(nivel):
    if nivel == 'Contrarreloj':
        pygame.mixer.music.load("Musica/Contrarreloj.ogg")
    elif nivel == 0:
        pygame.mixer.music.load("Musica/menu.ogg")
    else:
        pygame.mixer.music.load("Musica/Jugando.mp3")

#Definimos una funci�n que carga la imagen de la bater�a seg�n la cantidad restante.
def obtenerBateria(Energia):
    if Energia == 0:
        imgBateria = "Imagenes/bateria5.png"
    elif Energia <= 1750:
        imgBateria = "Imagenes/bateria4.png"
    elif Energia <= 3500:
        imgBateria = "Imagenes/bateria3.png"
    elif Energia <= 5250:
        imgBateria = "Imagenes/bateria2.png"
    elif Energia <= 7000:
        imgBateria = "Imagenes/bateria1.png"
    
    imgBateria = pygame.image.load(imgBateria)

    return imgBateria

