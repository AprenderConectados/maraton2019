#!/usr/bin/env python
#-*- coding: ISO-8859-1 -*-

#Importamos las librer�as necesarias
import os
import ctypes
import subprocess

#Se detecta en qu� sistema se est� ejecutando el programa
sistema = os.name

#Seg�n el sistema, se registra el alto y ancho de la pantalla total
def pantallaWindows():
    user32 = ctypes.windll.user32
    user32.SetProcessDPIAware()
    medida = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)

    return medida
 
def pantallaLinux():
    medida = (None, None)
    args = ["xrandr", "-q", "-d", ":0"]
    proc = subprocess.Popen(args,stdout=subprocess.PIPE)
    for line in proc.stdout:
        if isinstance(line, bytes):
            line = line.decode("utf-8")
            if "Screen" in line:
                medida = (int(line.split()[7]),  int(line.split()[9][:-1]))
    return medida

if sistema == "nt":
    anchoFull, altoFull = pantallaWindows()
else:
    anchoFull, altoFull = pantallaLinux()
