#!/usr/bin/env python
#-*- coding: utf-8 -*-

#Importamos las librerías necesarias
import Tkinter
import tkSimpleDialog
import tkMessageBox

root = Tkinter.Tk()
root.withdraw()


#Pedimos que el jugador ingrese su nombre a través del teclado
def pedirNombreJ():
    nombreJugador = tkSimpleDialog.askstring("Guardando","Ingresá tu nombre")
    
    if nombreJugador is not None:
        if len(nombreJugador)== 0:
            tkMessageBox.showinfo("Error", "No escribiste nada")
            nombreJugador = pedirNombreJ()
    else:
        nombreJugador = "Jugador1"

    return nombreJugador

#Devolvemos mensaje de error si ya se guardó el puntaje
def yaGuardado():
    tkMessageBox.showinfo("Error", "El puntaje ya fue guardado")

#tk.iconbitmap(default="nombre del ícono")
